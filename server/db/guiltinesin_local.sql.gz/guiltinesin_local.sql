-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: guiltinesin_local
-- ------------------------------------------------------
-- Server version	10.3.39-MariaDB-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `guiltinesin_local`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `guiltinesin_local` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `guiltinesin_local`;

--
-- Table structure for table `abilities`
--

DROP TABLE IF EXISTS `abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abilities` (
  `abilityId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`abilityId`),
  UNIQUE KEY `uk_character_ability` (`characterId`,`id`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `abilities_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `abilities_ibfk_2` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1237 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abilities`
--

LOCK TABLES `abilities` WRITE;
/*!40000 ALTER TABLE `abilities` DISABLE KEYS */;
INSERT INTO `abilities` VALUES (1,1,10012,1,1),(2,1,10013,1,1),(3,1,10014,1,1),(4,1,10000,1,1),(5,1,10001,1,1),(6,1,10002,1,1),(7,1,10003,1,1),(8,1,10004,1,1),(9,1,10005,1,1),(10,1,10006,1,1),(11,1,10007,1,1),(12,1,10008,1,1),(13,1,10009,1,1),(14,1,10010,1,1),(15,1,10011,1,1),(16,1,10015,1,1),(17,1,10016,1,1),(324,3,10012,1,1),(325,3,10013,1,1),(326,3,10014,1,1),(327,3,10000,1,1),(328,3,10001,1,1),(329,3,10007,1,1),(330,3,10009,1,1),(331,3,10008,1,1),(332,3,10002,1,1),(333,3,10003,1,1),(334,3,10004,1,1),(335,3,10005,1,1),(336,3,10006,1,1),(337,3,10010,1,1),(338,3,10011,1,1),(339,3,10015,1,1),(340,3,10016,1,1),(375,4,10012,1,1),(376,4,10013,1,1),(377,4,10014,1,1),(378,4,10000,1,1),(379,4,10005,1,1),(380,4,10006,1,1),(381,4,10001,1,1),(382,4,10002,1,1),(383,4,10003,1,1),(384,4,10004,1,1),(385,4,10007,1,1),(386,4,10008,1,1),(387,4,10009,1,1),(388,4,10010,1,1),(389,4,10011,1,1),(390,4,10015,1,1),(391,4,10016,1,1),(426,5,10012,1,1),(427,5,10013,1,1),(428,5,10014,1,1),(429,5,10000,1,1),(430,5,10001,1,1),(431,5,10007,1,1),(432,5,10009,1,1),(433,5,10025,1,1),(434,5,401035,1,1),(435,5,10002,1,1),(436,5,10003,1,1),(437,5,10004,1,1),(438,5,10005,1,1),(439,5,10006,1,1),(440,5,10008,1,1),(441,5,10010,1,1),(442,5,10011,1,1),(443,5,10015,1,1),(444,5,10016,1,1),(462,6,10012,1,1),(463,6,10013,1,1),(464,6,10014,1,1),(465,6,10000,1,1),(466,6,10001,1,1),(467,6,10007,1,1),(468,6,10009,1,1),(469,6,10002,1,1),(470,6,10003,1,1),(471,6,10004,1,1),(472,6,10005,1,1),(473,6,10006,1,1),(474,6,10008,1,1),(475,6,10010,1,1),(476,6,10011,1,1),(477,6,10015,1,1),(478,6,10016,1,1),(513,8,10012,1,1),(514,8,10013,1,1),(515,8,10014,1,1),(516,8,10000,1,1),(517,8,10001,1,1),(518,8,10002,1,1),(519,8,10003,1,1),(520,8,10004,1,1),(521,8,10005,1,1),(522,8,10006,1,1),(523,8,10007,1,1),(524,8,10008,1,1),(525,8,10009,1,1),(526,8,10010,1,1),(527,8,10011,1,1),(528,8,10015,1,1),(529,8,10016,1,1),(564,9,10012,1,1),(565,9,10013,1,1),(566,9,10014,1,1),(567,9,10000,1,1),(568,9,10001,1,1),(569,9,10007,1,1),(570,9,10009,1,1),(571,9,10008,1,1),(572,9,10002,1,1),(573,9,10003,1,1),(574,9,10004,1,1),(575,9,10005,1,1),(576,9,10006,1,1),(577,9,10010,1,1),(578,9,10011,1,1),(579,9,10015,1,1),(580,9,10016,1,1),(598,10,10012,1,1),(599,10,10013,1,1),(600,10,10014,1,1),(601,10,10000,1,1),(602,10,10001,1,1),(603,10,10007,1,1),(604,10,10009,1,1),(605,10,10008,1,1),(606,10,10002,1,1),(607,10,10003,1,1),(608,10,10004,1,1),(609,10,10005,1,1),(610,10,10006,1,1),(611,10,10010,1,1),(612,10,10011,1,1),(613,10,10015,1,1),(614,10,10016,1,1),(632,11,10012,1,1),(633,11,10013,1,1),(634,11,10014,1,1),(635,11,10000,1,1),(636,11,10005,1,1),(637,11,10006,1,1),(638,11,10001,1,1),(639,11,10002,1,1),(640,11,10003,1,1),(641,11,10004,1,1),(642,11,10007,1,1),(643,11,10008,1,1),(644,11,10009,1,1),(645,11,10010,1,1),(646,11,10011,1,1),(647,11,10015,1,1),(648,11,10016,1,1),(649,12,10012,1,1),(650,12,10013,1,1),(651,12,10014,1,1),(652,12,10000,1,1),(653,12,10001,1,1),(654,12,10007,1,1),(655,12,10009,1,1),(656,12,10008,1,1),(657,12,10002,1,1),(658,12,10003,1,1),(659,12,10004,1,1),(660,12,10005,1,1),(661,12,10006,1,1),(662,12,10010,1,1),(663,12,10011,1,1),(664,12,10015,1,1),(665,12,10016,1,1),(666,13,10012,1,1),(667,13,10013,1,1),(668,13,10014,1,1),(669,13,10000,1,1),(670,13,10001,1,1),(671,13,10007,1,1),(672,13,10009,1,1),(673,13,10025,1,1),(674,13,401035,1,1),(675,13,10002,1,1),(676,13,10003,1,1),(677,13,10004,1,1),(678,13,10005,1,1),(679,13,10006,1,1),(680,13,10008,1,1),(681,13,10010,1,1),(682,13,10011,1,1),(683,13,10015,1,1),(684,13,10016,1,1),(685,14,10012,1,1),(686,14,10013,1,1),(687,14,10014,1,1),(688,14,10000,1,1),(689,14,10001,1,1),(690,14,10007,1,1),(691,14,10009,1,1),(692,14,10002,1,1),(693,14,10003,1,1),(694,14,10004,1,1),(695,14,10005,1,1),(696,14,10006,1,1),(697,14,10008,1,1),(698,14,10010,1,1),(699,14,10011,1,1),(700,14,10015,1,1),(701,14,10016,1,1),(719,15,10012,1,1),(720,15,10013,1,1),(721,15,10014,1,1),(722,15,10000,1,1),(723,15,10005,1,1),(724,15,10006,1,1),(725,15,10001,1,1),(726,15,10002,1,1),(727,15,10003,1,1),(728,15,10004,1,1),(729,15,10007,1,1),(730,15,10008,1,1),(731,15,10009,1,1),(732,15,10010,1,1),(733,15,10011,1,1),(734,15,10015,1,1),(735,15,10016,1,1),(753,16,10012,1,1),(754,16,10013,1,1),(755,16,10014,1,1),(756,16,10000,1,1),(757,16,10001,1,1),(758,16,10007,1,1),(759,16,10009,1,1),(760,16,10025,1,1),(761,16,401035,1,1),(762,16,10002,1,1),(763,16,10003,1,1),(764,16,10004,1,1),(765,16,10005,1,1),(766,16,10006,1,1),(767,16,10008,1,1),(768,16,10010,1,1),(769,16,10011,1,1),(770,16,10015,1,1),(771,16,10016,1,1),(791,17,10012,1,1),(792,17,10013,1,1),(793,17,10014,1,1),(794,17,10000,1,1),(795,17,10001,1,1),(796,17,10007,1,1),(797,17,10009,1,1),(798,17,10025,1,1),(799,17,401035,1,1),(800,17,10002,1,1),(801,17,10003,1,1),(802,17,10004,1,1),(803,17,10005,1,1),(804,17,10006,1,1),(805,17,10008,1,1),(806,17,10010,1,1),(807,17,10011,1,1),(808,17,10015,1,1),(809,17,10016,1,1),(829,18,10012,1,1),(830,18,10013,1,1),(831,18,10014,1,1),(832,18,10000,1,1),(833,18,10001,1,1),(834,18,10007,1,1),(835,18,10009,1,1),(836,18,10002,1,1),(837,18,10003,1,1),(838,18,10004,1,1),(839,18,10005,1,1),(840,18,10006,1,1),(841,18,10008,1,1),(842,18,10010,1,1),(843,18,10011,1,1),(844,18,10015,1,1),(845,18,10016,1,1),(846,19,10012,1,1),(847,19,10013,1,1),(848,19,10014,1,1),(849,19,10000,1,1),(850,19,10001,1,1),(851,19,10002,1,1),(852,19,10003,1,1),(853,19,10004,1,1),(854,19,10005,1,1),(855,19,10006,1,1),(856,19,10007,1,1),(857,19,10008,1,1),(858,19,10009,1,1),(859,19,10010,1,1),(860,19,10011,1,1),(861,19,10015,1,1),(862,19,10016,1,1),(897,20,10012,1,1),(898,20,10013,1,1),(899,20,10014,1,1),(900,20,10000,1,1),(901,20,10001,1,1),(902,20,10007,1,1),(903,20,10009,1,1),(904,20,10008,1,1),(905,20,10002,1,1),(906,20,10003,1,1),(907,20,10004,1,1),(908,20,10005,1,1),(909,20,10006,1,1),(910,20,10010,1,1),(911,20,10011,1,1),(912,20,10015,1,1),(913,20,10016,1,1),(965,21,10012,1,1),(966,21,10013,1,1),(967,21,10014,1,1),(968,21,10000,1,1),(969,21,10005,1,1),(970,21,10006,1,1),(971,21,10001,1,1),(972,21,10002,1,1),(973,21,10003,1,1),(974,21,10004,1,1),(975,21,10007,1,1),(976,21,10008,1,1),(977,21,10009,1,1),(978,21,10010,1,1),(979,21,10011,1,1),(980,21,10015,1,1),(981,21,10016,1,1),(982,22,10012,1,1),(983,22,10013,1,1),(984,22,10014,1,1),(985,22,10000,1,1),(986,22,10001,1,1),(987,22,10007,1,1),(988,22,10009,1,1),(989,22,10008,1,1),(990,22,10002,1,1),(991,22,10003,1,1),(992,22,10004,1,1),(993,22,10005,1,1),(994,22,10006,1,1),(995,22,10010,1,1),(996,22,10011,1,1),(997,22,10015,1,1),(998,22,10016,1,1);
/*!40000 ALTER TABLE `abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_properties`
--

DROP TABLE IF EXISTS `account_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_properties` (
  `propertyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(1) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`propertyId`),
  UNIQUE KEY `uk_account_property` (`accountId`,`name`),
  KEY `accountId` (`accountId`),
  CONSTRAINT `account_properties_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1585 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_properties`
--

LOCK TABLES `account_properties` WRITE;
/*!40000 ALTER TABLE `account_properties` DISABLE KEYS */;
INSERT INTO `account_properties` VALUES (1,1,'Medal','f','0'),(2,1,'GiftMedal','f','0'),(3,1,'PremiumMedal','f','0'),(4,1,'SelectedBarrack','f','11'),(5,1,'BasicAccountWarehouseSlotCount','f','69'),(6,1,'InDunCountType_100','f','0'),(7,1,'InDunCountType_200','f','0'),(8,1,'InDunCountType_0','f','0'),(9,1,'InDunCountType_400','f','0'),(10,1,'InDunCountType_300','f','0'),(11,1,'InDunCountType_500','f','0'),(12,1,'InDunCountType_600','f','0'),(13,1,'InDunCountType_700','f','0'),(14,1,'InDunCountType_10000','f','0'),(15,1,'InDunCountType_900','f','0'),(16,1,'InDunCountType_1200','f','0'),(17,1,'InDunCountType_1100','f','0'),(18,1,'InDunCountType_8003','f','0'),(19,1,'InDunCountType_2','f','0'),(20,1,'InDunCountType_8000','f','0'),(21,1,'Indun_ResetTime','s','202604625081405'),(22,1,'IndunWeeklyResetTime','s','202604524210144');
/*!40000 ALTER TABLE `account_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_properties_log`
--

DROP TABLE IF EXISTS `account_properties_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_properties_log` (
  `logId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(1) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  `backupTimestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `backupReason` varchar(50) DEFAULT 'pre_save',
  PRIMARY KEY (`logId`),
  KEY `idx_itemId_timestamp` (`accountId`,`backupTimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_properties_log`
--

LOCK TABLES `account_properties_log` WRITE;
/*!40000 ALTER TABLE `account_properties_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_properties_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `accountId` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL,
  `sessionKey` varchar(64) DEFAULT NULL,
  `teamName` varchar(64) DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 3,
  `authority` int(11) NOT NULL DEFAULT 0,
  `settings` varchar(2048) NOT NULL DEFAULT '',
  `medals` int(11) NOT NULL DEFAULT 0,
  `giftMedals` int(11) NOT NULL DEFAULT 0,
  `premiumMedals` int(11) NOT NULL DEFAULT 0,
  `additionalSlotCount` int(11) NOT NULL DEFAULT 0,
  `teamExp` int(11) NOT NULL DEFAULT 0,
  `barracksThema` int(11) NOT NULL DEFAULT 11,
  `themas` varchar(128) NOT NULL DEFAULT '11',
  `selectedSlot` tinyint(4) NOT NULL DEFAULT 0,
  `loginState` tinyint(4) NOT NULL DEFAULT 0,
  `loginCharacter` bigint(20) NOT NULL DEFAULT 0,
  `premiumTokenExpiration` datetime DEFAULT NULL,
  `language` varchar(32) NOT NULL DEFAULT 'English',
  `lastLogin` datetime DEFAULT NULL,
  `lastIP` int(10) unsigned DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `creationDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'gotei','$2a$10$cxu8FzYqEkscYOl31kGH3.Tb4cJJ5Wx98oqmR6OMulA6YxnOwil/u','FB82652187F83E98C75E1C730A1223CD5C1C4E7E','Gotei',3,99,'44 0 98 0 15 1 63 1 46 1 66 1 71 1 68 1 84 1 85 1 86 1 163 1 164 1 155 0 157 1 99 1 133 1 145 1 150 1 151 1 82 1 91 1 83 0 23 1 33 0 48 1 54 1 53 1 61 1 73 1 24 1 45 1 52 1 55 1 60 1 67 1 96 1 141 1 143 1 136 0 138 0 142 1 130 1 131 1 132 1 17 1 34 1 59 1 58 1 50 500 51 230 100 1 101 1 102 1 103 1 104 1 105 1 166 1 106 1 107 1 108 1 110 1 109 1 111 1 126 1 112 1 113 1 115 1 116 1 117 1 118 1 119 1 120 1 121 1 122 1 123 1 124 1 125 1 167 1 168 1 169 1 170 1 144 0',0,0,0,20,0,11,'11',1,0,0,'0001-01-01 00:00:00','English','2026-04-26 04:20:37',NULL,NULL,'2026-04-24 20:45:18');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `achievement_points`
--

DROP TABLE IF EXISTS `achievement_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `achievement_points` (
  `characterId` bigint(20) NOT NULL,
  `pointId` bigint(20) NOT NULL,
  `pointValue` mediumint(9) NOT NULL,
  PRIMARY KEY (`characterId`,`pointId`),
  UNIQUE KEY `uk_character_point` (`characterId`,`pointId`),
  KEY `achievement_points_ibfk_1` (`characterId`),
  CONSTRAINT `achievement_points_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievement_points`
--

LOCK TABLES `achievement_points` WRITE;
/*!40000 ALTER TABLE `achievement_points` DISABLE KEYS */;
INSERT INTO `achievement_points` VALUES (1,104,1),(1,1001,2),(1,2005,4),(13,1001,1),(14,1001,1),(15,1001,1),(16,1001,1),(17,1001,1),(18,1001,1),(19,1001,1),(20,1001,1),(22,1001,1);
/*!40000 ALTER TABLE `achievement_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `achievements` (
  `characterId` bigint(20) NOT NULL,
  `achievementId` bigint(20) NOT NULL,
  PRIMARY KEY (`achievementId`,`characterId`),
  UNIQUE KEY `uk_character_achievement` (`characterId`,`achievementId`),
  KEY `achievements_ibfk_1` (`characterId`),
  CONSTRAINT `achievements_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievements`
--

LOCK TABLES `achievements` WRITE;
/*!40000 ALTER TABLE `achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adventure_book`
--

DROP TABLE IF EXISTS `adventure_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_book` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `classId` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `accountId` (`accountId`),
  KEY `adventure_book_ibfk_1` (`accountId`),
  CONSTRAINT `adventure_book_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adventure_book`
--

LOCK TABLES `adventure_book` WRITE;
/*!40000 ALTER TABLE `adventure_book` DISABLE KEYS */;
INSERT INTO `adventure_book` VALUES (8,1,0,41319,1);
/*!40000 ALTER TABLE `adventure_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adventure_book_items`
--

DROP TABLE IF EXISTS `adventure_book_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_book_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `itemId` int(11) NOT NULL,
  `craftCount` int(11) NOT NULL DEFAULT 0,
  `obtainCount` int(11) NOT NULL DEFAULT 0,
  `useCount` int(11) NOT NULL DEFAULT 0,
  `count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `accountId` (`accountId`),
  KEY `adventure_book_items_ibfk_1` (`accountId`),
  CONSTRAINT `adventure_book_items_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adventure_book_items`
--

LOCK TABLES `adventure_book_items` WRITE;
/*!40000 ALTER TABLE `adventure_book_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `adventure_book_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adventure_book_monster_drops`
--

DROP TABLE IF EXISTS `adventure_book_monster_drops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adventure_book_monster_drops` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `monsterId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `accountId` (`accountId`),
  KEY `adventure_book_monster_drops_ibfk_1` (`accountId`),
  CONSTRAINT `adventure_book_monster_drops_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adventure_book_monster_drops`
--

LOCK TABLES `adventure_book_monster_drops` WRITE;
/*!40000 ALTER TABLE `adventure_book_monster_drops` DISABLE KEYS */;
/*!40000 ALTER TABLE `adventure_book_monster_drops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buffs`
--

DROP TABLE IF EXISTS `buffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buffs` (
  `buffId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `classId` int(11) NOT NULL,
  `numArg1` int(11) NOT NULL,
  `numArg2` int(11) NOT NULL,
  `numArg3` int(11) NOT NULL DEFAULT 0,
  `numArg4` int(11) NOT NULL DEFAULT 0,
  `numArg5` int(11) NOT NULL DEFAULT 0,
  `duration` time NOT NULL,
  `runTime` time NOT NULL,
  `skillId` int(11) NOT NULL,
  `overbuffCount` int(11) NOT NULL,
  PRIMARY KEY (`buffId`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `buffs_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buffs`
--

LOCK TABLES `buffs` WRITE;
/*!40000 ALTER TABLE `buffs` DISABLE KEYS */;
/*!40000 ALTER TABLE `buffs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_etc_properties`
--

DROP TABLE IF EXISTS `character_etc_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_etc_properties` (
  `propertyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(1) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`propertyId`),
  UNIQUE KEY `uk_character_etc_property` (`characterId`,`name`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `character_etc_properties_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `character_etc_properties_ibfk_2` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2060 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_etc_properties`
--

LOCK TABLES `character_etc_properties` WRITE;
/*!40000 ALTER TABLE `character_etc_properties` DISABLE KEYS */;
INSERT INTO `character_etc_properties` VALUES (1,1,'SkintoneName','s','skintone2'),(2,1,'StartHairName','s','UnbalancedShortcut'),(3,1,'LastPlayDate','f','20210728'),(4,1,'CTRLTYPE_RESET_EXCEPT','f','1'),(5,1,'MaxWarehouseCount','f','2000'),(6,1,'CompanionAutoAtk','f','0'),(7,1,'HAT_Visible','f','1'),(8,1,'HAT_T_Visible','f','1'),(9,1,'HAT_L_Visible','f','1'),(10,1,'HAIR_WIG_Visible','f','1'),(11,1,'InDunCountType_100','f','0'),(12,1,'InDunCountType_200','f','0'),(13,1,'InDunCountType_0','f','0'),(14,1,'InDunCountType_400','f','0'),(15,1,'InDunCountType_300','f','0'),(16,1,'InDunCountType_500','f','0'),(17,1,'InDunCountType_600','f','0'),(18,1,'InDunCountType_700','f','0'),(19,1,'InDunCountType_10000','f','0'),(20,1,'InDunCountType_900','f','0'),(21,1,'InDunCountType_1200','f','0'),(22,1,'InDunCountType_1100','f','0'),(23,1,'InDunCountType_8003','f','0'),(24,1,'InDunCountType_2','f','0'),(25,1,'InDunCountType_8000','f','0'),(26,1,'Indun_ResetTime','s','202604625081405'),(27,1,'IndunWeeklyResetTime','s','202604524210144'),(28,1,'FirstPlay','f','0'),(532,3,'SkintoneName','s','skintone2'),(533,3,'StartHairName','s','UnbalancedShortcut'),(534,3,'LastPlayDate','f','20210728'),(535,3,'CTRLTYPE_RESET_EXCEPT','f','1'),(536,3,'MaxWarehouseCount','f','2000'),(537,3,'CompanionAutoAtk','f','0'),(538,3,'HAT_Visible','f','1'),(539,3,'HAT_T_Visible','f','1'),(540,3,'HAT_L_Visible','f','1'),(541,3,'HAIR_WIG_Visible','f','1'),(542,3,'InDunCountType_100','f','0'),(543,3,'InDunCountType_200','f','0'),(544,3,'InDunCountType_0','f','0'),(545,3,'InDunCountType_400','f','0'),(546,3,'InDunCountType_300','f','0'),(547,3,'InDunCountType_500','f','0'),(548,3,'InDunCountType_600','f','0'),(549,3,'InDunCountType_700','f','0'),(550,3,'InDunCountType_10000','f','0'),(551,3,'InDunCountType_900','f','0'),(552,3,'InDunCountType_1200','f','0'),(553,3,'InDunCountType_1100','f','0'),(554,3,'InDunCountType_8003','f','0'),(555,3,'InDunCountType_2','f','0'),(556,3,'InDunCountType_8000','f','0'),(557,3,'Indun_ResetTime','s','202604625093923'),(558,3,'IndunWeeklyResetTime','s','202604625093923'),(559,3,'FirstPlay','f','0'),(616,4,'SkintoneName','s','skintone2'),(617,4,'StartHairName','s','UnbalancedShortcut'),(618,4,'LastPlayDate','f','20210728'),(619,4,'CTRLTYPE_RESET_EXCEPT','f','1'),(620,4,'MaxWarehouseCount','f','2000'),(621,4,'CompanionAutoAtk','f','0'),(622,4,'HAT_Visible','f','1'),(623,4,'HAT_T_Visible','f','1'),(624,4,'HAT_L_Visible','f','1'),(625,4,'HAIR_WIG_Visible','f','1'),(626,4,'InDunCountType_100','f','0'),(627,4,'InDunCountType_200','f','0'),(628,4,'InDunCountType_0','f','0'),(629,4,'InDunCountType_400','f','0'),(630,4,'InDunCountType_300','f','0'),(631,4,'InDunCountType_500','f','0'),(632,4,'InDunCountType_600','f','0'),(633,4,'InDunCountType_700','f','0'),(634,4,'InDunCountType_10000','f','0'),(635,4,'InDunCountType_900','f','0'),(636,4,'InDunCountType_1200','f','0'),(637,4,'InDunCountType_1100','f','0'),(638,4,'InDunCountType_8003','f','0'),(639,4,'InDunCountType_2','f','0'),(640,4,'InDunCountType_8000','f','0'),(641,4,'Indun_ResetTime','s','202604625100016'),(642,4,'IndunWeeklyResetTime','s','202604625100016'),(643,4,'FirstPlay','f','0'),(700,5,'SkintoneName','s','skintone2'),(701,5,'StartHairName','s','UnbalancedShortcut'),(702,5,'LastPlayDate','f','20210728'),(703,5,'CTRLTYPE_RESET_EXCEPT','f','1'),(704,5,'MaxWarehouseCount','f','2000'),(705,5,'CompanionAutoAtk','f','0'),(706,5,'HAT_Visible','f','1'),(707,5,'HAT_T_Visible','f','1'),(708,5,'HAT_L_Visible','f','1'),(709,5,'HAIR_WIG_Visible','f','1'),(710,5,'InDunCountType_100','f','0'),(711,5,'InDunCountType_200','f','0'),(712,5,'InDunCountType_0','f','0'),(713,5,'InDunCountType_400','f','0'),(714,5,'InDunCountType_300','f','0'),(715,5,'InDunCountType_500','f','0'),(716,5,'InDunCountType_600','f','0'),(717,5,'InDunCountType_700','f','0'),(718,5,'InDunCountType_10000','f','0'),(719,5,'InDunCountType_900','f','0'),(720,5,'InDunCountType_1200','f','0'),(721,5,'InDunCountType_1100','f','0'),(722,5,'InDunCountType_8003','f','0'),(723,5,'InDunCountType_2','f','0'),(724,5,'InDunCountType_8000','f','0'),(725,5,'Indun_ResetTime','s','202604625103259'),(726,5,'IndunWeeklyResetTime','s','202604625103259'),(727,5,'FirstPlay','f','0'),(756,6,'SkintoneName','s','skintone2'),(757,6,'StartHairName','s','UnbalancedShortcut'),(758,6,'LastPlayDate','f','20210728'),(759,6,'CTRLTYPE_RESET_EXCEPT','f','1'),(760,6,'MaxWarehouseCount','f','2000'),(761,6,'CompanionAutoAtk','f','0'),(762,6,'HAT_Visible','f','1'),(763,6,'HAT_T_Visible','f','1'),(764,6,'HAT_L_Visible','f','1'),(765,6,'HAIR_WIG_Visible','f','1'),(766,6,'InDunCountType_100','f','0'),(767,6,'InDunCountType_200','f','0'),(768,6,'InDunCountType_0','f','0'),(769,6,'InDunCountType_400','f','0'),(770,6,'InDunCountType_300','f','0'),(771,6,'InDunCountType_500','f','0'),(772,6,'InDunCountType_600','f','0'),(773,6,'InDunCountType_700','f','0'),(774,6,'InDunCountType_10000','f','0'),(775,6,'InDunCountType_900','f','0'),(776,6,'InDunCountType_1200','f','0'),(777,6,'InDunCountType_1100','f','0'),(778,6,'InDunCountType_8003','f','0'),(779,6,'InDunCountType_2','f','0'),(780,6,'InDunCountType_8000','f','0'),(781,6,'Indun_ResetTime','s','202604625105541'),(782,6,'IndunWeeklyResetTime','s','202604625105541'),(783,6,'FirstPlay','f','0'),(784,6,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(843,8,'SkintoneName','s','skintone2'),(844,8,'StartHairName','s','UnbalancedShortcut'),(845,8,'LastPlayDate','f','20210728'),(846,8,'CTRLTYPE_RESET_EXCEPT','f','1'),(847,8,'MaxWarehouseCount','f','2000'),(848,8,'CompanionAutoAtk','f','0'),(849,8,'HAT_Visible','f','1'),(850,8,'HAT_T_Visible','f','1'),(851,8,'HAT_L_Visible','f','1'),(852,8,'HAIR_WIG_Visible','f','1'),(853,8,'InDunCountType_100','f','0'),(854,8,'InDunCountType_200','f','0'),(855,8,'InDunCountType_0','f','0'),(856,8,'InDunCountType_400','f','0'),(857,8,'InDunCountType_300','f','0'),(858,8,'InDunCountType_500','f','0'),(859,8,'InDunCountType_600','f','0'),(860,8,'InDunCountType_700','f','0'),(861,8,'InDunCountType_10000','f','0'),(862,8,'InDunCountType_900','f','0'),(863,8,'InDunCountType_1200','f','0'),(864,8,'InDunCountType_1100','f','0'),(865,8,'InDunCountType_8003','f','0'),(866,8,'InDunCountType_2','f','0'),(867,8,'InDunCountType_8000','f','0'),(868,8,'Indun_ResetTime','s','202604625113555'),(869,8,'IndunWeeklyResetTime','s','202604625113555'),(870,8,'FirstPlay','f','0'),(871,8,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(930,9,'SkintoneName','s','skintone2'),(931,9,'StartHairName','s','UnbalancedShortcut'),(932,9,'LastPlayDate','f','20210728'),(933,9,'CTRLTYPE_RESET_EXCEPT','f','1'),(934,9,'MaxWarehouseCount','f','2000'),(935,9,'CompanionAutoAtk','f','0'),(936,9,'HAT_Visible','f','1'),(937,9,'HAT_T_Visible','f','1'),(938,9,'HAT_L_Visible','f','1'),(939,9,'HAIR_WIG_Visible','f','1'),(940,9,'InDunCountType_100','f','0'),(941,9,'InDunCountType_200','f','0'),(942,9,'InDunCountType_0','f','0'),(943,9,'InDunCountType_400','f','0'),(944,9,'InDunCountType_300','f','0'),(945,9,'InDunCountType_500','f','0'),(946,9,'InDunCountType_600','f','0'),(947,9,'InDunCountType_700','f','0'),(948,9,'InDunCountType_10000','f','0'),(949,9,'InDunCountType_900','f','0'),(950,9,'InDunCountType_1200','f','0'),(951,9,'InDunCountType_1100','f','0'),(952,9,'InDunCountType_8003','f','0'),(953,9,'InDunCountType_2','f','0'),(954,9,'InDunCountType_8000','f','0'),(955,9,'Indun_ResetTime','s','202604625115238'),(956,9,'IndunWeeklyResetTime','s','202604625115238'),(957,9,'FirstPlay','f','0'),(958,9,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(988,10,'SkintoneName','s','skintone2'),(989,10,'StartHairName','s','UnbalancedShortcut'),(990,10,'LastPlayDate','f','20210728'),(991,10,'CTRLTYPE_RESET_EXCEPT','f','1'),(992,10,'MaxWarehouseCount','f','2000'),(993,10,'CompanionAutoAtk','f','0'),(994,10,'HAT_Visible','f','1'),(995,10,'HAT_T_Visible','f','1'),(996,10,'HAT_L_Visible','f','1'),(997,10,'HAIR_WIG_Visible','f','1'),(998,10,'InDunCountType_100','f','0'),(999,10,'InDunCountType_200','f','0'),(1000,10,'InDunCountType_0','f','0'),(1001,10,'InDunCountType_400','f','0'),(1002,10,'InDunCountType_300','f','0'),(1003,10,'InDunCountType_500','f','0'),(1004,10,'InDunCountType_600','f','0'),(1005,10,'InDunCountType_700','f','0'),(1006,10,'InDunCountType_10000','f','0'),(1007,10,'InDunCountType_900','f','0'),(1008,10,'InDunCountType_1200','f','0'),(1009,10,'InDunCountType_1100','f','0'),(1010,10,'InDunCountType_8003','f','0'),(1011,10,'InDunCountType_2','f','0'),(1012,10,'InDunCountType_8000','f','0'),(1013,10,'Indun_ResetTime','s','202604625122921'),(1014,10,'IndunWeeklyResetTime','s','202604625122921'),(1015,10,'FirstPlay','f','0'),(1016,10,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1046,11,'SkintoneName','s','skintone2'),(1047,11,'StartHairName','s','UnbalancedShortcut'),(1048,11,'LastPlayDate','f','20210728'),(1049,11,'CTRLTYPE_RESET_EXCEPT','f','1'),(1050,11,'MaxWarehouseCount','f','2000'),(1051,11,'CompanionAutoAtk','f','0'),(1052,11,'HAT_Visible','f','1'),(1053,11,'HAT_T_Visible','f','1'),(1054,11,'HAT_L_Visible','f','1'),(1055,11,'HAIR_WIG_Visible','f','1'),(1056,11,'InDunCountType_100','f','0'),(1057,11,'InDunCountType_200','f','0'),(1058,11,'InDunCountType_0','f','0'),(1059,11,'InDunCountType_400','f','0'),(1060,11,'InDunCountType_300','f','0'),(1061,11,'InDunCountType_500','f','0'),(1062,11,'InDunCountType_600','f','0'),(1063,11,'InDunCountType_700','f','0'),(1064,11,'InDunCountType_10000','f','0'),(1065,11,'InDunCountType_900','f','0'),(1066,11,'InDunCountType_1200','f','0'),(1067,11,'InDunCountType_1100','f','0'),(1068,11,'InDunCountType_8003','f','0'),(1069,11,'InDunCountType_2','f','0'),(1070,11,'InDunCountType_8000','f','0'),(1071,11,'Indun_ResetTime','s','202604625124329'),(1072,11,'IndunWeeklyResetTime','s','202604625124329'),(1073,11,'FirstPlay','f','0'),(1074,11,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1075,12,'SkintoneName','s','skintone2'),(1076,12,'StartHairName','s','UnbalancedShortcut'),(1077,12,'LastPlayDate','f','20210728'),(1078,12,'CTRLTYPE_RESET_EXCEPT','f','1'),(1079,12,'MaxWarehouseCount','f','2000'),(1080,12,'CompanionAutoAtk','f','0'),(1081,12,'HAT_Visible','f','1'),(1082,12,'HAT_T_Visible','f','1'),(1083,12,'HAT_L_Visible','f','1'),(1084,12,'HAIR_WIG_Visible','f','1'),(1085,12,'InDunCountType_100','f','0'),(1086,12,'InDunCountType_200','f','0'),(1087,12,'InDunCountType_0','f','0'),(1088,12,'InDunCountType_400','f','0'),(1089,12,'InDunCountType_300','f','0'),(1090,12,'InDunCountType_500','f','0'),(1091,12,'InDunCountType_600','f','0'),(1092,12,'InDunCountType_700','f','0'),(1093,12,'InDunCountType_10000','f','0'),(1094,12,'InDunCountType_900','f','0'),(1095,12,'InDunCountType_1200','f','0'),(1096,12,'InDunCountType_1100','f','0'),(1097,12,'InDunCountType_8003','f','0'),(1098,12,'InDunCountType_2','f','0'),(1099,12,'InDunCountType_8000','f','0'),(1100,12,'Indun_ResetTime','s','202604625130216'),(1101,12,'IndunWeeklyResetTime','s','202604625130216'),(1102,12,'FirstPlay','f','0'),(1103,13,'SkintoneName','s','skintone2'),(1104,13,'StartHairName','s','UnbalancedShortcut'),(1105,13,'LastPlayDate','f','20210728'),(1106,13,'CTRLTYPE_RESET_EXCEPT','f','1'),(1107,13,'MaxWarehouseCount','f','2000'),(1108,13,'CompanionAutoAtk','f','0'),(1109,13,'HAT_Visible','f','1'),(1110,13,'HAT_T_Visible','f','1'),(1111,13,'HAT_L_Visible','f','1'),(1112,13,'HAIR_WIG_Visible','f','1'),(1113,13,'InDunCountType_100','f','0'),(1114,13,'InDunCountType_200','f','0'),(1115,13,'InDunCountType_0','f','0'),(1116,13,'InDunCountType_400','f','0'),(1117,13,'InDunCountType_300','f','0'),(1118,13,'InDunCountType_500','f','0'),(1119,13,'InDunCountType_600','f','0'),(1120,13,'InDunCountType_700','f','0'),(1121,13,'InDunCountType_10000','f','0'),(1122,13,'InDunCountType_900','f','0'),(1123,13,'InDunCountType_1200','f','0'),(1124,13,'InDunCountType_1100','f','0'),(1125,13,'InDunCountType_8003','f','0'),(1126,13,'InDunCountType_2','f','0'),(1127,13,'InDunCountType_8000','f','0'),(1128,13,'Indun_ResetTime','s','202604625132327'),(1129,13,'IndunWeeklyResetTime','s','202604625132327'),(1130,13,'FirstPlay','f','0'),(1131,13,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1132,14,'SkintoneName','s','skintone2'),(1133,14,'StartHairName','s','UnbalancedShortcut'),(1134,14,'LastPlayDate','f','20210728'),(1135,14,'CTRLTYPE_RESET_EXCEPT','f','1'),(1136,14,'MaxWarehouseCount','f','2000'),(1137,14,'CompanionAutoAtk','f','0'),(1138,14,'HAT_Visible','f','1'),(1139,14,'HAT_T_Visible','f','1'),(1140,14,'HAT_L_Visible','f','1'),(1141,14,'HAIR_WIG_Visible','f','1'),(1142,14,'InDunCountType_100','f','0'),(1143,14,'InDunCountType_200','f','0'),(1144,14,'InDunCountType_0','f','0'),(1145,14,'InDunCountType_400','f','0'),(1146,14,'InDunCountType_300','f','0'),(1147,14,'InDunCountType_500','f','0'),(1148,14,'InDunCountType_600','f','0'),(1149,14,'InDunCountType_700','f','0'),(1150,14,'InDunCountType_10000','f','0'),(1151,14,'InDunCountType_900','f','0'),(1152,14,'InDunCountType_1200','f','0'),(1153,14,'InDunCountType_1100','f','0'),(1154,14,'InDunCountType_8003','f','0'),(1155,14,'InDunCountType_2','f','0'),(1156,14,'InDunCountType_8000','f','0'),(1157,14,'Indun_ResetTime','s','202604625133311'),(1158,14,'IndunWeeklyResetTime','s','202604625133311'),(1159,14,'FirstPlay','f','0'),(1160,14,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1190,15,'SkintoneName','s','skintone2'),(1191,15,'StartHairName','s','UnbalancedShortcut'),(1192,15,'LastPlayDate','f','20210728'),(1193,15,'CTRLTYPE_RESET_EXCEPT','f','1'),(1194,15,'MaxWarehouseCount','f','2000'),(1195,15,'CompanionAutoAtk','f','0'),(1196,15,'HAT_Visible','f','1'),(1197,15,'HAT_T_Visible','f','1'),(1198,15,'HAT_L_Visible','f','1'),(1199,15,'HAIR_WIG_Visible','f','1'),(1200,15,'InDunCountType_100','f','0'),(1201,15,'InDunCountType_200','f','0'),(1202,15,'InDunCountType_0','f','0'),(1203,15,'InDunCountType_400','f','0'),(1204,15,'InDunCountType_300','f','0'),(1205,15,'InDunCountType_500','f','0'),(1206,15,'InDunCountType_600','f','0'),(1207,15,'InDunCountType_700','f','0'),(1208,15,'InDunCountType_10000','f','0'),(1209,15,'InDunCountType_900','f','0'),(1210,15,'InDunCountType_1200','f','0'),(1211,15,'InDunCountType_1100','f','0'),(1212,15,'InDunCountType_8003','f','0'),(1213,15,'InDunCountType_2','f','0'),(1214,15,'InDunCountType_8000','f','0'),(1215,15,'Indun_ResetTime','s','202604625141304'),(1216,15,'IndunWeeklyResetTime','s','202604625141304'),(1217,15,'FirstPlay','f','0'),(1218,15,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1248,16,'SkintoneName','s','skintone2'),(1249,16,'StartHairName','s','UnbalancedShortcut'),(1250,16,'LastPlayDate','f','20210728'),(1251,16,'CTRLTYPE_RESET_EXCEPT','f','1'),(1252,16,'MaxWarehouseCount','f','2000'),(1253,16,'CompanionAutoAtk','f','0'),(1254,16,'HAT_Visible','f','1'),(1255,16,'HAT_T_Visible','f','1'),(1256,16,'HAT_L_Visible','f','1'),(1257,16,'HAIR_WIG_Visible','f','1'),(1258,16,'InDunCountType_100','f','0'),(1259,16,'InDunCountType_200','f','0'),(1260,16,'InDunCountType_0','f','0'),(1261,16,'InDunCountType_400','f','0'),(1262,16,'InDunCountType_300','f','0'),(1263,16,'InDunCountType_500','f','0'),(1264,16,'InDunCountType_600','f','0'),(1265,16,'InDunCountType_700','f','0'),(1266,16,'InDunCountType_10000','f','0'),(1267,16,'InDunCountType_900','f','0'),(1268,16,'InDunCountType_1200','f','0'),(1269,16,'InDunCountType_1100','f','0'),(1270,16,'InDunCountType_8003','f','0'),(1271,16,'InDunCountType_2','f','0'),(1272,16,'InDunCountType_8000','f','0'),(1273,16,'Indun_ResetTime','s','202604625145357'),(1274,16,'IndunWeeklyResetTime','s','202604625145357'),(1275,16,'FirstPlay','f','0'),(1276,16,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1306,17,'SkintoneName','s','skintone2'),(1307,17,'StartHairName','s','UnbalancedShortcut'),(1308,17,'LastPlayDate','f','20210728'),(1309,17,'CTRLTYPE_RESET_EXCEPT','f','1'),(1310,17,'MaxWarehouseCount','f','2000'),(1311,17,'CompanionAutoAtk','f','0'),(1312,17,'HAT_Visible','f','1'),(1313,17,'HAT_T_Visible','f','1'),(1314,17,'HAT_L_Visible','f','1'),(1315,17,'HAIR_WIG_Visible','f','1'),(1316,17,'InDunCountType_100','f','0'),(1317,17,'InDunCountType_200','f','0'),(1318,17,'InDunCountType_0','f','0'),(1319,17,'InDunCountType_400','f','0'),(1320,17,'InDunCountType_300','f','0'),(1321,17,'InDunCountType_500','f','0'),(1322,17,'InDunCountType_600','f','0'),(1323,17,'InDunCountType_700','f','0'),(1324,17,'InDunCountType_10000','f','0'),(1325,17,'InDunCountType_900','f','0'),(1326,17,'InDunCountType_1200','f','0'),(1327,17,'InDunCountType_1100','f','0'),(1328,17,'InDunCountType_8003','f','0'),(1329,17,'InDunCountType_2','f','0'),(1330,17,'InDunCountType_8000','f','0'),(1331,17,'Indun_ResetTime','s','202604625152358'),(1332,17,'IndunWeeklyResetTime','s','202604625152358'),(1333,17,'FirstPlay','f','0'),(1334,17,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1364,18,'SkintoneName','s','skintone2'),(1365,18,'StartHairName','s','UnbalancedShortcut'),(1366,18,'LastPlayDate','f','20210728'),(1367,18,'CTRLTYPE_RESET_EXCEPT','f','1'),(1368,18,'MaxWarehouseCount','f','2000'),(1369,18,'CompanionAutoAtk','f','0'),(1370,18,'HAT_Visible','f','1'),(1371,18,'HAT_T_Visible','f','1'),(1372,18,'HAT_L_Visible','f','1'),(1373,18,'HAIR_WIG_Visible','f','1'),(1374,18,'InDunCountType_100','f','0'),(1375,18,'InDunCountType_200','f','0'),(1376,18,'InDunCountType_0','f','0'),(1377,18,'InDunCountType_400','f','0'),(1378,18,'InDunCountType_300','f','0'),(1379,18,'InDunCountType_500','f','0'),(1380,18,'InDunCountType_600','f','0'),(1381,18,'InDunCountType_700','f','0'),(1382,18,'InDunCountType_10000','f','0'),(1383,18,'InDunCountType_900','f','0'),(1384,18,'InDunCountType_1200','f','0'),(1385,18,'InDunCountType_1100','f','0'),(1386,18,'InDunCountType_8003','f','0'),(1387,18,'InDunCountType_2','f','0'),(1388,18,'InDunCountType_8000','f','0'),(1389,18,'Indun_ResetTime','s','202604625154712'),(1390,18,'IndunWeeklyResetTime','s','202604625154712'),(1391,18,'FirstPlay','f','0'),(1392,18,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1393,19,'SkintoneName','s','skintone2'),(1394,19,'StartHairName','s','UnbalancedShortcut'),(1395,19,'LastPlayDate','f','20210728'),(1396,19,'CTRLTYPE_RESET_EXCEPT','f','1'),(1397,19,'MaxWarehouseCount','f','2000'),(1398,19,'CompanionAutoAtk','f','0'),(1399,19,'HAT_Visible','f','1'),(1400,19,'HAT_T_Visible','f','1'),(1401,19,'HAT_L_Visible','f','1'),(1402,19,'HAIR_WIG_Visible','f','1'),(1403,19,'InDunCountType_100','f','0'),(1404,19,'InDunCountType_200','f','0'),(1405,19,'InDunCountType_0','f','0'),(1406,19,'InDunCountType_400','f','0'),(1407,19,'InDunCountType_300','f','0'),(1408,19,'InDunCountType_500','f','0'),(1409,19,'InDunCountType_600','f','0'),(1410,19,'InDunCountType_700','f','0'),(1411,19,'InDunCountType_10000','f','0'),(1412,19,'InDunCountType_900','f','0'),(1413,19,'InDunCountType_1200','f','0'),(1414,19,'InDunCountType_1100','f','0'),(1415,19,'InDunCountType_8003','f','0'),(1416,19,'InDunCountType_2','f','0'),(1417,19,'InDunCountType_8000','f','0'),(1418,19,'Indun_ResetTime','s','202604625161721'),(1419,19,'IndunWeeklyResetTime','s','202604625161721'),(1420,19,'FirstPlay','f','0'),(1421,19,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1480,20,'SkintoneName','s','skintone2'),(1481,20,'StartHairName','s','UnbalancedShortcut'),(1482,20,'LastPlayDate','f','20210728'),(1483,20,'CTRLTYPE_RESET_EXCEPT','f','1'),(1484,20,'MaxWarehouseCount','f','2000'),(1485,20,'CompanionAutoAtk','f','0'),(1486,20,'HAT_Visible','f','1'),(1487,20,'HAT_T_Visible','f','1'),(1488,20,'HAT_L_Visible','f','1'),(1489,20,'HAIR_WIG_Visible','f','1'),(1490,20,'InDunCountType_100','f','0'),(1491,20,'InDunCountType_200','f','0'),(1492,20,'InDunCountType_0','f','0'),(1493,20,'InDunCountType_400','f','0'),(1494,20,'InDunCountType_300','f','0'),(1495,20,'InDunCountType_500','f','0'),(1496,20,'InDunCountType_600','f','0'),(1497,20,'InDunCountType_700','f','0'),(1498,20,'InDunCountType_10000','f','0'),(1499,20,'InDunCountType_900','f','0'),(1500,20,'InDunCountType_1200','f','0'),(1501,20,'InDunCountType_1100','f','0'),(1502,20,'InDunCountType_8003','f','0'),(1503,20,'InDunCountType_2','f','0'),(1504,20,'InDunCountType_8000','f','0'),(1505,20,'Indun_ResetTime','s','202604625165615'),(1506,20,'IndunWeeklyResetTime','s','202604625165615'),(1507,20,'FirstPlay','f','0'),(1508,20,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1538,4,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1596,21,'SkintoneName','s','skintone2'),(1597,21,'StartHairName','s','UnbalancedShortcut'),(1598,21,'LastPlayDate','f','20210728'),(1599,21,'CTRLTYPE_RESET_EXCEPT','f','1'),(1600,21,'MaxWarehouseCount','f','2000'),(1601,21,'CompanionAutoAtk','f','0'),(1602,21,'HAT_Visible','f','1'),(1603,21,'HAT_T_Visible','f','1'),(1604,21,'HAT_L_Visible','f','1'),(1605,21,'HAIR_WIG_Visible','f','1'),(1606,21,'InDunCountType_100','f','0'),(1607,21,'InDunCountType_200','f','0'),(1608,21,'InDunCountType_0','f','0'),(1609,21,'InDunCountType_400','f','0'),(1610,21,'InDunCountType_300','f','0'),(1611,21,'InDunCountType_500','f','0'),(1612,21,'InDunCountType_600','f','0'),(1613,21,'InDunCountType_700','f','0'),(1614,21,'InDunCountType_10000','f','0'),(1615,21,'InDunCountType_900','f','0'),(1616,21,'InDunCountType_1200','f','0'),(1617,21,'InDunCountType_1100','f','0'),(1618,21,'InDunCountType_8003','f','0'),(1619,21,'InDunCountType_2','f','0'),(1620,21,'InDunCountType_8000','f','0'),(1621,21,'Indun_ResetTime','s','202604625181208'),(1622,21,'IndunWeeklyResetTime','s','202604625181208'),(1623,21,'FirstPlay','f','0'),(1624,21,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1625,22,'SkintoneName','s','skintone2'),(1626,22,'StartHairName','s','UnbalancedShortcut'),(1627,22,'LastPlayDate','f','20210728'),(1628,22,'CTRLTYPE_RESET_EXCEPT','f','1'),(1629,22,'MaxWarehouseCount','f','2000'),(1630,22,'CompanionAutoAtk','f','0'),(1631,22,'HAT_Visible','f','1'),(1632,22,'HAT_T_Visible','f','1'),(1633,22,'HAT_L_Visible','f','1'),(1634,22,'HAIR_WIG_Visible','f','1'),(1635,22,'InDunCountType_100','f','0'),(1636,22,'InDunCountType_200','f','0'),(1637,22,'InDunCountType_0','f','0'),(1638,22,'InDunCountType_400','f','0'),(1639,22,'InDunCountType_300','f','0'),(1640,22,'InDunCountType_500','f','0'),(1641,22,'InDunCountType_600','f','0'),(1642,22,'InDunCountType_700','f','0'),(1643,22,'InDunCountType_10000','f','0'),(1644,22,'InDunCountType_900','f','0'),(1645,22,'InDunCountType_1200','f','0'),(1646,22,'InDunCountType_1100','f','0'),(1647,22,'InDunCountType_8003','f','0'),(1648,22,'InDunCountType_2','f','0'),(1649,22,'InDunCountType_8000','f','0'),(1650,22,'Indun_ResetTime','s','202604625182149'),(1651,22,'IndunWeeklyResetTime','s','202604625182149'),(1652,22,'FirstPlay','f','0'),(1653,22,'SIAUL_WEST_MEET_TITAS_TRACK','f','1'),(1683,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1');
/*!40000 ALTER TABLE `character_etc_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_etc_properties_log`
--

DROP TABLE IF EXISTS `character_etc_properties_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_etc_properties_log` (
  `logId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(1) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  `backupTimestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `backupReason` varchar(50) DEFAULT 'pre_save',
  PRIMARY KEY (`logId`),
  KEY `idx_itemId_timestamp` (`characterId`,`backupTimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_etc_properties_log`
--

LOCK TABLES `character_etc_properties_log` WRITE;
/*!40000 ALTER TABLE `character_etc_properties_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_etc_properties_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_properties`
--

DROP TABLE IF EXISTS `character_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_properties` (
  `propertyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(1) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`propertyId`),
  UNIQUE KEY `uk_character_property` (`characterId`,`name`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `character_properties_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `character_properties_ibfk_2` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1657 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_properties`
--

LOCK TABLES `character_properties` WRITE;
/*!40000 ALTER TABLE `character_properties` DISABLE KEYS */;
INSERT INTO `character_properties` VALUES (1,1,'Lv','f','1'),(2,1,'HP','f','405'),(3,1,'SP','f','207'),(4,1,'StatByLevel','f','0'),(5,1,'StatByBonus','f','0'),(6,1,'UsedStat','f','0'),(7,1,'AbilityPoint','s','0'),(8,1,'STR_STAT','f','0'),(9,1,'CON_STAT','f','0'),(10,1,'INT_STAT','f','0'),(11,1,'MNA_STAT','f','0'),(12,1,'DEX_STAT','f','0'),(13,1,'STR_Bonus','f','0'),(14,1,'CON_Bonus','f','0'),(15,1,'INT_Bonus','f','0'),(16,1,'MNA_Bonus','f','0'),(17,1,'DEX_Bonus','f','0'),(18,1,'MHP_Bonus','f','0'),(19,1,'MSP_Bonus','f','0'),(20,1,'MSPD_Bonus','f','0'),(21,1,'MAXSTA_Bonus','f','0'),(22,1,'DashRun','f','0'),(23,1,'MaxWeight_Bonus','f','0'),(438,3,'Lv','f','1'),(439,3,'HP','f','367'),(440,3,'SP','f','465'),(441,3,'StatByLevel','f','0'),(442,3,'StatByBonus','f','0'),(443,3,'UsedStat','f','0'),(444,3,'AbilityPoint','s','0'),(445,3,'STR_STAT','f','0'),(446,3,'CON_STAT','f','0'),(447,3,'INT_STAT','f','0'),(448,3,'MNA_STAT','f','0'),(449,3,'DEX_STAT','f','0'),(450,3,'STR_Bonus','f','0'),(451,3,'CON_Bonus','f','0'),(452,3,'INT_Bonus','f','0'),(453,3,'MNA_Bonus','f','0'),(454,3,'DEX_Bonus','f','0'),(455,3,'MHP_Bonus','f','0'),(456,3,'MSP_Bonus','f','0'),(457,3,'MSPD_Bonus','f','0'),(458,3,'MAXSTA_Bonus','f','0'),(459,3,'DashRun','f','0'),(460,3,'MaxWeight_Bonus','f','0'),(507,4,'Lv','f','1'),(508,4,'HP','f','109'),(509,4,'SP','f','207'),(510,4,'StatByLevel','f','0'),(511,4,'StatByBonus','f','0'),(512,4,'UsedStat','f','0'),(513,4,'AbilityPoint','s','0'),(514,4,'STR_STAT','f','0'),(515,4,'CON_STAT','f','0'),(516,4,'INT_STAT','f','0'),(517,4,'MNA_STAT','f','0'),(518,4,'DEX_STAT','f','0'),(519,4,'STR_Bonus','f','0'),(520,4,'CON_Bonus','f','0'),(521,4,'INT_Bonus','f','0'),(522,4,'MNA_Bonus','f','0'),(523,4,'DEX_Bonus','f','0'),(524,4,'MHP_Bonus','f','0'),(525,4,'MSP_Bonus','f','0'),(526,4,'MSPD_Bonus','f','0'),(527,4,'MAXSTA_Bonus','f','0'),(528,4,'DashRun','f','0'),(529,4,'MaxWeight_Bonus','f','0'),(576,5,'Lv','f','1'),(577,5,'HP','f','438'),(578,5,'SP','f','460'),(579,5,'StatByLevel','f','0'),(580,5,'StatByBonus','f','0'),(581,5,'UsedStat','f','0'),(582,5,'AbilityPoint','s','0'),(583,5,'STR_STAT','f','0'),(584,5,'CON_STAT','f','0'),(585,5,'INT_STAT','f','0'),(586,5,'MNA_STAT','f','0'),(587,5,'DEX_STAT','f','0'),(588,5,'STR_Bonus','f','0'),(589,5,'CON_Bonus','f','0'),(590,5,'INT_Bonus','f','0'),(591,5,'MNA_Bonus','f','0'),(592,5,'DEX_Bonus','f','0'),(593,5,'MHP_Bonus','f','0'),(594,5,'MSP_Bonus','f','0'),(595,5,'MSPD_Bonus','f','0'),(596,5,'MAXSTA_Bonus','f','0'),(597,5,'DashRun','f','0'),(598,5,'MaxWeight_Bonus','f','0'),(622,6,'Lv','f','1'),(623,6,'HP','f','467'),(624,6,'SP','f','207'),(625,6,'StatByLevel','f','0'),(626,6,'StatByBonus','f','0'),(627,6,'UsedStat','f','0'),(628,6,'AbilityPoint','s','0'),(629,6,'STR_STAT','f','0'),(630,6,'CON_STAT','f','0'),(631,6,'INT_STAT','f','0'),(632,6,'MNA_STAT','f','0'),(633,6,'DEX_STAT','f','0'),(634,6,'STR_Bonus','f','0'),(635,6,'CON_Bonus','f','0'),(636,6,'INT_Bonus','f','0'),(637,6,'MNA_Bonus','f','0'),(638,6,'DEX_Bonus','f','0'),(639,6,'MHP_Bonus','f','0'),(640,6,'MSP_Bonus','f','0'),(641,6,'MSPD_Bonus','f','0'),(642,6,'MAXSTA_Bonus','f','0'),(643,6,'DashRun','f','0'),(644,6,'MaxWeight_Bonus','f','0'),(691,8,'Lv','f','1'),(692,8,'HP','f','122.25'),(693,8,'SP','f','207'),(694,8,'StatByLevel','f','0'),(695,8,'StatByBonus','f','0'),(696,8,'UsedStat','f','0'),(697,8,'AbilityPoint','s','0'),(698,8,'STR_STAT','f','0'),(699,8,'CON_STAT','f','0'),(700,8,'INT_STAT','f','0'),(701,8,'MNA_STAT','f','0'),(702,8,'DEX_STAT','f','0'),(703,8,'STR_Bonus','f','0'),(704,8,'CON_Bonus','f','0'),(705,8,'INT_Bonus','f','0'),(706,8,'MNA_Bonus','f','0'),(707,8,'DEX_Bonus','f','0'),(708,8,'MHP_Bonus','f','0'),(709,8,'MSP_Bonus','f','0'),(710,8,'MSPD_Bonus','f','0'),(711,8,'MAXSTA_Bonus','f','0'),(712,8,'DashRun','f','0'),(713,8,'MaxWeight_Bonus','f','0'),(760,9,'Lv','f','1'),(761,9,'HP','f','367'),(762,9,'SP','f','465'),(763,9,'StatByLevel','f','0'),(764,9,'StatByBonus','f','0'),(765,9,'UsedStat','f','0'),(766,9,'AbilityPoint','s','0'),(767,9,'STR_STAT','f','0'),(768,9,'CON_STAT','f','0'),(769,9,'INT_STAT','f','0'),(770,9,'MNA_STAT','f','0'),(771,9,'DEX_STAT','f','0'),(772,9,'STR_Bonus','f','0'),(773,9,'CON_Bonus','f','0'),(774,9,'INT_Bonus','f','0'),(775,9,'MNA_Bonus','f','0'),(776,9,'DEX_Bonus','f','0'),(777,9,'MHP_Bonus','f','0'),(778,9,'MSP_Bonus','f','0'),(779,9,'MSPD_Bonus','f','0'),(780,9,'MAXSTA_Bonus','f','0'),(781,9,'DashRun','f','0'),(782,9,'MaxWeight_Bonus','f','0'),(806,10,'Lv','f','1'),(807,10,'HP','f','106.75'),(808,10,'SP','f','465'),(809,10,'StatByLevel','f','0'),(810,10,'StatByBonus','f','0'),(811,10,'UsedStat','f','0'),(812,10,'AbilityPoint','s','0'),(813,10,'STR_STAT','f','0'),(814,10,'CON_STAT','f','0'),(815,10,'INT_STAT','f','0'),(816,10,'MNA_STAT','f','0'),(817,10,'DEX_STAT','f','0'),(818,10,'STR_Bonus','f','0'),(819,10,'CON_Bonus','f','0'),(820,10,'INT_Bonus','f','0'),(821,10,'MNA_Bonus','f','0'),(822,10,'DEX_Bonus','f','0'),(823,10,'MHP_Bonus','f','0'),(824,10,'MSP_Bonus','f','0'),(825,10,'MSPD_Bonus','f','0'),(826,10,'MAXSTA_Bonus','f','0'),(827,10,'DashRun','f','0'),(828,10,'MaxWeight_Bonus','f','0'),(852,11,'Lv','f','1'),(853,11,'HP','f','396'),(854,11,'SP','f','207'),(855,11,'StatByLevel','f','0'),(856,11,'StatByBonus','f','0'),(857,11,'UsedStat','f','0'),(858,11,'AbilityPoint','s','0'),(859,11,'STR_STAT','f','0'),(860,11,'CON_STAT','f','0'),(861,11,'INT_STAT','f','0'),(862,11,'MNA_STAT','f','0'),(863,11,'DEX_STAT','f','0'),(864,11,'STR_Bonus','f','0'),(865,11,'CON_Bonus','f','0'),(866,11,'INT_Bonus','f','0'),(867,11,'MNA_Bonus','f','0'),(868,11,'DEX_Bonus','f','0'),(869,11,'MHP_Bonus','f','0'),(870,11,'MSP_Bonus','f','0'),(871,11,'MSPD_Bonus','f','0'),(872,11,'MAXSTA_Bonus','f','0'),(873,11,'DashRun','f','0'),(874,11,'MaxWeight_Bonus','f','0'),(875,12,'Lv','f','1'),(876,12,'HP','f','367'),(877,12,'SP','f','259'),(878,12,'StatByLevel','f','0'),(879,12,'StatByBonus','f','0'),(880,12,'UsedStat','f','0'),(881,12,'AbilityPoint','s','0'),(882,12,'STR_STAT','f','0'),(883,12,'CON_STAT','f','0'),(884,12,'INT_STAT','f','0'),(885,12,'MNA_STAT','f','0'),(886,12,'DEX_STAT','f','0'),(887,12,'STR_Bonus','f','0'),(888,12,'CON_Bonus','f','0'),(889,12,'INT_Bonus','f','0'),(890,12,'MNA_Bonus','f','0'),(891,12,'DEX_Bonus','f','0'),(892,12,'MHP_Bonus','f','0'),(893,12,'MSP_Bonus','f','0'),(894,12,'MSPD_Bonus','f','0'),(895,12,'MAXSTA_Bonus','f','0'),(896,12,'DashRun','f','0'),(897,12,'MaxWeight_Bonus','f','0'),(898,13,'Lv','f','1'),(899,13,'HP','f','438'),(900,13,'SP','f','460'),(901,13,'StatByLevel','f','0'),(902,13,'StatByBonus','f','0'),(903,13,'UsedStat','f','0'),(904,13,'AbilityPoint','s','0'),(905,13,'STR_STAT','f','0'),(906,13,'CON_STAT','f','0'),(907,13,'INT_STAT','f','0'),(908,13,'MNA_STAT','f','0'),(909,13,'DEX_STAT','f','0'),(910,13,'STR_Bonus','f','0'),(911,13,'CON_Bonus','f','0'),(912,13,'INT_Bonus','f','0'),(913,13,'MNA_Bonus','f','0'),(914,13,'DEX_Bonus','f','0'),(915,13,'MHP_Bonus','f','0'),(916,13,'MSP_Bonus','f','0'),(917,13,'MSPD_Bonus','f','0'),(918,13,'MAXSTA_Bonus','f','0'),(919,13,'DashRun','f','0'),(920,13,'MaxWeight_Bonus','f','0'),(921,14,'Lv','f','1'),(922,14,'HP','f','467'),(923,14,'SP','f','207'),(924,14,'StatByLevel','f','0'),(925,14,'StatByBonus','f','0'),(926,14,'UsedStat','f','0'),(927,14,'AbilityPoint','s','0'),(928,14,'STR_STAT','f','0'),(929,14,'CON_STAT','f','0'),(930,14,'INT_STAT','f','0'),(931,14,'MNA_STAT','f','0'),(932,14,'DEX_STAT','f','0'),(933,14,'STR_Bonus','f','0'),(934,14,'CON_Bonus','f','0'),(935,14,'INT_Bonus','f','0'),(936,14,'MNA_Bonus','f','0'),(937,14,'DEX_Bonus','f','0'),(938,14,'MHP_Bonus','f','0'),(939,14,'MSP_Bonus','f','0'),(940,14,'MSPD_Bonus','f','0'),(941,14,'MAXSTA_Bonus','f','0'),(942,14,'DashRun','f','0'),(943,14,'MaxWeight_Bonus','f','0'),(967,15,'Lv','f','1'),(968,15,'HP','f','396'),(969,15,'SP','f','207'),(970,15,'StatByLevel','f','0'),(971,15,'StatByBonus','f','0'),(972,15,'UsedStat','f','0'),(973,15,'AbilityPoint','s','0'),(974,15,'STR_STAT','f','0'),(975,15,'CON_STAT','f','0'),(976,15,'INT_STAT','f','0'),(977,15,'MNA_STAT','f','0'),(978,15,'DEX_STAT','f','0'),(979,15,'STR_Bonus','f','0'),(980,15,'CON_Bonus','f','0'),(981,15,'INT_Bonus','f','0'),(982,15,'MNA_Bonus','f','0'),(983,15,'DEX_Bonus','f','0'),(984,15,'MHP_Bonus','f','0'),(985,15,'MSP_Bonus','f','0'),(986,15,'MSPD_Bonus','f','0'),(987,15,'MAXSTA_Bonus','f','0'),(988,15,'DashRun','f','0'),(989,15,'MaxWeight_Bonus','f','0'),(1013,16,'Lv','f','1'),(1014,16,'HP','f','136'),(1015,16,'SP','f','460'),(1016,16,'StatByLevel','f','0'),(1017,16,'StatByBonus','f','0'),(1018,16,'UsedStat','f','0'),(1019,16,'AbilityPoint','s','0'),(1020,16,'STR_STAT','f','0'),(1021,16,'CON_STAT','f','0'),(1022,16,'INT_STAT','f','0'),(1023,16,'MNA_STAT','f','0'),(1024,16,'DEX_STAT','f','0'),(1025,16,'STR_Bonus','f','0'),(1026,16,'CON_Bonus','f','0'),(1027,16,'INT_Bonus','f','0'),(1028,16,'MNA_Bonus','f','0'),(1029,16,'DEX_Bonus','f','0'),(1030,16,'MHP_Bonus','f','0'),(1031,16,'MSP_Bonus','f','0'),(1032,16,'MSPD_Bonus','f','0'),(1033,16,'MAXSTA_Bonus','f','0'),(1034,16,'DashRun','f','0'),(1035,16,'MaxWeight_Bonus','f','0'),(1059,17,'Lv','f','1'),(1060,17,'HP','f','438'),(1061,17,'SP','f','460'),(1062,17,'StatByLevel','f','0'),(1063,17,'StatByBonus','f','0'),(1064,17,'UsedStat','f','0'),(1065,17,'AbilityPoint','s','0'),(1066,17,'STR_STAT','f','0'),(1067,17,'CON_STAT','f','0'),(1068,17,'INT_STAT','f','0'),(1069,17,'MNA_STAT','f','0'),(1070,17,'DEX_STAT','f','0'),(1071,17,'STR_Bonus','f','0'),(1072,17,'CON_Bonus','f','0'),(1073,17,'INT_Bonus','f','0'),(1074,17,'MNA_Bonus','f','0'),(1075,17,'DEX_Bonus','f','0'),(1076,17,'MHP_Bonus','f','0'),(1077,17,'MSP_Bonus','f','0'),(1078,17,'MSPD_Bonus','f','0'),(1079,17,'MAXSTA_Bonus','f','0'),(1080,17,'DashRun','f','0'),(1081,17,'MaxWeight_Bonus','f','0'),(1105,18,'Lv','f','1'),(1106,18,'HP','f','467'),(1107,18,'SP','f','207'),(1108,18,'StatByLevel','f','0'),(1109,18,'StatByBonus','f','0'),(1110,18,'UsedStat','f','0'),(1111,18,'AbilityPoint','s','0'),(1112,18,'STR_STAT','f','0'),(1113,18,'CON_STAT','f','0'),(1114,18,'INT_STAT','f','0'),(1115,18,'MNA_STAT','f','0'),(1116,18,'DEX_STAT','f','0'),(1117,18,'STR_Bonus','f','0'),(1118,18,'CON_Bonus','f','0'),(1119,18,'INT_Bonus','f','0'),(1120,18,'MNA_Bonus','f','0'),(1121,18,'DEX_Bonus','f','0'),(1122,18,'MHP_Bonus','f','0'),(1123,18,'MSP_Bonus','f','0'),(1124,18,'MSPD_Bonus','f','0'),(1125,18,'MAXSTA_Bonus','f','0'),(1126,18,'DashRun','f','0'),(1127,18,'MaxWeight_Bonus','f','0'),(1128,19,'Lv','f','1'),(1129,19,'HP','f','405'),(1130,19,'SP','f','207'),(1131,19,'StatByLevel','f','0'),(1132,19,'StatByBonus','f','0'),(1133,19,'UsedStat','f','0'),(1134,19,'AbilityPoint','s','0'),(1135,19,'STR_STAT','f','0'),(1136,19,'CON_STAT','f','0'),(1137,19,'INT_STAT','f','0'),(1138,19,'MNA_STAT','f','0'),(1139,19,'DEX_STAT','f','0'),(1140,19,'STR_Bonus','f','0'),(1141,19,'CON_Bonus','f','0'),(1142,19,'INT_Bonus','f','0'),(1143,19,'MNA_Bonus','f','0'),(1144,19,'DEX_Bonus','f','0'),(1145,19,'MHP_Bonus','f','0'),(1146,19,'MSP_Bonus','f','0'),(1147,19,'MSPD_Bonus','f','0'),(1148,19,'MAXSTA_Bonus','f','0'),(1149,19,'DashRun','f','0'),(1150,19,'MaxWeight_Bonus','f','0'),(1197,20,'Lv','f','1'),(1198,20,'HP','f','141.75'),(1199,20,'SP','f','232'),(1200,20,'StatByLevel','f','0'),(1201,20,'StatByBonus','f','0'),(1202,20,'UsedStat','f','0'),(1203,20,'AbilityPoint','s','0'),(1204,20,'STR_STAT','f','0'),(1205,20,'CON_STAT','f','0'),(1206,20,'INT_STAT','f','0'),(1207,20,'MNA_STAT','f','0'),(1208,20,'DEX_STAT','f','0'),(1209,20,'STR_Bonus','f','0'),(1210,20,'CON_Bonus','f','0'),(1211,20,'INT_Bonus','f','0'),(1212,20,'MNA_Bonus','f','0'),(1213,20,'DEX_Bonus','f','0'),(1214,20,'MHP_Bonus','f','0'),(1215,20,'MSP_Bonus','f','0'),(1216,20,'MSPD_Bonus','f','0'),(1217,20,'MAXSTA_Bonus','f','0'),(1218,20,'DashRun','f','0'),(1219,20,'MaxWeight_Bonus','f','0'),(1289,21,'Lv','f','1'),(1290,21,'HP','f','396'),(1291,21,'SP','f','207'),(1292,21,'StatByLevel','f','0'),(1293,21,'StatByBonus','f','0'),(1294,21,'UsedStat','f','0'),(1295,21,'AbilityPoint','s','0'),(1296,21,'STR_STAT','f','0'),(1297,21,'CON_STAT','f','0'),(1298,21,'INT_STAT','f','0'),(1299,21,'MNA_STAT','f','0'),(1300,21,'DEX_STAT','f','0'),(1301,21,'STR_Bonus','f','0'),(1302,21,'CON_Bonus','f','0'),(1303,21,'INT_Bonus','f','0'),(1304,21,'MNA_Bonus','f','0'),(1305,21,'DEX_Bonus','f','0'),(1306,21,'MHP_Bonus','f','0'),(1307,21,'MSP_Bonus','f','0'),(1308,21,'MSPD_Bonus','f','0'),(1309,21,'MAXSTA_Bonus','f','0'),(1310,21,'DashRun','f','0'),(1311,21,'MaxWeight_Bonus','f','0'),(1312,22,'Lv','f','1'),(1313,22,'HP','f','367'),(1314,22,'SP','f','454'),(1315,22,'StatByLevel','f','0'),(1316,22,'StatByBonus','f','0'),(1317,22,'UsedStat','f','0'),(1318,22,'AbilityPoint','s','0'),(1319,22,'STR_STAT','f','0'),(1320,22,'CON_STAT','f','0'),(1321,22,'INT_STAT','f','0'),(1322,22,'MNA_STAT','f','0'),(1323,22,'DEX_STAT','f','0'),(1324,22,'STR_Bonus','f','0'),(1325,22,'CON_Bonus','f','0'),(1326,22,'INT_Bonus','f','0'),(1327,22,'MNA_Bonus','f','0'),(1328,22,'DEX_Bonus','f','0'),(1329,22,'MHP_Bonus','f','0'),(1330,22,'MSP_Bonus','f','0'),(1331,22,'MSPD_Bonus','f','0'),(1332,22,'MAXSTA_Bonus','f','0'),(1333,22,'DashRun','f','0'),(1334,22,'MaxWeight_Bonus','f','0');
/*!40000 ALTER TABLE `character_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_properties_log`
--

DROP TABLE IF EXISTS `character_properties_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_properties_log` (
  `logId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(1) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  `backupTimestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `backupReason` varchar(50) DEFAULT 'pre_save',
  PRIMARY KEY (`logId`),
  KEY `idx_itemId_timestamp` (`characterId`,`backupTimestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=3101 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_properties_log`
--

LOCK TABLES `character_properties_log` WRITE;
/*!40000 ALTER TABLE `character_properties_log` DISABLE KEYS */;
INSERT INTO `character_properties_log` VALUES (1,1,'Lv','f','1','2026-04-24 21:22:30','pre_save_character_properties'),(2,1,'HP','f','405','2026-04-24 21:22:30','pre_save_character_properties'),(3,1,'SP','f','207','2026-04-24 21:22:30','pre_save_character_properties'),(4,1,'StatByLevel','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(5,1,'StatByBonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(6,1,'UsedStat','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(7,1,'AbilityPoint','s','0','2026-04-24 21:22:30','pre_save_character_properties'),(8,1,'STR_STAT','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(9,1,'CON_STAT','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(10,1,'INT_STAT','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(11,1,'MNA_STAT','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(12,1,'DEX_STAT','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(13,1,'STR_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(14,1,'CON_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(15,1,'INT_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(16,1,'MNA_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(17,1,'DEX_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(18,1,'MHP_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(19,1,'MSP_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(20,1,'MSPD_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(21,1,'MAXSTA_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(22,1,'DashRun','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(23,1,'MaxWeight_Bonus','f','0','2026-04-24 21:22:30','pre_save_character_properties'),(32,1,'SkintoneName','s','skintone2','2026-04-24 21:22:30','pre_save_character_etc_properties'),(33,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 21:22:30','pre_save_character_etc_properties'),(34,1,'LastPlayDate','f','20210728','2026-04-24 21:22:30','pre_save_character_etc_properties'),(35,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 21:22:30','pre_save_character_etc_properties'),(36,1,'MaxWarehouseCount','f','2000','2026-04-24 21:22:30','pre_save_character_etc_properties'),(37,1,'CompanionAutoAtk','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(38,1,'HAT_Visible','f','1','2026-04-24 21:22:30','pre_save_character_etc_properties'),(39,1,'HAT_T_Visible','f','1','2026-04-24 21:22:30','pre_save_character_etc_properties'),(40,1,'HAT_L_Visible','f','1','2026-04-24 21:22:30','pre_save_character_etc_properties'),(41,1,'HAIR_WIG_Visible','f','1','2026-04-24 21:22:30','pre_save_character_etc_properties'),(42,1,'InDunCountType_100','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(43,1,'InDunCountType_200','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(44,1,'InDunCountType_0','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(45,1,'InDunCountType_400','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(46,1,'InDunCountType_300','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(47,1,'InDunCountType_500','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(48,1,'InDunCountType_600','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(49,1,'InDunCountType_700','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(50,1,'InDunCountType_10000','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(51,1,'InDunCountType_900','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(52,1,'InDunCountType_1200','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(53,1,'InDunCountType_1100','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(54,1,'InDunCountType_8003','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(55,1,'InDunCountType_2','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(56,1,'InDunCountType_8000','f','0','2026-04-24 21:22:30','pre_save_character_etc_properties'),(57,1,'Indun_ResetTime','s','202604524210144','2026-04-24 21:22:30','pre_save_character_etc_properties'),(58,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 21:22:30','pre_save_character_etc_properties'),(63,1,'Lv','f','1','2026-04-24 21:24:01','pre_save_character_properties'),(64,1,'HP','f','405','2026-04-24 21:24:01','pre_save_character_properties'),(65,1,'SP','f','207','2026-04-24 21:24:01','pre_save_character_properties'),(66,1,'StatByLevel','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(67,1,'StatByBonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(68,1,'UsedStat','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(69,1,'AbilityPoint','s','0','2026-04-24 21:24:01','pre_save_character_properties'),(70,1,'STR_STAT','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(71,1,'CON_STAT','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(72,1,'INT_STAT','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(73,1,'MNA_STAT','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(74,1,'DEX_STAT','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(75,1,'STR_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(76,1,'CON_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(77,1,'INT_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(78,1,'MNA_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(79,1,'DEX_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(80,1,'MHP_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(81,1,'MSP_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(82,1,'MSPD_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(83,1,'MAXSTA_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(84,1,'DashRun','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(85,1,'MaxWeight_Bonus','f','0','2026-04-24 21:24:01','pre_save_character_properties'),(94,1,'SkintoneName','s','skintone2','2026-04-24 21:24:01','pre_save_character_etc_properties'),(95,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 21:24:01','pre_save_character_etc_properties'),(96,1,'LastPlayDate','f','20210728','2026-04-24 21:24:01','pre_save_character_etc_properties'),(97,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 21:24:01','pre_save_character_etc_properties'),(98,1,'MaxWarehouseCount','f','2000','2026-04-24 21:24:01','pre_save_character_etc_properties'),(99,1,'CompanionAutoAtk','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(100,1,'HAT_Visible','f','1','2026-04-24 21:24:01','pre_save_character_etc_properties'),(101,1,'HAT_T_Visible','f','1','2026-04-24 21:24:01','pre_save_character_etc_properties'),(102,1,'HAT_L_Visible','f','1','2026-04-24 21:24:01','pre_save_character_etc_properties'),(103,1,'HAIR_WIG_Visible','f','1','2026-04-24 21:24:01','pre_save_character_etc_properties'),(104,1,'InDunCountType_100','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(105,1,'InDunCountType_200','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(106,1,'InDunCountType_0','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(107,1,'InDunCountType_400','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(108,1,'InDunCountType_300','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(109,1,'InDunCountType_500','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(110,1,'InDunCountType_600','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(111,1,'InDunCountType_700','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(112,1,'InDunCountType_10000','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(113,1,'InDunCountType_900','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(114,1,'InDunCountType_1200','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(115,1,'InDunCountType_1100','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(116,1,'InDunCountType_8003','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(117,1,'InDunCountType_2','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(118,1,'InDunCountType_8000','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(119,1,'Indun_ResetTime','s','202604524210144','2026-04-24 21:24:01','pre_save_character_etc_properties'),(120,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 21:24:01','pre_save_character_etc_properties'),(121,1,'FirstPlay','f','0','2026-04-24 21:24:01','pre_save_character_etc_properties'),(125,1,'Lv','f','1','2026-04-24 21:50:10','pre_save_character_properties'),(126,1,'HP','f','405','2026-04-24 21:50:10','pre_save_character_properties'),(127,1,'SP','f','207','2026-04-24 21:50:10','pre_save_character_properties'),(128,1,'StatByLevel','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(129,1,'StatByBonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(130,1,'UsedStat','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(131,1,'AbilityPoint','s','0','2026-04-24 21:50:10','pre_save_character_properties'),(132,1,'STR_STAT','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(133,1,'CON_STAT','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(134,1,'INT_STAT','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(135,1,'MNA_STAT','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(136,1,'DEX_STAT','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(137,1,'STR_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(138,1,'CON_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(139,1,'INT_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(140,1,'MNA_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(141,1,'DEX_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(142,1,'MHP_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(143,1,'MSP_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(144,1,'MSPD_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(145,1,'MAXSTA_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(146,1,'DashRun','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(147,1,'MaxWeight_Bonus','f','0','2026-04-24 21:50:10','pre_save_character_properties'),(156,1,'SkintoneName','s','skintone2','2026-04-24 21:50:11','pre_save_character_etc_properties'),(157,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 21:50:11','pre_save_character_etc_properties'),(158,1,'LastPlayDate','f','20210728','2026-04-24 21:50:11','pre_save_character_etc_properties'),(159,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 21:50:11','pre_save_character_etc_properties'),(160,1,'MaxWarehouseCount','f','2000','2026-04-24 21:50:11','pre_save_character_etc_properties'),(161,1,'CompanionAutoAtk','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(162,1,'HAT_Visible','f','1','2026-04-24 21:50:11','pre_save_character_etc_properties'),(163,1,'HAT_T_Visible','f','1','2026-04-24 21:50:11','pre_save_character_etc_properties'),(164,1,'HAT_L_Visible','f','1','2026-04-24 21:50:11','pre_save_character_etc_properties'),(165,1,'HAIR_WIG_Visible','f','1','2026-04-24 21:50:11','pre_save_character_etc_properties'),(166,1,'InDunCountType_100','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(167,1,'InDunCountType_200','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(168,1,'InDunCountType_0','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(169,1,'InDunCountType_400','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(170,1,'InDunCountType_300','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(171,1,'InDunCountType_500','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(172,1,'InDunCountType_600','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(173,1,'InDunCountType_700','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(174,1,'InDunCountType_10000','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(175,1,'InDunCountType_900','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(176,1,'InDunCountType_1200','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(177,1,'InDunCountType_1100','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(178,1,'InDunCountType_8003','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(179,1,'InDunCountType_2','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(180,1,'InDunCountType_8000','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(181,1,'Indun_ResetTime','s','202604524210144','2026-04-24 21:50:11','pre_save_character_etc_properties'),(182,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 21:50:11','pre_save_character_etc_properties'),(183,1,'FirstPlay','f','0','2026-04-24 21:50:11','pre_save_character_etc_properties'),(187,1,'Lv','f','1','2026-04-24 22:12:10','pre_save_character_properties'),(188,1,'HP','f','405','2026-04-24 22:12:10','pre_save_character_properties'),(189,1,'SP','f','207','2026-04-24 22:12:10','pre_save_character_properties'),(190,1,'StatByLevel','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(191,1,'StatByBonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(192,1,'UsedStat','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(193,1,'AbilityPoint','s','0','2026-04-24 22:12:10','pre_save_character_properties'),(194,1,'STR_STAT','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(195,1,'CON_STAT','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(196,1,'INT_STAT','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(197,1,'MNA_STAT','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(198,1,'DEX_STAT','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(199,1,'STR_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(200,1,'CON_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(201,1,'INT_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(202,1,'MNA_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(203,1,'DEX_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(204,1,'MHP_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(205,1,'MSP_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(206,1,'MSPD_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(207,1,'MAXSTA_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(208,1,'DashRun','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(209,1,'MaxWeight_Bonus','f','0','2026-04-24 22:12:10','pre_save_character_properties'),(218,1,'SkintoneName','s','skintone2','2026-04-24 22:12:10','pre_save_character_etc_properties'),(219,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 22:12:10','pre_save_character_etc_properties'),(220,1,'LastPlayDate','f','20210728','2026-04-24 22:12:10','pre_save_character_etc_properties'),(221,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 22:12:10','pre_save_character_etc_properties'),(222,1,'MaxWarehouseCount','f','2000','2026-04-24 22:12:10','pre_save_character_etc_properties'),(223,1,'CompanionAutoAtk','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(224,1,'HAT_Visible','f','1','2026-04-24 22:12:10','pre_save_character_etc_properties'),(225,1,'HAT_T_Visible','f','1','2026-04-24 22:12:10','pre_save_character_etc_properties'),(226,1,'HAT_L_Visible','f','1','2026-04-24 22:12:10','pre_save_character_etc_properties'),(227,1,'HAIR_WIG_Visible','f','1','2026-04-24 22:12:10','pre_save_character_etc_properties'),(228,1,'InDunCountType_100','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(229,1,'InDunCountType_200','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(230,1,'InDunCountType_0','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(231,1,'InDunCountType_400','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(232,1,'InDunCountType_300','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(233,1,'InDunCountType_500','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(234,1,'InDunCountType_600','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(235,1,'InDunCountType_700','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(236,1,'InDunCountType_10000','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(237,1,'InDunCountType_900','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(238,1,'InDunCountType_1200','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(239,1,'InDunCountType_1100','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(240,1,'InDunCountType_8003','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(241,1,'InDunCountType_2','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(242,1,'InDunCountType_8000','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(243,1,'Indun_ResetTime','s','202604524210144','2026-04-24 22:12:10','pre_save_character_etc_properties'),(244,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 22:12:10','pre_save_character_etc_properties'),(245,1,'FirstPlay','f','0','2026-04-24 22:12:10','pre_save_character_etc_properties'),(249,1,'Lv','f','1','2026-04-24 22:15:28','pre_save_character_properties'),(250,1,'HP','f','405','2026-04-24 22:15:28','pre_save_character_properties'),(251,1,'SP','f','207','2026-04-24 22:15:28','pre_save_character_properties'),(252,1,'StatByLevel','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(253,1,'StatByBonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(254,1,'UsedStat','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(255,1,'AbilityPoint','s','0','2026-04-24 22:15:28','pre_save_character_properties'),(256,1,'STR_STAT','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(257,1,'CON_STAT','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(258,1,'INT_STAT','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(259,1,'MNA_STAT','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(260,1,'DEX_STAT','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(261,1,'STR_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(262,1,'CON_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(263,1,'INT_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(264,1,'MNA_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(265,1,'DEX_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(266,1,'MHP_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(267,1,'MSP_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(268,1,'MSPD_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(269,1,'MAXSTA_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(270,1,'DashRun','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(271,1,'MaxWeight_Bonus','f','0','2026-04-24 22:15:28','pre_save_character_properties'),(280,1,'SkintoneName','s','skintone2','2026-04-24 22:15:28','pre_save_character_etc_properties'),(281,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 22:15:28','pre_save_character_etc_properties'),(282,1,'LastPlayDate','f','20210728','2026-04-24 22:15:28','pre_save_character_etc_properties'),(283,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 22:15:28','pre_save_character_etc_properties'),(284,1,'MaxWarehouseCount','f','2000','2026-04-24 22:15:28','pre_save_character_etc_properties'),(285,1,'CompanionAutoAtk','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(286,1,'HAT_Visible','f','1','2026-04-24 22:15:28','pre_save_character_etc_properties'),(287,1,'HAT_T_Visible','f','1','2026-04-24 22:15:28','pre_save_character_etc_properties'),(288,1,'HAT_L_Visible','f','1','2026-04-24 22:15:28','pre_save_character_etc_properties'),(289,1,'HAIR_WIG_Visible','f','1','2026-04-24 22:15:28','pre_save_character_etc_properties'),(290,1,'InDunCountType_100','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(291,1,'InDunCountType_200','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(292,1,'InDunCountType_0','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(293,1,'InDunCountType_400','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(294,1,'InDunCountType_300','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(295,1,'InDunCountType_500','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(296,1,'InDunCountType_600','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(297,1,'InDunCountType_700','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(298,1,'InDunCountType_10000','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(299,1,'InDunCountType_900','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(300,1,'InDunCountType_1200','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(301,1,'InDunCountType_1100','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(302,1,'InDunCountType_8003','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(303,1,'InDunCountType_2','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(304,1,'InDunCountType_8000','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(305,1,'Indun_ResetTime','s','202604524210144','2026-04-24 22:15:28','pre_save_character_etc_properties'),(306,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 22:15:28','pre_save_character_etc_properties'),(307,1,'FirstPlay','f','0','2026-04-24 22:15:28','pre_save_character_etc_properties'),(311,1,'Lv','f','1','2026-04-24 22:29:18','pre_save_character_properties'),(312,1,'HP','f','405','2026-04-24 22:29:18','pre_save_character_properties'),(313,1,'SP','f','207','2026-04-24 22:29:18','pre_save_character_properties'),(314,1,'StatByLevel','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(315,1,'StatByBonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(316,1,'UsedStat','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(317,1,'AbilityPoint','s','0','2026-04-24 22:29:18','pre_save_character_properties'),(318,1,'STR_STAT','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(319,1,'CON_STAT','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(320,1,'INT_STAT','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(321,1,'MNA_STAT','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(322,1,'DEX_STAT','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(323,1,'STR_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(324,1,'CON_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(325,1,'INT_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(326,1,'MNA_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(327,1,'DEX_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(328,1,'MHP_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(329,1,'MSP_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(330,1,'MSPD_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(331,1,'MAXSTA_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(332,1,'DashRun','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(333,1,'MaxWeight_Bonus','f','0','2026-04-24 22:29:18','pre_save_character_properties'),(342,1,'SkintoneName','s','skintone2','2026-04-24 22:29:18','pre_save_character_etc_properties'),(343,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 22:29:18','pre_save_character_etc_properties'),(344,1,'LastPlayDate','f','20210728','2026-04-24 22:29:18','pre_save_character_etc_properties'),(345,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 22:29:18','pre_save_character_etc_properties'),(346,1,'MaxWarehouseCount','f','2000','2026-04-24 22:29:18','pre_save_character_etc_properties'),(347,1,'CompanionAutoAtk','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(348,1,'HAT_Visible','f','1','2026-04-24 22:29:18','pre_save_character_etc_properties'),(349,1,'HAT_T_Visible','f','1','2026-04-24 22:29:18','pre_save_character_etc_properties'),(350,1,'HAT_L_Visible','f','1','2026-04-24 22:29:18','pre_save_character_etc_properties'),(351,1,'HAIR_WIG_Visible','f','1','2026-04-24 22:29:18','pre_save_character_etc_properties'),(352,1,'InDunCountType_100','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(353,1,'InDunCountType_200','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(354,1,'InDunCountType_0','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(355,1,'InDunCountType_400','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(356,1,'InDunCountType_300','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(357,1,'InDunCountType_500','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(358,1,'InDunCountType_600','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(359,1,'InDunCountType_700','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(360,1,'InDunCountType_10000','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(361,1,'InDunCountType_900','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(362,1,'InDunCountType_1200','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(363,1,'InDunCountType_1100','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(364,1,'InDunCountType_8003','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(365,1,'InDunCountType_2','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(366,1,'InDunCountType_8000','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(367,1,'Indun_ResetTime','s','202604524210144','2026-04-24 22:29:18','pre_save_character_etc_properties'),(368,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 22:29:18','pre_save_character_etc_properties'),(369,1,'FirstPlay','f','0','2026-04-24 22:29:18','pre_save_character_etc_properties'),(373,1,'Lv','f','1','2026-04-24 22:47:18','pre_save_character_properties'),(374,1,'HP','f','405','2026-04-24 22:47:18','pre_save_character_properties'),(375,1,'SP','f','207','2026-04-24 22:47:18','pre_save_character_properties'),(376,1,'StatByLevel','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(377,1,'StatByBonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(378,1,'UsedStat','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(379,1,'AbilityPoint','s','0','2026-04-24 22:47:18','pre_save_character_properties'),(380,1,'STR_STAT','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(381,1,'CON_STAT','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(382,1,'INT_STAT','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(383,1,'MNA_STAT','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(384,1,'DEX_STAT','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(385,1,'STR_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(386,1,'CON_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(387,1,'INT_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(388,1,'MNA_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(389,1,'DEX_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(390,1,'MHP_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(391,1,'MSP_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(392,1,'MSPD_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(393,1,'MAXSTA_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(394,1,'DashRun','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(395,1,'MaxWeight_Bonus','f','0','2026-04-24 22:47:18','pre_save_character_properties'),(404,1,'SkintoneName','s','skintone2','2026-04-24 22:47:18','pre_save_character_etc_properties'),(405,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 22:47:18','pre_save_character_etc_properties'),(406,1,'LastPlayDate','f','20210728','2026-04-24 22:47:18','pre_save_character_etc_properties'),(407,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 22:47:18','pre_save_character_etc_properties'),(408,1,'MaxWarehouseCount','f','2000','2026-04-24 22:47:18','pre_save_character_etc_properties'),(409,1,'CompanionAutoAtk','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(410,1,'HAT_Visible','f','1','2026-04-24 22:47:18','pre_save_character_etc_properties'),(411,1,'HAT_T_Visible','f','1','2026-04-24 22:47:18','pre_save_character_etc_properties'),(412,1,'HAT_L_Visible','f','1','2026-04-24 22:47:18','pre_save_character_etc_properties'),(413,1,'HAIR_WIG_Visible','f','1','2026-04-24 22:47:18','pre_save_character_etc_properties'),(414,1,'InDunCountType_100','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(415,1,'InDunCountType_200','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(416,1,'InDunCountType_0','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(417,1,'InDunCountType_400','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(418,1,'InDunCountType_300','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(419,1,'InDunCountType_500','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(420,1,'InDunCountType_600','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(421,1,'InDunCountType_700','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(422,1,'InDunCountType_10000','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(423,1,'InDunCountType_900','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(424,1,'InDunCountType_1200','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(425,1,'InDunCountType_1100','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(426,1,'InDunCountType_8003','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(427,1,'InDunCountType_2','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(428,1,'InDunCountType_8000','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(429,1,'Indun_ResetTime','s','202604524210144','2026-04-24 22:47:18','pre_save_character_etc_properties'),(430,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 22:47:18','pre_save_character_etc_properties'),(431,1,'FirstPlay','f','0','2026-04-24 22:47:18','pre_save_character_etc_properties'),(435,1,'Lv','f','1','2026-04-24 22:47:19','pre_save_character_properties'),(436,1,'HP','f','405','2026-04-24 22:47:19','pre_save_character_properties'),(437,1,'SP','f','207','2026-04-24 22:47:19','pre_save_character_properties'),(438,1,'StatByLevel','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(439,1,'StatByBonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(440,1,'UsedStat','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(441,1,'AbilityPoint','s','0','2026-04-24 22:47:19','pre_save_character_properties'),(442,1,'STR_STAT','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(443,1,'CON_STAT','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(444,1,'INT_STAT','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(445,1,'MNA_STAT','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(446,1,'DEX_STAT','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(447,1,'STR_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(448,1,'CON_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(449,1,'INT_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(450,1,'MNA_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(451,1,'DEX_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(452,1,'MHP_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(453,1,'MSP_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(454,1,'MSPD_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(455,1,'MAXSTA_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(456,1,'DashRun','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(457,1,'MaxWeight_Bonus','f','0','2026-04-24 22:47:19','pre_save_character_properties'),(466,1,'SkintoneName','s','skintone2','2026-04-24 22:47:19','pre_save_character_etc_properties'),(467,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 22:47:19','pre_save_character_etc_properties'),(468,1,'LastPlayDate','f','20210728','2026-04-24 22:47:19','pre_save_character_etc_properties'),(469,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 22:47:19','pre_save_character_etc_properties'),(470,1,'MaxWarehouseCount','f','2000','2026-04-24 22:47:19','pre_save_character_etc_properties'),(471,1,'CompanionAutoAtk','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(472,1,'HAT_Visible','f','1','2026-04-24 22:47:19','pre_save_character_etc_properties'),(473,1,'HAT_T_Visible','f','1','2026-04-24 22:47:19','pre_save_character_etc_properties'),(474,1,'HAT_L_Visible','f','1','2026-04-24 22:47:19','pre_save_character_etc_properties'),(475,1,'HAIR_WIG_Visible','f','1','2026-04-24 22:47:19','pre_save_character_etc_properties'),(476,1,'InDunCountType_100','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(477,1,'InDunCountType_200','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(478,1,'InDunCountType_0','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(479,1,'InDunCountType_400','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(480,1,'InDunCountType_300','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(481,1,'InDunCountType_500','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(482,1,'InDunCountType_600','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(483,1,'InDunCountType_700','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(484,1,'InDunCountType_10000','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(485,1,'InDunCountType_900','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(486,1,'InDunCountType_1200','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(487,1,'InDunCountType_1100','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(488,1,'InDunCountType_8003','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(489,1,'InDunCountType_2','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(490,1,'InDunCountType_8000','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(491,1,'Indun_ResetTime','s','202604524210144','2026-04-24 22:47:19','pre_save_character_etc_properties'),(492,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 22:47:19','pre_save_character_etc_properties'),(493,1,'FirstPlay','f','0','2026-04-24 22:47:19','pre_save_character_etc_properties'),(497,2,'AbilityPoint','s','0','2026-04-24 22:50:16','pre_save_character_properties'),(498,2,'CON_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(499,2,'CON_STAT','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(500,2,'DashRun','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(501,2,'DEX_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(502,2,'DEX_STAT','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(503,2,'HP','f','467','2026-04-24 22:50:16','pre_save_character_properties'),(504,2,'INT_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(505,2,'INT_STAT','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(506,2,'Lv','f','1','2026-04-24 22:50:16','pre_save_character_properties'),(507,2,'MAXSTA_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(508,2,'MaxWeight_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(509,2,'MHP_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(510,2,'MNA_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(511,2,'MNA_STAT','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(512,2,'MSPD_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(513,2,'MSP_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(514,2,'SP','f','207','2026-04-24 22:50:16','pre_save_character_properties'),(515,2,'StatByBonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(516,2,'StatByLevel','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(517,2,'STR_Bonus','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(518,2,'STR_STAT','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(519,2,'UsedStat','f','0','2026-04-24 22:50:16','pre_save_character_properties'),(528,2,'CompanionAutoAtk','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(529,2,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 22:50:16','pre_save_character_etc_properties'),(530,2,'FirstPlay','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(531,2,'HAIR_WIG_Visible','f','1','2026-04-24 22:50:16','pre_save_character_etc_properties'),(532,2,'HAT_L_Visible','f','1','2026-04-24 22:50:16','pre_save_character_etc_properties'),(533,2,'HAT_T_Visible','f','1','2026-04-24 22:50:16','pre_save_character_etc_properties'),(534,2,'HAT_Visible','f','1','2026-04-24 22:50:16','pre_save_character_etc_properties'),(535,2,'InDunCountType_0','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(536,2,'InDunCountType_100','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(537,2,'InDunCountType_10000','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(538,2,'InDunCountType_1100','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(539,2,'InDunCountType_1200','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(540,2,'InDunCountType_2','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(541,2,'InDunCountType_200','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(542,2,'InDunCountType_300','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(543,2,'InDunCountType_400','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(544,2,'InDunCountType_500','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(545,2,'InDunCountType_600','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(546,2,'InDunCountType_700','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(547,2,'InDunCountType_8000','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(548,2,'InDunCountType_8003','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(549,2,'InDunCountType_900','f','0','2026-04-24 22:50:16','pre_save_character_etc_properties'),(550,2,'IndunWeeklyResetTime','s','202604524224852','2026-04-24 22:50:16','pre_save_character_etc_properties'),(551,2,'Indun_ResetTime','s','202604524224852','2026-04-24 22:50:16','pre_save_character_etc_properties'),(552,2,'LastPlayDate','f','20210728','2026-04-24 22:50:16','pre_save_character_etc_properties'),(553,2,'MaxWarehouseCount','f','2000','2026-04-24 22:50:16','pre_save_character_etc_properties'),(554,2,'SkintoneName','s','skintone2','2026-04-24 22:50:16','pre_save_character_etc_properties'),(555,2,'StartHairName','s','UnbalancedShortcut','2026-04-24 22:50:16','pre_save_character_etc_properties'),(559,1,'AbilityPoint','s','0','2026-04-24 23:01:48','pre_save_character_properties'),(560,1,'CON_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(561,1,'CON_STAT','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(562,1,'DashRun','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(563,1,'DEX_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(564,1,'DEX_STAT','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(565,1,'HP','f','405','2026-04-24 23:01:48','pre_save_character_properties'),(566,1,'INT_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(567,1,'INT_STAT','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(568,1,'Lv','f','1','2026-04-24 23:01:48','pre_save_character_properties'),(569,1,'MAXSTA_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(570,1,'MaxWeight_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(571,1,'MHP_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(572,1,'MNA_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(573,1,'MNA_STAT','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(574,1,'MSPD_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(575,1,'MSP_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(576,1,'SP','f','207','2026-04-24 23:01:48','pre_save_character_properties'),(577,1,'StatByBonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(578,1,'StatByLevel','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(579,1,'STR_Bonus','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(580,1,'STR_STAT','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(581,1,'UsedStat','f','0','2026-04-24 23:01:48','pre_save_character_properties'),(590,1,'CompanionAutoAtk','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(591,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 23:01:48','pre_save_character_etc_properties'),(592,1,'FirstPlay','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(593,1,'HAIR_WIG_Visible','f','1','2026-04-24 23:01:48','pre_save_character_etc_properties'),(594,1,'HAT_L_Visible','f','1','2026-04-24 23:01:48','pre_save_character_etc_properties'),(595,1,'HAT_T_Visible','f','1','2026-04-24 23:01:48','pre_save_character_etc_properties'),(596,1,'HAT_Visible','f','1','2026-04-24 23:01:48','pre_save_character_etc_properties'),(597,1,'InDunCountType_0','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(598,1,'InDunCountType_100','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(599,1,'InDunCountType_10000','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(600,1,'InDunCountType_1100','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(601,1,'InDunCountType_1200','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(602,1,'InDunCountType_2','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(603,1,'InDunCountType_200','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(604,1,'InDunCountType_300','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(605,1,'InDunCountType_400','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(606,1,'InDunCountType_500','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(607,1,'InDunCountType_600','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(608,1,'InDunCountType_700','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(609,1,'InDunCountType_8000','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(610,1,'InDunCountType_8003','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(611,1,'InDunCountType_900','f','0','2026-04-24 23:01:48','pre_save_character_etc_properties'),(612,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 23:01:48','pre_save_character_etc_properties'),(613,1,'Indun_ResetTime','s','202604524210144','2026-04-24 23:01:48','pre_save_character_etc_properties'),(614,1,'LastPlayDate','f','20210728','2026-04-24 23:01:48','pre_save_character_etc_properties'),(615,1,'MaxWarehouseCount','f','2000','2026-04-24 23:01:48','pre_save_character_etc_properties'),(616,1,'SkintoneName','s','skintone2','2026-04-24 23:01:48','pre_save_character_etc_properties'),(617,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 23:01:48','pre_save_character_etc_properties'),(621,1,'AbilityPoint','s','0','2026-04-24 23:25:42','pre_save_character_properties'),(622,1,'CON_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(623,1,'CON_STAT','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(624,1,'DashRun','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(625,1,'DEX_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(626,1,'DEX_STAT','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(627,1,'HP','f','405','2026-04-24 23:25:42','pre_save_character_properties'),(628,1,'INT_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(629,1,'INT_STAT','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(630,1,'Lv','f','1','2026-04-24 23:25:42','pre_save_character_properties'),(631,1,'MAXSTA_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(632,1,'MaxWeight_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(633,1,'MHP_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(634,1,'MNA_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(635,1,'MNA_STAT','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(636,1,'MSPD_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(637,1,'MSP_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(638,1,'SP','f','207','2026-04-24 23:25:42','pre_save_character_properties'),(639,1,'StatByBonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(640,1,'StatByLevel','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(641,1,'STR_Bonus','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(642,1,'STR_STAT','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(643,1,'UsedStat','f','0','2026-04-24 23:25:42','pre_save_character_properties'),(652,1,'CompanionAutoAtk','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(653,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-24 23:25:42','pre_save_character_etc_properties'),(654,1,'FirstPlay','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(655,1,'HAIR_WIG_Visible','f','1','2026-04-24 23:25:42','pre_save_character_etc_properties'),(656,1,'HAT_L_Visible','f','1','2026-04-24 23:25:42','pre_save_character_etc_properties'),(657,1,'HAT_T_Visible','f','1','2026-04-24 23:25:42','pre_save_character_etc_properties'),(658,1,'HAT_Visible','f','1','2026-04-24 23:25:42','pre_save_character_etc_properties'),(659,1,'InDunCountType_0','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(660,1,'InDunCountType_100','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(661,1,'InDunCountType_10000','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(662,1,'InDunCountType_1100','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(663,1,'InDunCountType_1200','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(664,1,'InDunCountType_2','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(665,1,'InDunCountType_200','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(666,1,'InDunCountType_300','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(667,1,'InDunCountType_400','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(668,1,'InDunCountType_500','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(669,1,'InDunCountType_600','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(670,1,'InDunCountType_700','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(671,1,'InDunCountType_8000','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(672,1,'InDunCountType_8003','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(673,1,'InDunCountType_900','f','0','2026-04-24 23:25:42','pre_save_character_etc_properties'),(674,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-24 23:25:42','pre_save_character_etc_properties'),(675,1,'Indun_ResetTime','s','202604524210144','2026-04-24 23:25:42','pre_save_character_etc_properties'),(676,1,'LastPlayDate','f','20210728','2026-04-24 23:25:42','pre_save_character_etc_properties'),(677,1,'MaxWarehouseCount','f','2000','2026-04-24 23:25:42','pre_save_character_etc_properties'),(678,1,'SkintoneName','s','skintone2','2026-04-24 23:25:42','pre_save_character_etc_properties'),(679,1,'StartHairName','s','UnbalancedShortcut','2026-04-24 23:25:42','pre_save_character_etc_properties'),(683,1,'AbilityPoint','s','0','2026-04-25 08:16:14','pre_save_character_properties'),(684,1,'CON_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(685,1,'CON_STAT','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(686,1,'DashRun','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(687,1,'DEX_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(688,1,'DEX_STAT','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(689,1,'HP','f','405','2026-04-25 08:16:14','pre_save_character_properties'),(690,1,'INT_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(691,1,'INT_STAT','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(692,1,'Lv','f','1','2026-04-25 08:16:14','pre_save_character_properties'),(693,1,'MAXSTA_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(694,1,'MaxWeight_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(695,1,'MHP_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(696,1,'MNA_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(697,1,'MNA_STAT','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(698,1,'MSPD_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(699,1,'MSP_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(700,1,'SP','f','207','2026-04-25 08:16:14','pre_save_character_properties'),(701,1,'StatByBonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(702,1,'StatByLevel','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(703,1,'STR_Bonus','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(704,1,'STR_STAT','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(705,1,'UsedStat','f','0','2026-04-25 08:16:14','pre_save_character_properties'),(714,1,'CompanionAutoAtk','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(715,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 08:16:14','pre_save_character_etc_properties'),(716,1,'FirstPlay','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(717,1,'HAIR_WIG_Visible','f','1','2026-04-25 08:16:14','pre_save_character_etc_properties'),(718,1,'HAT_L_Visible','f','1','2026-04-25 08:16:14','pre_save_character_etc_properties'),(719,1,'HAT_T_Visible','f','1','2026-04-25 08:16:14','pre_save_character_etc_properties'),(720,1,'HAT_Visible','f','1','2026-04-25 08:16:14','pre_save_character_etc_properties'),(721,1,'InDunCountType_0','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(722,1,'InDunCountType_100','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(723,1,'InDunCountType_10000','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(724,1,'InDunCountType_1100','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(725,1,'InDunCountType_1200','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(726,1,'InDunCountType_2','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(727,1,'InDunCountType_200','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(728,1,'InDunCountType_300','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(729,1,'InDunCountType_400','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(730,1,'InDunCountType_500','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(731,1,'InDunCountType_600','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(732,1,'InDunCountType_700','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(733,1,'InDunCountType_8000','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(734,1,'InDunCountType_8003','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(735,1,'InDunCountType_900','f','0','2026-04-25 08:16:14','pre_save_character_etc_properties'),(736,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 08:16:14','pre_save_character_etc_properties'),(737,1,'Indun_ResetTime','s','202604524210144','2026-04-25 08:16:14','pre_save_character_etc_properties'),(738,1,'LastPlayDate','f','20210728','2026-04-25 08:16:14','pre_save_character_etc_properties'),(739,1,'MaxWarehouseCount','f','2000','2026-04-25 08:16:14','pre_save_character_etc_properties'),(740,1,'SkintoneName','s','skintone2','2026-04-25 08:16:14','pre_save_character_etc_properties'),(741,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 08:16:14','pre_save_character_etc_properties'),(745,1,'AbilityPoint','s','0','2026-04-25 08:48:41','pre_save_character_properties'),(746,1,'CON_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(747,1,'CON_STAT','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(748,1,'DashRun','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(749,1,'DEX_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(750,1,'DEX_STAT','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(751,1,'HP','f','405','2026-04-25 08:48:41','pre_save_character_properties'),(752,1,'INT_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(753,1,'INT_STAT','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(754,1,'Lv','f','1','2026-04-25 08:48:41','pre_save_character_properties'),(755,1,'MAXSTA_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(756,1,'MaxWeight_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(757,1,'MHP_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(758,1,'MNA_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(759,1,'MNA_STAT','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(760,1,'MSPD_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(761,1,'MSP_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(762,1,'SP','f','207','2026-04-25 08:48:41','pre_save_character_properties'),(763,1,'StatByBonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(764,1,'StatByLevel','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(765,1,'STR_Bonus','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(766,1,'STR_STAT','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(767,1,'UsedStat','f','0','2026-04-25 08:48:41','pre_save_character_properties'),(776,1,'CompanionAutoAtk','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(777,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 08:48:41','pre_save_character_etc_properties'),(778,1,'FirstPlay','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(779,1,'HAIR_WIG_Visible','f','1','2026-04-25 08:48:41','pre_save_character_etc_properties'),(780,1,'HAT_L_Visible','f','1','2026-04-25 08:48:41','pre_save_character_etc_properties'),(781,1,'HAT_T_Visible','f','1','2026-04-25 08:48:41','pre_save_character_etc_properties'),(782,1,'HAT_Visible','f','1','2026-04-25 08:48:41','pre_save_character_etc_properties'),(783,1,'InDunCountType_0','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(784,1,'InDunCountType_100','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(785,1,'InDunCountType_10000','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(786,1,'InDunCountType_1100','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(787,1,'InDunCountType_1200','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(788,1,'InDunCountType_2','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(789,1,'InDunCountType_200','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(790,1,'InDunCountType_300','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(791,1,'InDunCountType_400','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(792,1,'InDunCountType_500','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(793,1,'InDunCountType_600','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(794,1,'InDunCountType_700','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(795,1,'InDunCountType_8000','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(796,1,'InDunCountType_8003','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(797,1,'InDunCountType_900','f','0','2026-04-25 08:48:41','pre_save_character_etc_properties'),(798,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 08:48:41','pre_save_character_etc_properties'),(799,1,'Indun_ResetTime','s','202604625081405','2026-04-25 08:48:41','pre_save_character_etc_properties'),(800,1,'LastPlayDate','f','20210728','2026-04-25 08:48:41','pre_save_character_etc_properties'),(801,1,'MaxWarehouseCount','f','2000','2026-04-25 08:48:41','pre_save_character_etc_properties'),(802,1,'SkintoneName','s','skintone2','2026-04-25 08:48:41','pre_save_character_etc_properties'),(803,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 08:48:41','pre_save_character_etc_properties'),(807,1,'AbilityPoint','s','0','2026-04-25 08:51:07','pre_save_character_properties'),(808,1,'CON_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(809,1,'CON_STAT','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(810,1,'DashRun','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(811,1,'DEX_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(812,1,'DEX_STAT','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(813,1,'HP','f','405','2026-04-25 08:51:07','pre_save_character_properties'),(814,1,'INT_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(815,1,'INT_STAT','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(816,1,'Lv','f','1','2026-04-25 08:51:07','pre_save_character_properties'),(817,1,'MAXSTA_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(818,1,'MaxWeight_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(819,1,'MHP_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(820,1,'MNA_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(821,1,'MNA_STAT','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(822,1,'MSPD_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(823,1,'MSP_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(824,1,'SP','f','207','2026-04-25 08:51:07','pre_save_character_properties'),(825,1,'StatByBonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(826,1,'StatByLevel','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(827,1,'STR_Bonus','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(828,1,'STR_STAT','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(829,1,'UsedStat','f','0','2026-04-25 08:51:07','pre_save_character_properties'),(838,1,'CompanionAutoAtk','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(839,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 08:51:07','pre_save_character_etc_properties'),(840,1,'FirstPlay','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(841,1,'HAIR_WIG_Visible','f','1','2026-04-25 08:51:07','pre_save_character_etc_properties'),(842,1,'HAT_L_Visible','f','1','2026-04-25 08:51:07','pre_save_character_etc_properties'),(843,1,'HAT_T_Visible','f','1','2026-04-25 08:51:07','pre_save_character_etc_properties'),(844,1,'HAT_Visible','f','1','2026-04-25 08:51:07','pre_save_character_etc_properties'),(845,1,'InDunCountType_0','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(846,1,'InDunCountType_100','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(847,1,'InDunCountType_10000','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(848,1,'InDunCountType_1100','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(849,1,'InDunCountType_1200','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(850,1,'InDunCountType_2','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(851,1,'InDunCountType_200','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(852,1,'InDunCountType_300','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(853,1,'InDunCountType_400','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(854,1,'InDunCountType_500','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(855,1,'InDunCountType_600','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(856,1,'InDunCountType_700','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(857,1,'InDunCountType_8000','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(858,1,'InDunCountType_8003','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(859,1,'InDunCountType_900','f','0','2026-04-25 08:51:07','pre_save_character_etc_properties'),(860,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 08:51:07','pre_save_character_etc_properties'),(861,1,'Indun_ResetTime','s','202604625081405','2026-04-25 08:51:07','pre_save_character_etc_properties'),(862,1,'LastPlayDate','f','20210728','2026-04-25 08:51:07','pre_save_character_etc_properties'),(863,1,'MaxWarehouseCount','f','2000','2026-04-25 08:51:07','pre_save_character_etc_properties'),(864,1,'SkintoneName','s','skintone2','2026-04-25 08:51:07','pre_save_character_etc_properties'),(865,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 08:51:07','pre_save_character_etc_properties'),(869,1,'AbilityPoint','s','0','2026-04-25 09:17:10','pre_save_character_properties'),(870,1,'CON_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(871,1,'CON_STAT','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(872,1,'DashRun','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(873,1,'DEX_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(874,1,'DEX_STAT','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(875,1,'HP','f','405','2026-04-25 09:17:10','pre_save_character_properties'),(876,1,'INT_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(877,1,'INT_STAT','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(878,1,'Lv','f','1','2026-04-25 09:17:10','pre_save_character_properties'),(879,1,'MAXSTA_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(880,1,'MaxWeight_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(881,1,'MHP_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(882,1,'MNA_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(883,1,'MNA_STAT','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(884,1,'MSPD_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(885,1,'MSP_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(886,1,'SP','f','207','2026-04-25 09:17:10','pre_save_character_properties'),(887,1,'StatByBonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(888,1,'StatByLevel','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(889,1,'STR_Bonus','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(890,1,'STR_STAT','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(891,1,'UsedStat','f','0','2026-04-25 09:17:10','pre_save_character_properties'),(900,1,'CompanionAutoAtk','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(901,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 09:17:10','pre_save_character_etc_properties'),(902,1,'FirstPlay','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(903,1,'HAIR_WIG_Visible','f','1','2026-04-25 09:17:10','pre_save_character_etc_properties'),(904,1,'HAT_L_Visible','f','1','2026-04-25 09:17:10','pre_save_character_etc_properties'),(905,1,'HAT_T_Visible','f','1','2026-04-25 09:17:10','pre_save_character_etc_properties'),(906,1,'HAT_Visible','f','1','2026-04-25 09:17:10','pre_save_character_etc_properties'),(907,1,'InDunCountType_0','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(908,1,'InDunCountType_100','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(909,1,'InDunCountType_10000','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(910,1,'InDunCountType_1100','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(911,1,'InDunCountType_1200','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(912,1,'InDunCountType_2','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(913,1,'InDunCountType_200','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(914,1,'InDunCountType_300','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(915,1,'InDunCountType_400','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(916,1,'InDunCountType_500','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(917,1,'InDunCountType_600','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(918,1,'InDunCountType_700','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(919,1,'InDunCountType_8000','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(920,1,'InDunCountType_8003','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(921,1,'InDunCountType_900','f','0','2026-04-25 09:17:10','pre_save_character_etc_properties'),(922,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 09:17:10','pre_save_character_etc_properties'),(923,1,'Indun_ResetTime','s','202604625081405','2026-04-25 09:17:10','pre_save_character_etc_properties'),(924,1,'LastPlayDate','f','20210728','2026-04-25 09:17:10','pre_save_character_etc_properties'),(925,1,'MaxWarehouseCount','f','2000','2026-04-25 09:17:10','pre_save_character_etc_properties'),(926,1,'SkintoneName','s','skintone2','2026-04-25 09:17:10','pre_save_character_etc_properties'),(927,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 09:17:10','pre_save_character_etc_properties'),(931,1,'AbilityPoint','s','0','2026-04-25 09:17:23','pre_save_character_properties'),(932,1,'CON_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(933,1,'CON_STAT','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(934,1,'DashRun','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(935,1,'DEX_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(936,1,'DEX_STAT','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(937,1,'HP','f','405','2026-04-25 09:17:23','pre_save_character_properties'),(938,1,'INT_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(939,1,'INT_STAT','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(940,1,'Lv','f','1','2026-04-25 09:17:23','pre_save_character_properties'),(941,1,'MAXSTA_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(942,1,'MaxWeight_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(943,1,'MHP_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(944,1,'MNA_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(945,1,'MNA_STAT','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(946,1,'MSPD_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(947,1,'MSP_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(948,1,'SP','f','207','2026-04-25 09:17:23','pre_save_character_properties'),(949,1,'StatByBonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(950,1,'StatByLevel','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(951,1,'STR_Bonus','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(952,1,'STR_STAT','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(953,1,'UsedStat','f','0','2026-04-25 09:17:23','pre_save_character_properties'),(962,1,'CompanionAutoAtk','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(963,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 09:17:23','pre_save_character_etc_properties'),(964,1,'FirstPlay','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(965,1,'HAIR_WIG_Visible','f','1','2026-04-25 09:17:23','pre_save_character_etc_properties'),(966,1,'HAT_L_Visible','f','1','2026-04-25 09:17:23','pre_save_character_etc_properties'),(967,1,'HAT_T_Visible','f','1','2026-04-25 09:17:23','pre_save_character_etc_properties'),(968,1,'HAT_Visible','f','1','2026-04-25 09:17:23','pre_save_character_etc_properties'),(969,1,'InDunCountType_0','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(970,1,'InDunCountType_100','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(971,1,'InDunCountType_10000','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(972,1,'InDunCountType_1100','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(973,1,'InDunCountType_1200','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(974,1,'InDunCountType_2','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(975,1,'InDunCountType_200','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(976,1,'InDunCountType_300','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(977,1,'InDunCountType_400','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(978,1,'InDunCountType_500','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(979,1,'InDunCountType_600','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(980,1,'InDunCountType_700','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(981,1,'InDunCountType_8000','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(982,1,'InDunCountType_8003','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(983,1,'InDunCountType_900','f','0','2026-04-25 09:17:23','pre_save_character_etc_properties'),(984,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 09:17:23','pre_save_character_etc_properties'),(985,1,'Indun_ResetTime','s','202604625081405','2026-04-25 09:17:23','pre_save_character_etc_properties'),(986,1,'LastPlayDate','f','20210728','2026-04-25 09:17:23','pre_save_character_etc_properties'),(987,1,'MaxWarehouseCount','f','2000','2026-04-25 09:17:23','pre_save_character_etc_properties'),(988,1,'SkintoneName','s','skintone2','2026-04-25 09:17:23','pre_save_character_etc_properties'),(989,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 09:17:23','pre_save_character_etc_properties'),(993,1,'AbilityPoint','s','0','2026-04-25 09:38:10','pre_save_character_properties'),(994,1,'CON_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(995,1,'CON_STAT','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(996,1,'DashRun','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(997,1,'DEX_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(998,1,'DEX_STAT','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(999,1,'HP','f','405','2026-04-25 09:38:10','pre_save_character_properties'),(1000,1,'INT_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1001,1,'INT_STAT','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1002,1,'Lv','f','1','2026-04-25 09:38:10','pre_save_character_properties'),(1003,1,'MAXSTA_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1004,1,'MaxWeight_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1005,1,'MHP_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1006,1,'MNA_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1007,1,'MNA_STAT','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1008,1,'MSPD_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1009,1,'MSP_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1010,1,'SP','f','207','2026-04-25 09:38:10','pre_save_character_properties'),(1011,1,'StatByBonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1012,1,'StatByLevel','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1013,1,'STR_Bonus','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1014,1,'STR_STAT','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1015,1,'UsedStat','f','0','2026-04-25 09:38:10','pre_save_character_properties'),(1024,1,'CompanionAutoAtk','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1025,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1026,1,'FirstPlay','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1027,1,'HAIR_WIG_Visible','f','1','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1028,1,'HAT_L_Visible','f','1','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1029,1,'HAT_T_Visible','f','1','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1030,1,'HAT_Visible','f','1','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1031,1,'InDunCountType_0','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1032,1,'InDunCountType_100','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1033,1,'InDunCountType_10000','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1034,1,'InDunCountType_1100','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1035,1,'InDunCountType_1200','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1036,1,'InDunCountType_2','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1037,1,'InDunCountType_200','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1038,1,'InDunCountType_300','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1039,1,'InDunCountType_400','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1040,1,'InDunCountType_500','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1041,1,'InDunCountType_600','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1042,1,'InDunCountType_700','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1043,1,'InDunCountType_8000','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1044,1,'InDunCountType_8003','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1045,1,'InDunCountType_900','f','0','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1046,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1047,1,'Indun_ResetTime','s','202604625081405','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1048,1,'LastPlayDate','f','20210728','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1049,1,'MaxWarehouseCount','f','2000','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1050,1,'SkintoneName','s','skintone2','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1051,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 09:38:10','pre_save_character_etc_properties'),(1055,3,'AbilityPoint','s','0','2026-04-25 09:44:03','pre_save_character_properties'),(1056,3,'CON_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1057,3,'CON_STAT','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1058,3,'DashRun','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1059,3,'DEX_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1060,3,'DEX_STAT','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1061,3,'HP','f','367','2026-04-25 09:44:03','pre_save_character_properties'),(1062,3,'INT_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1063,3,'INT_STAT','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1064,3,'Lv','f','1','2026-04-25 09:44:03','pre_save_character_properties'),(1065,3,'MAXSTA_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1066,3,'MaxWeight_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1067,3,'MHP_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1068,3,'MNA_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1069,3,'MNA_STAT','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1070,3,'MSPD_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1071,3,'MSP_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1072,3,'SP','f','376','2026-04-25 09:44:03','pre_save_character_properties'),(1073,3,'StatByBonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1074,3,'StatByLevel','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1075,3,'STR_Bonus','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1076,3,'STR_STAT','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1077,3,'UsedStat','f','0','2026-04-25 09:44:03','pre_save_character_properties'),(1086,3,'CompanionAutoAtk','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1087,3,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1088,3,'FirstPlay','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1089,3,'HAIR_WIG_Visible','f','1','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1090,3,'HAT_L_Visible','f','1','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1091,3,'HAT_T_Visible','f','1','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1092,3,'HAT_Visible','f','1','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1093,3,'InDunCountType_0','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1094,3,'InDunCountType_100','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1095,3,'InDunCountType_10000','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1096,3,'InDunCountType_1100','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1097,3,'InDunCountType_1200','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1098,3,'InDunCountType_2','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1099,3,'InDunCountType_200','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1100,3,'InDunCountType_300','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1101,3,'InDunCountType_400','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1102,3,'InDunCountType_500','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1103,3,'InDunCountType_600','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1104,3,'InDunCountType_700','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1105,3,'InDunCountType_8000','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1106,3,'InDunCountType_8003','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1107,3,'InDunCountType_900','f','0','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1108,3,'IndunWeeklyResetTime','s','202604625093923','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1109,3,'Indun_ResetTime','s','202604625093923','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1110,3,'LastPlayDate','f','20210728','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1111,3,'MaxWarehouseCount','f','2000','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1112,3,'SkintoneName','s','skintone2','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1113,3,'StartHairName','s','UnbalancedShortcut','2026-04-25 09:44:03','pre_save_character_etc_properties'),(1117,3,'AbilityPoint','s','0','2026-04-25 09:45:40','pre_save_character_properties'),(1118,3,'CON_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1119,3,'CON_STAT','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1120,3,'DashRun','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1121,3,'DEX_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1122,3,'DEX_STAT','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1123,3,'HP','f','367','2026-04-25 09:45:40','pre_save_character_properties'),(1124,3,'INT_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1125,3,'INT_STAT','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1126,3,'Lv','f','1','2026-04-25 09:45:40','pre_save_character_properties'),(1127,3,'MAXSTA_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1128,3,'MaxWeight_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1129,3,'MHP_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1130,3,'MNA_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1131,3,'MNA_STAT','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1132,3,'MSPD_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1133,3,'MSP_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1134,3,'SP','f','465','2026-04-25 09:45:40','pre_save_character_properties'),(1135,3,'StatByBonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1136,3,'StatByLevel','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1137,3,'STR_Bonus','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1138,3,'STR_STAT','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1139,3,'UsedStat','f','0','2026-04-25 09:45:40','pre_save_character_properties'),(1148,3,'CompanionAutoAtk','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1149,3,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1150,3,'FirstPlay','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1151,3,'HAIR_WIG_Visible','f','1','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1152,3,'HAT_L_Visible','f','1','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1153,3,'HAT_T_Visible','f','1','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1154,3,'HAT_Visible','f','1','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1155,3,'InDunCountType_0','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1156,3,'InDunCountType_100','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1157,3,'InDunCountType_10000','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1158,3,'InDunCountType_1100','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1159,3,'InDunCountType_1200','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1160,3,'InDunCountType_2','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1161,3,'InDunCountType_200','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1162,3,'InDunCountType_300','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1163,3,'InDunCountType_400','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1164,3,'InDunCountType_500','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1165,3,'InDunCountType_600','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1166,3,'InDunCountType_700','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1167,3,'InDunCountType_8000','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1168,3,'InDunCountType_8003','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1169,3,'InDunCountType_900','f','0','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1170,3,'IndunWeeklyResetTime','s','202604625093923','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1171,3,'Indun_ResetTime','s','202604625093923','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1172,3,'LastPlayDate','f','20210728','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1173,3,'MaxWarehouseCount','f','2000','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1174,3,'SkintoneName','s','skintone2','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1175,3,'StartHairName','s','UnbalancedShortcut','2026-04-25 09:45:40','pre_save_character_etc_properties'),(1179,4,'AbilityPoint','s','0','2026-04-25 10:02:01','pre_save_character_properties'),(1180,4,'CON_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1181,4,'CON_STAT','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1182,4,'DashRun','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1183,4,'DEX_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1184,4,'DEX_STAT','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1185,4,'HP','f','396','2026-04-25 10:02:01','pre_save_character_properties'),(1186,4,'INT_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1187,4,'INT_STAT','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1188,4,'Lv','f','1','2026-04-25 10:02:01','pre_save_character_properties'),(1189,4,'MAXSTA_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1190,4,'MaxWeight_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1191,4,'MHP_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1192,4,'MNA_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1193,4,'MNA_STAT','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1194,4,'MSPD_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1195,4,'MSP_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1196,4,'SP','f','207','2026-04-25 10:02:01','pre_save_character_properties'),(1197,4,'StatByBonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1198,4,'StatByLevel','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1199,4,'STR_Bonus','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1200,4,'STR_STAT','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1201,4,'UsedStat','f','0','2026-04-25 10:02:01','pre_save_character_properties'),(1210,4,'CompanionAutoAtk','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1211,4,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1212,4,'FirstPlay','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1213,4,'HAIR_WIG_Visible','f','1','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1214,4,'HAT_L_Visible','f','1','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1215,4,'HAT_T_Visible','f','1','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1216,4,'HAT_Visible','f','1','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1217,4,'InDunCountType_0','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1218,4,'InDunCountType_100','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1219,4,'InDunCountType_10000','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1220,4,'InDunCountType_1100','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1221,4,'InDunCountType_1200','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1222,4,'InDunCountType_2','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1223,4,'InDunCountType_200','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1224,4,'InDunCountType_300','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1225,4,'InDunCountType_400','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1226,4,'InDunCountType_500','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1227,4,'InDunCountType_600','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1228,4,'InDunCountType_700','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1229,4,'InDunCountType_8000','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1230,4,'InDunCountType_8003','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1231,4,'InDunCountType_900','f','0','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1232,4,'IndunWeeklyResetTime','s','202604625100016','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1233,4,'Indun_ResetTime','s','202604625100016','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1234,4,'LastPlayDate','f','20210728','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1235,4,'MaxWarehouseCount','f','2000','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1236,4,'SkintoneName','s','skintone2','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1237,4,'StartHairName','s','UnbalancedShortcut','2026-04-25 10:02:01','pre_save_character_etc_properties'),(1241,4,'AbilityPoint','s','0','2026-04-25 10:32:09','pre_save_character_properties'),(1242,4,'CON_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1243,4,'CON_STAT','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1244,4,'DashRun','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1245,4,'DEX_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1246,4,'DEX_STAT','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1247,4,'HP','f','396','2026-04-25 10:32:09','pre_save_character_properties'),(1248,4,'INT_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1249,4,'INT_STAT','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1250,4,'Lv','f','1','2026-04-25 10:32:09','pre_save_character_properties'),(1251,4,'MAXSTA_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1252,4,'MaxWeight_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1253,4,'MHP_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1254,4,'MNA_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1255,4,'MNA_STAT','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1256,4,'MSPD_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1257,4,'MSP_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1258,4,'SP','f','207','2026-04-25 10:32:09','pre_save_character_properties'),(1259,4,'StatByBonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1260,4,'StatByLevel','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1261,4,'STR_Bonus','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1262,4,'STR_STAT','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1263,4,'UsedStat','f','0','2026-04-25 10:32:09','pre_save_character_properties'),(1272,4,'CompanionAutoAtk','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1273,4,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1274,4,'FirstPlay','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1275,4,'HAIR_WIG_Visible','f','1','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1276,4,'HAT_L_Visible','f','1','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1277,4,'HAT_T_Visible','f','1','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1278,4,'HAT_Visible','f','1','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1279,4,'InDunCountType_0','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1280,4,'InDunCountType_100','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1281,4,'InDunCountType_10000','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1282,4,'InDunCountType_1100','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1283,4,'InDunCountType_1200','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1284,4,'InDunCountType_2','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1285,4,'InDunCountType_200','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1286,4,'InDunCountType_300','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1287,4,'InDunCountType_400','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1288,4,'InDunCountType_500','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1289,4,'InDunCountType_600','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1290,4,'InDunCountType_700','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1291,4,'InDunCountType_8000','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1292,4,'InDunCountType_8003','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1293,4,'InDunCountType_900','f','0','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1294,4,'IndunWeeklyResetTime','s','202604625100016','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1295,4,'Indun_ResetTime','s','202604625100016','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1296,4,'LastPlayDate','f','20210728','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1297,4,'MaxWarehouseCount','f','2000','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1298,4,'SkintoneName','s','skintone2','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1299,4,'StartHairName','s','UnbalancedShortcut','2026-04-25 10:32:09','pre_save_character_etc_properties'),(1303,2,'AbilityPoint','s','0','2026-04-25 10:35:49','pre_save_character_properties'),(1304,2,'CON_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1305,2,'CON_STAT','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1306,2,'DashRun','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1307,2,'DEX_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1308,2,'DEX_STAT','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1309,2,'HP','f','467','2026-04-25 10:35:49','pre_save_character_properties'),(1310,2,'INT_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1311,2,'INT_STAT','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1312,2,'Lv','f','1','2026-04-25 10:35:49','pre_save_character_properties'),(1313,2,'MAXSTA_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1314,2,'MaxWeight_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1315,2,'MHP_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1316,2,'MNA_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1317,2,'MNA_STAT','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1318,2,'MSPD_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1319,2,'MSP_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1320,2,'SP','f','207','2026-04-25 10:35:49','pre_save_character_properties'),(1321,2,'StatByBonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1322,2,'StatByLevel','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1323,2,'STR_Bonus','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1324,2,'STR_STAT','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1325,2,'UsedStat','f','0','2026-04-25 10:35:49','pre_save_character_properties'),(1334,2,'CompanionAutoAtk','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1335,2,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1336,2,'FirstPlay','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1337,2,'HAIR_WIG_Visible','f','1','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1338,2,'HAT_L_Visible','f','1','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1339,2,'HAT_T_Visible','f','1','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1340,2,'HAT_Visible','f','1','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1341,2,'InDunCountType_0','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1342,2,'InDunCountType_100','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1343,2,'InDunCountType_10000','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1344,2,'InDunCountType_1100','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1345,2,'InDunCountType_1200','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1346,2,'InDunCountType_2','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1347,2,'InDunCountType_200','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1348,2,'InDunCountType_300','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1349,2,'InDunCountType_400','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1350,2,'InDunCountType_500','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1351,2,'InDunCountType_600','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1352,2,'InDunCountType_700','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1353,2,'InDunCountType_8000','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1354,2,'InDunCountType_8003','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1355,2,'InDunCountType_900','f','0','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1356,2,'IndunWeeklyResetTime','s','202604524224852','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1357,2,'Indun_ResetTime','s','202604524224852','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1358,2,'LastPlayDate','f','20210728','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1359,2,'MaxWarehouseCount','f','2000','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1360,2,'SkintoneName','s','skintone2','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1361,2,'StartHairName','s','UnbalancedShortcut','2026-04-25 10:35:49','pre_save_character_etc_properties'),(1365,6,'AbilityPoint','s','0','2026-04-25 11:12:54','pre_save_character_properties'),(1366,6,'CON_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1367,6,'CON_STAT','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1368,6,'DashRun','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1369,6,'DEX_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1370,6,'DEX_STAT','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1371,6,'HP','f','467','2026-04-25 11:12:54','pre_save_character_properties'),(1372,6,'INT_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1373,6,'INT_STAT','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1374,6,'Lv','f','1','2026-04-25 11:12:54','pre_save_character_properties'),(1375,6,'MAXSTA_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1376,6,'MaxWeight_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1377,6,'MHP_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1378,6,'MNA_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1379,6,'MNA_STAT','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1380,6,'MSPD_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1381,6,'MSP_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1382,6,'SP','f','207','2026-04-25 11:12:54','pre_save_character_properties'),(1383,6,'StatByBonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1384,6,'StatByLevel','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1385,6,'STR_Bonus','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1386,6,'STR_STAT','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1387,6,'UsedStat','f','0','2026-04-25 11:12:54','pre_save_character_properties'),(1396,6,'CompanionAutoAtk','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1397,6,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1398,6,'FirstPlay','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1399,6,'HAIR_WIG_Visible','f','1','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1400,6,'HAT_L_Visible','f','1','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1401,6,'HAT_T_Visible','f','1','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1402,6,'HAT_Visible','f','1','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1403,6,'InDunCountType_0','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1404,6,'InDunCountType_100','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1405,6,'InDunCountType_10000','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1406,6,'InDunCountType_1100','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1407,6,'InDunCountType_1200','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1408,6,'InDunCountType_2','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1409,6,'InDunCountType_200','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1410,6,'InDunCountType_300','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1411,6,'InDunCountType_400','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1412,6,'InDunCountType_500','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1413,6,'InDunCountType_600','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1414,6,'InDunCountType_700','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1415,6,'InDunCountType_8000','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1416,6,'InDunCountType_8003','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1417,6,'InDunCountType_900','f','0','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1418,6,'IndunWeeklyResetTime','s','202604625105541','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1419,6,'Indun_ResetTime','s','202604625105541','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1420,6,'LastPlayDate','f','20210728','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1421,6,'MaxWarehouseCount','f','2000','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1422,6,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1423,6,'SkintoneName','s','skintone2','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1424,6,'StartHairName','s','UnbalancedShortcut','2026-04-25 11:12:54','pre_save_character_etc_properties'),(1427,8,'AbilityPoint','s','0','2026-04-25 11:40:01','pre_save_character_properties'),(1428,8,'CON_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1429,8,'CON_STAT','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1430,8,'DashRun','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1431,8,'DEX_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1432,8,'DEX_STAT','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1433,8,'HP','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1434,8,'INT_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1435,8,'INT_STAT','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1436,8,'Lv','f','1','2026-04-25 11:40:01','pre_save_character_properties'),(1437,8,'MAXSTA_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1438,8,'MaxWeight_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1439,8,'MHP_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1440,8,'MNA_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1441,8,'MNA_STAT','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1442,8,'MSPD_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1443,8,'MSP_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1444,8,'SP','f','207','2026-04-25 11:40:01','pre_save_character_properties'),(1445,8,'StatByBonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1446,8,'StatByLevel','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1447,8,'STR_Bonus','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1448,8,'STR_STAT','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1449,8,'UsedStat','f','0','2026-04-25 11:40:01','pre_save_character_properties'),(1458,8,'CompanionAutoAtk','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1459,8,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1460,8,'FirstPlay','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1461,8,'HAIR_WIG_Visible','f','1','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1462,8,'HAT_L_Visible','f','1','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1463,8,'HAT_T_Visible','f','1','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1464,8,'HAT_Visible','f','1','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1465,8,'InDunCountType_0','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1466,8,'InDunCountType_100','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1467,8,'InDunCountType_10000','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1468,8,'InDunCountType_1100','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1469,8,'InDunCountType_1200','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1470,8,'InDunCountType_2','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1471,8,'InDunCountType_200','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1472,8,'InDunCountType_300','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1473,8,'InDunCountType_400','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1474,8,'InDunCountType_500','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1475,8,'InDunCountType_600','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1476,8,'InDunCountType_700','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1477,8,'InDunCountType_8000','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1478,8,'InDunCountType_8003','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1479,8,'InDunCountType_900','f','0','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1480,8,'IndunWeeklyResetTime','s','202604625113555','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1481,8,'Indun_ResetTime','s','202604625113555','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1482,8,'LastPlayDate','f','20210728','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1483,8,'MaxWarehouseCount','f','2000','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1484,8,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1485,8,'SkintoneName','s','skintone2','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1486,8,'StartHairName','s','UnbalancedShortcut','2026-04-25 11:40:01','pre_save_character_etc_properties'),(1489,8,'AbilityPoint','s','0','2026-04-25 11:40:42','pre_save_character_properties'),(1490,8,'CON_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1491,8,'CON_STAT','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1492,8,'DashRun','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1493,8,'DEX_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1494,8,'DEX_STAT','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1495,8,'HP','f','101.25','2026-04-25 11:40:42','pre_save_character_properties'),(1496,8,'INT_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1497,8,'INT_STAT','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1498,8,'Lv','f','1','2026-04-25 11:40:42','pre_save_character_properties'),(1499,8,'MAXSTA_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1500,8,'MaxWeight_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1501,8,'MHP_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1502,8,'MNA_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1503,8,'MNA_STAT','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1504,8,'MSPD_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1505,8,'MSP_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1506,8,'SP','f','207','2026-04-25 11:40:42','pre_save_character_properties'),(1507,8,'StatByBonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1508,8,'StatByLevel','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1509,8,'STR_Bonus','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1510,8,'STR_STAT','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1511,8,'UsedStat','f','0','2026-04-25 11:40:42','pre_save_character_properties'),(1520,8,'CompanionAutoAtk','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1521,8,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1522,8,'FirstPlay','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1523,8,'HAIR_WIG_Visible','f','1','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1524,8,'HAT_L_Visible','f','1','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1525,8,'HAT_T_Visible','f','1','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1526,8,'HAT_Visible','f','1','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1527,8,'InDunCountType_0','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1528,8,'InDunCountType_100','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1529,8,'InDunCountType_10000','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1530,8,'InDunCountType_1100','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1531,8,'InDunCountType_1200','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1532,8,'InDunCountType_2','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1533,8,'InDunCountType_200','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1534,8,'InDunCountType_300','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1535,8,'InDunCountType_400','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1536,8,'InDunCountType_500','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1537,8,'InDunCountType_600','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1538,8,'InDunCountType_700','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1539,8,'InDunCountType_8000','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1540,8,'InDunCountType_8003','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1541,8,'InDunCountType_900','f','0','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1542,8,'IndunWeeklyResetTime','s','202604625113555','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1543,8,'Indun_ResetTime','s','202604625113555','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1544,8,'LastPlayDate','f','20210728','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1545,8,'MaxWarehouseCount','f','2000','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1546,8,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1547,8,'SkintoneName','s','skintone2','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1548,8,'StartHairName','s','UnbalancedShortcut','2026-04-25 11:40:42','pre_save_character_etc_properties'),(1551,9,'AbilityPoint','s','0','2026-04-25 11:58:04','pre_save_character_properties'),(1552,9,'CON_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1553,9,'CON_STAT','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1554,9,'DashRun','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1555,9,'DEX_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1556,9,'DEX_STAT','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1557,9,'HP','f','367','2026-04-25 11:58:04','pre_save_character_properties'),(1558,9,'INT_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1559,9,'INT_STAT','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1560,9,'Lv','f','1','2026-04-25 11:58:04','pre_save_character_properties'),(1561,9,'MAXSTA_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1562,9,'MaxWeight_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1563,9,'MHP_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1564,9,'MNA_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1565,9,'MNA_STAT','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1566,9,'MSPD_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1567,9,'MSP_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1568,9,'SP','f','465','2026-04-25 11:58:04','pre_save_character_properties'),(1569,9,'StatByBonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1570,9,'StatByLevel','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1571,9,'STR_Bonus','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1572,9,'STR_STAT','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1573,9,'UsedStat','f','0','2026-04-25 11:58:04','pre_save_character_properties'),(1582,9,'CompanionAutoAtk','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1583,9,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1584,9,'FirstPlay','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1585,9,'HAIR_WIG_Visible','f','1','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1586,9,'HAT_L_Visible','f','1','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1587,9,'HAT_T_Visible','f','1','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1588,9,'HAT_Visible','f','1','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1589,9,'InDunCountType_0','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1590,9,'InDunCountType_100','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1591,9,'InDunCountType_10000','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1592,9,'InDunCountType_1100','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1593,9,'InDunCountType_1200','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1594,9,'InDunCountType_2','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1595,9,'InDunCountType_200','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1596,9,'InDunCountType_300','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1597,9,'InDunCountType_400','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1598,9,'InDunCountType_500','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1599,9,'InDunCountType_600','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1600,9,'InDunCountType_700','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1601,9,'InDunCountType_8000','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1602,9,'InDunCountType_8003','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1603,9,'InDunCountType_900','f','0','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1604,9,'IndunWeeklyResetTime','s','202604625115238','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1605,9,'Indun_ResetTime','s','202604625115238','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1606,9,'LastPlayDate','f','20210728','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1607,9,'MaxWarehouseCount','f','2000','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1608,9,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1609,9,'SkintoneName','s','skintone2','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1610,9,'StartHairName','s','UnbalancedShortcut','2026-04-25 11:58:04','pre_save_character_etc_properties'),(1613,10,'AbilityPoint','s','0','2026-04-25 12:31:21','pre_save_character_properties'),(1614,10,'CON_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1615,10,'CON_STAT','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1616,10,'DashRun','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1617,10,'DEX_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1618,10,'DEX_STAT','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1619,10,'HP','f','91.75','2026-04-25 12:31:21','pre_save_character_properties'),(1620,10,'INT_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1621,10,'INT_STAT','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1622,10,'Lv','f','1','2026-04-25 12:31:21','pre_save_character_properties'),(1623,10,'MAXSTA_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1624,10,'MaxWeight_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1625,10,'MHP_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1626,10,'MNA_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1627,10,'MNA_STAT','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1628,10,'MSPD_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1629,10,'MSP_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1630,10,'SP','f','415','2026-04-25 12:31:21','pre_save_character_properties'),(1631,10,'StatByBonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1632,10,'StatByLevel','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1633,10,'STR_Bonus','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1634,10,'STR_STAT','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1635,10,'UsedStat','f','0','2026-04-25 12:31:21','pre_save_character_properties'),(1644,10,'CompanionAutoAtk','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1645,10,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1646,10,'FirstPlay','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1647,10,'HAIR_WIG_Visible','f','1','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1648,10,'HAT_L_Visible','f','1','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1649,10,'HAT_T_Visible','f','1','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1650,10,'HAT_Visible','f','1','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1651,10,'InDunCountType_0','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1652,10,'InDunCountType_100','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1653,10,'InDunCountType_10000','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1654,10,'InDunCountType_1100','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1655,10,'InDunCountType_1200','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1656,10,'InDunCountType_2','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1657,10,'InDunCountType_200','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1658,10,'InDunCountType_300','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1659,10,'InDunCountType_400','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1660,10,'InDunCountType_500','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1661,10,'InDunCountType_600','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1662,10,'InDunCountType_700','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1663,10,'InDunCountType_8000','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1664,10,'InDunCountType_8003','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1665,10,'InDunCountType_900','f','0','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1666,10,'IndunWeeklyResetTime','s','202604625122921','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1667,10,'Indun_ResetTime','s','202604625122921','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1668,10,'LastPlayDate','f','20210728','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1669,10,'MaxWarehouseCount','f','2000','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1670,10,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1671,10,'SkintoneName','s','skintone2','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1672,10,'StartHairName','s','UnbalancedShortcut','2026-04-25 12:31:21','pre_save_character_etc_properties'),(1675,14,'AbilityPoint','s','0','2026-04-25 13:40:04','pre_save_character_properties'),(1676,14,'CON_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1677,14,'CON_STAT','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1678,14,'DashRun','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1679,14,'DEX_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1680,14,'DEX_STAT','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1681,14,'HP','f','467','2026-04-25 13:40:04','pre_save_character_properties'),(1682,14,'INT_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1683,14,'INT_STAT','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1684,14,'Lv','f','1','2026-04-25 13:40:04','pre_save_character_properties'),(1685,14,'MAXSTA_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1686,14,'MaxWeight_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1687,14,'MHP_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1688,14,'MNA_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1689,14,'MNA_STAT','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1690,14,'MSPD_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1691,14,'MSP_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1692,14,'SP','f','207','2026-04-25 13:40:04','pre_save_character_properties'),(1693,14,'StatByBonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1694,14,'StatByLevel','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1695,14,'STR_Bonus','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1696,14,'STR_STAT','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1697,14,'UsedStat','f','0','2026-04-25 13:40:04','pre_save_character_properties'),(1706,14,'CompanionAutoAtk','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1707,14,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1708,14,'FirstPlay','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1709,14,'HAIR_WIG_Visible','f','1','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1710,14,'HAT_L_Visible','f','1','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1711,14,'HAT_T_Visible','f','1','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1712,14,'HAT_Visible','f','1','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1713,14,'InDunCountType_0','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1714,14,'InDunCountType_100','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1715,14,'InDunCountType_10000','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1716,14,'InDunCountType_1100','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1717,14,'InDunCountType_1200','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1718,14,'InDunCountType_2','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1719,14,'InDunCountType_200','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1720,14,'InDunCountType_300','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1721,14,'InDunCountType_400','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1722,14,'InDunCountType_500','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1723,14,'InDunCountType_600','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1724,14,'InDunCountType_700','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1725,14,'InDunCountType_8000','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1726,14,'InDunCountType_8003','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1727,14,'InDunCountType_900','f','0','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1728,14,'IndunWeeklyResetTime','s','202604625133311','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1729,14,'Indun_ResetTime','s','202604625133311','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1730,14,'LastPlayDate','f','20210728','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1731,14,'MaxWarehouseCount','f','2000','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1732,14,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1733,14,'SkintoneName','s','skintone2','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1734,14,'StartHairName','s','UnbalancedShortcut','2026-04-25 13:40:04','pre_save_character_etc_properties'),(1737,15,'AbilityPoint','s','0','2026-04-25 14:16:13','pre_save_character_properties'),(1738,15,'CON_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1739,15,'CON_STAT','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1740,15,'DashRun','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1741,15,'DEX_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1742,15,'DEX_STAT','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1743,15,'HP','f','396','2026-04-25 14:16:13','pre_save_character_properties'),(1744,15,'INT_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1745,15,'INT_STAT','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1746,15,'Lv','f','1','2026-04-25 14:16:13','pre_save_character_properties'),(1747,15,'MAXSTA_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1748,15,'MaxWeight_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1749,15,'MHP_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1750,15,'MNA_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1751,15,'MNA_STAT','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1752,15,'MSPD_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1753,15,'MSP_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1754,15,'SP','f','207','2026-04-25 14:16:13','pre_save_character_properties'),(1755,15,'StatByBonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1756,15,'StatByLevel','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1757,15,'STR_Bonus','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1758,15,'STR_STAT','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1759,15,'UsedStat','f','0','2026-04-25 14:16:13','pre_save_character_properties'),(1768,15,'CompanionAutoAtk','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1769,15,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1770,15,'FirstPlay','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1771,15,'HAIR_WIG_Visible','f','1','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1772,15,'HAT_L_Visible','f','1','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1773,15,'HAT_T_Visible','f','1','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1774,15,'HAT_Visible','f','1','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1775,15,'InDunCountType_0','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1776,15,'InDunCountType_100','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1777,15,'InDunCountType_10000','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1778,15,'InDunCountType_1100','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1779,15,'InDunCountType_1200','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1780,15,'InDunCountType_2','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1781,15,'InDunCountType_200','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1782,15,'InDunCountType_300','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1783,15,'InDunCountType_400','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1784,15,'InDunCountType_500','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1785,15,'InDunCountType_600','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1786,15,'InDunCountType_700','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1787,15,'InDunCountType_8000','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1788,15,'InDunCountType_8003','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1789,15,'InDunCountType_900','f','0','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1790,15,'IndunWeeklyResetTime','s','202604625141304','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1791,15,'Indun_ResetTime','s','202604625141304','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1792,15,'LastPlayDate','f','20210728','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1793,15,'MaxWarehouseCount','f','2000','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1794,15,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1795,15,'SkintoneName','s','skintone2','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1796,15,'StartHairName','s','UnbalancedShortcut','2026-04-25 14:16:13','pre_save_character_etc_properties'),(1799,16,'AbilityPoint','s','0','2026-04-25 14:55:21','pre_save_character_properties'),(1800,16,'CON_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1801,16,'CON_STAT','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1802,16,'DashRun','f','1','2026-04-25 14:55:21','pre_save_character_properties'),(1803,16,'DEX_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1804,16,'DEX_STAT','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1805,16,'HP','f','129','2026-04-25 14:55:21','pre_save_character_properties'),(1806,16,'INT_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1807,16,'INT_STAT','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1808,16,'Lv','f','1','2026-04-25 14:55:21','pre_save_character_properties'),(1809,16,'MAXSTA_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1810,16,'MaxWeight_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1811,16,'MHP_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1812,16,'MNA_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1813,16,'MNA_STAT','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1814,16,'MSPD_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1815,16,'MSP_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1816,16,'SP','f','460','2026-04-25 14:55:21','pre_save_character_properties'),(1817,16,'StatByBonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1818,16,'StatByLevel','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1819,16,'STR_Bonus','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1820,16,'STR_STAT','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1821,16,'UsedStat','f','0','2026-04-25 14:55:21','pre_save_character_properties'),(1830,16,'CompanionAutoAtk','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1831,16,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1832,16,'FirstPlay','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1833,16,'HAIR_WIG_Visible','f','1','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1834,16,'HAT_L_Visible','f','1','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1835,16,'HAT_T_Visible','f','1','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1836,16,'HAT_Visible','f','1','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1837,16,'InDunCountType_0','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1838,16,'InDunCountType_100','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1839,16,'InDunCountType_10000','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1840,16,'InDunCountType_1100','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1841,16,'InDunCountType_1200','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1842,16,'InDunCountType_2','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1843,16,'InDunCountType_200','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1844,16,'InDunCountType_300','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1845,16,'InDunCountType_400','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1846,16,'InDunCountType_500','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1847,16,'InDunCountType_600','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1848,16,'InDunCountType_700','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1849,16,'InDunCountType_8000','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1850,16,'InDunCountType_8003','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1851,16,'InDunCountType_900','f','0','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1852,16,'IndunWeeklyResetTime','s','202604625145357','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1853,16,'Indun_ResetTime','s','202604625145357','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1854,16,'LastPlayDate','f','20210728','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1855,16,'MaxWarehouseCount','f','2000','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1856,16,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1857,16,'SkintoneName','s','skintone2','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1858,16,'StartHairName','s','UnbalancedShortcut','2026-04-25 14:55:21','pre_save_character_etc_properties'),(1861,17,'AbilityPoint','s','0','2026-04-25 15:30:57','pre_save_character_properties'),(1862,17,'CON_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1863,17,'CON_STAT','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1864,17,'DashRun','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1865,17,'DEX_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1866,17,'DEX_STAT','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1867,17,'HP','f','438','2026-04-25 15:30:57','pre_save_character_properties'),(1868,17,'INT_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1869,17,'INT_STAT','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1870,17,'Lv','f','1','2026-04-25 15:30:57','pre_save_character_properties'),(1871,17,'MAXSTA_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1872,17,'MaxWeight_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1873,17,'MHP_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1874,17,'MNA_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1875,17,'MNA_STAT','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1876,17,'MSPD_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1877,17,'MSP_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1878,17,'SP','f','460','2026-04-25 15:30:57','pre_save_character_properties'),(1879,17,'StatByBonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1880,17,'StatByLevel','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1881,17,'STR_Bonus','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1882,17,'STR_STAT','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1883,17,'UsedStat','f','0','2026-04-25 15:30:57','pre_save_character_properties'),(1892,17,'CompanionAutoAtk','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1893,17,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1894,17,'FirstPlay','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1895,17,'HAIR_WIG_Visible','f','1','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1896,17,'HAT_L_Visible','f','1','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1897,17,'HAT_T_Visible','f','1','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1898,17,'HAT_Visible','f','1','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1899,17,'InDunCountType_0','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1900,17,'InDunCountType_100','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1901,17,'InDunCountType_10000','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1902,17,'InDunCountType_1100','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1903,17,'InDunCountType_1200','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1904,17,'InDunCountType_2','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1905,17,'InDunCountType_200','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1906,17,'InDunCountType_300','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1907,17,'InDunCountType_400','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1908,17,'InDunCountType_500','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1909,17,'InDunCountType_600','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1910,17,'InDunCountType_700','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1911,17,'InDunCountType_8000','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1912,17,'InDunCountType_8003','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1913,17,'InDunCountType_900','f','0','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1914,17,'IndunWeeklyResetTime','s','202604625152358','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1915,17,'Indun_ResetTime','s','202604625152358','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1916,17,'LastPlayDate','f','20210728','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1917,17,'MaxWarehouseCount','f','2000','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1918,17,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1919,17,'SkintoneName','s','skintone2','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1920,17,'StartHairName','s','UnbalancedShortcut','2026-04-25 15:30:57','pre_save_character_etc_properties'),(1923,19,'AbilityPoint','s','0','2026-04-25 16:22:19','pre_save_character_properties'),(1924,19,'CON_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1925,19,'CON_STAT','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1926,19,'DashRun','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1927,19,'DEX_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1928,19,'DEX_STAT','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1929,19,'HP','f','405','2026-04-25 16:22:19','pre_save_character_properties'),(1930,19,'INT_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1931,19,'INT_STAT','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1932,19,'Lv','f','1','2026-04-25 16:22:19','pre_save_character_properties'),(1933,19,'MAXSTA_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1934,19,'MaxWeight_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1935,19,'MHP_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1936,19,'MNA_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1937,19,'MNA_STAT','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1938,19,'MSPD_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1939,19,'MSP_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1940,19,'SP','f','207','2026-04-25 16:22:19','pre_save_character_properties'),(1941,19,'StatByBonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1942,19,'StatByLevel','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1943,19,'STR_Bonus','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1944,19,'STR_STAT','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1945,19,'UsedStat','f','0','2026-04-25 16:22:19','pre_save_character_properties'),(1954,19,'CompanionAutoAtk','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1955,19,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1956,19,'FirstPlay','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1957,19,'HAIR_WIG_Visible','f','1','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1958,19,'HAT_L_Visible','f','1','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1959,19,'HAT_T_Visible','f','1','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1960,19,'HAT_Visible','f','1','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1961,19,'InDunCountType_0','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1962,19,'InDunCountType_100','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1963,19,'InDunCountType_10000','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1964,19,'InDunCountType_1100','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1965,19,'InDunCountType_1200','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1966,19,'InDunCountType_2','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1967,19,'InDunCountType_200','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1968,19,'InDunCountType_300','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1969,19,'InDunCountType_400','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1970,19,'InDunCountType_500','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1971,19,'InDunCountType_600','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1972,19,'InDunCountType_700','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1973,19,'InDunCountType_8000','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1974,19,'InDunCountType_8003','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1975,19,'InDunCountType_900','f','0','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1976,19,'IndunWeeklyResetTime','s','202604625161721','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1977,19,'Indun_ResetTime','s','202604625161721','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1978,19,'LastPlayDate','f','20210728','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1979,19,'MaxWarehouseCount','f','2000','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1980,19,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1981,19,'SkintoneName','s','skintone2','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1982,19,'StartHairName','s','UnbalancedShortcut','2026-04-25 16:22:19','pre_save_character_etc_properties'),(1985,19,'AbilityPoint','s','0','2026-04-25 16:55:54','pre_save_character_properties'),(1986,19,'CON_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1987,19,'CON_STAT','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1988,19,'DashRun','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1989,19,'DEX_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1990,19,'DEX_STAT','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1991,19,'HP','f','405','2026-04-25 16:55:54','pre_save_character_properties'),(1992,19,'INT_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1993,19,'INT_STAT','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1994,19,'Lv','f','1','2026-04-25 16:55:54','pre_save_character_properties'),(1995,19,'MAXSTA_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1996,19,'MaxWeight_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1997,19,'MHP_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1998,19,'MNA_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(1999,19,'MNA_STAT','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2000,19,'MSPD_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2001,19,'MSP_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2002,19,'SP','f','207','2026-04-25 16:55:54','pre_save_character_properties'),(2003,19,'StatByBonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2004,19,'StatByLevel','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2005,19,'STR_Bonus','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2006,19,'STR_STAT','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2007,19,'UsedStat','f','0','2026-04-25 16:55:54','pre_save_character_properties'),(2016,19,'CompanionAutoAtk','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2017,19,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2018,19,'FirstPlay','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2019,19,'HAIR_WIG_Visible','f','1','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2020,19,'HAT_L_Visible','f','1','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2021,19,'HAT_T_Visible','f','1','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2022,19,'HAT_Visible','f','1','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2023,19,'InDunCountType_0','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2024,19,'InDunCountType_100','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2025,19,'InDunCountType_10000','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2026,19,'InDunCountType_1100','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2027,19,'InDunCountType_1200','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2028,19,'InDunCountType_2','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2029,19,'InDunCountType_200','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2030,19,'InDunCountType_300','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2031,19,'InDunCountType_400','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2032,19,'InDunCountType_500','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2033,19,'InDunCountType_600','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2034,19,'InDunCountType_700','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2035,19,'InDunCountType_8000','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2036,19,'InDunCountType_8003','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2037,19,'InDunCountType_900','f','0','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2038,19,'IndunWeeklyResetTime','s','202604625161721','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2039,19,'Indun_ResetTime','s','202604625161721','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2040,19,'LastPlayDate','f','20210728','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2041,19,'MaxWarehouseCount','f','2000','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2042,19,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2043,19,'SkintoneName','s','skintone2','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2044,19,'StartHairName','s','UnbalancedShortcut','2026-04-25 16:55:54','pre_save_character_etc_properties'),(2047,20,'AbilityPoint','s','0','2026-04-25 17:00:18','pre_save_character_properties'),(2048,20,'CON_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2049,20,'CON_STAT','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2050,20,'DashRun','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2051,20,'DEX_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2052,20,'DEX_STAT','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2053,20,'HP','f','91.75','2026-04-25 17:00:18','pre_save_character_properties'),(2054,20,'INT_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2055,20,'INT_STAT','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2056,20,'Lv','f','1','2026-04-25 17:00:18','pre_save_character_properties'),(2057,20,'MAXSTA_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2058,20,'MaxWeight_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2059,20,'MHP_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2060,20,'MNA_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2061,20,'MNA_STAT','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2062,20,'MSPD_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2063,20,'MSP_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2064,20,'SP','f','454','2026-04-25 17:00:18','pre_save_character_properties'),(2065,20,'StatByBonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2066,20,'StatByLevel','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2067,20,'STR_Bonus','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2068,20,'STR_STAT','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2069,20,'UsedStat','f','0','2026-04-25 17:00:18','pre_save_character_properties'),(2078,20,'CompanionAutoAtk','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2079,20,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2080,20,'FirstPlay','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2081,20,'HAIR_WIG_Visible','f','1','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2082,20,'HAT_L_Visible','f','1','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2083,20,'HAT_T_Visible','f','1','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2084,20,'HAT_Visible','f','1','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2085,20,'InDunCountType_0','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2086,20,'InDunCountType_100','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2087,20,'InDunCountType_10000','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2088,20,'InDunCountType_1100','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2089,20,'InDunCountType_1200','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2090,20,'InDunCountType_2','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2091,20,'InDunCountType_200','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2092,20,'InDunCountType_300','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2093,20,'InDunCountType_400','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2094,20,'InDunCountType_500','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2095,20,'InDunCountType_600','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2096,20,'InDunCountType_700','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2097,20,'InDunCountType_8000','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2098,20,'InDunCountType_8003','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2099,20,'InDunCountType_900','f','0','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2100,20,'IndunWeeklyResetTime','s','202604625165615','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2101,20,'Indun_ResetTime','s','202604625165615','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2102,20,'LastPlayDate','f','20210728','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2103,20,'MaxWarehouseCount','f','2000','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2104,20,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2105,20,'SkintoneName','s','skintone2','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2106,20,'StartHairName','s','UnbalancedShortcut','2026-04-25 17:00:18','pre_save_character_etc_properties'),(2109,4,'AbilityPoint','s','0','2026-04-25 17:01:29','pre_save_character_properties'),(2110,4,'CON_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2111,4,'CON_STAT','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2112,4,'DashRun','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2113,4,'DEX_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2114,4,'DEX_STAT','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2115,4,'HP','f','396','2026-04-25 17:01:29','pre_save_character_properties'),(2116,4,'INT_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2117,4,'INT_STAT','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2118,4,'Lv','f','1','2026-04-25 17:01:29','pre_save_character_properties'),(2119,4,'MAXSTA_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2120,4,'MaxWeight_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2121,4,'MHP_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2122,4,'MNA_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2123,4,'MNA_STAT','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2124,4,'MSPD_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2125,4,'MSP_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2126,4,'SP','f','207','2026-04-25 17:01:29','pre_save_character_properties'),(2127,4,'StatByBonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2128,4,'StatByLevel','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2129,4,'STR_Bonus','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2130,4,'STR_STAT','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2131,4,'UsedStat','f','0','2026-04-25 17:01:29','pre_save_character_properties'),(2140,4,'SkintoneName','s','skintone2','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2141,4,'StartHairName','s','UnbalancedShortcut','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2142,4,'LastPlayDate','f','20210728','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2143,4,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2144,4,'MaxWarehouseCount','f','2000','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2145,4,'CompanionAutoAtk','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2146,4,'HAT_Visible','f','1','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2147,4,'HAT_T_Visible','f','1','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2148,4,'HAT_L_Visible','f','1','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2149,4,'HAIR_WIG_Visible','f','1','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2150,4,'InDunCountType_100','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2151,4,'InDunCountType_200','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2152,4,'InDunCountType_0','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2153,4,'InDunCountType_400','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2154,4,'InDunCountType_300','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2155,4,'InDunCountType_500','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2156,4,'InDunCountType_600','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2157,4,'InDunCountType_700','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2158,4,'InDunCountType_10000','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2159,4,'InDunCountType_900','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2160,4,'InDunCountType_1200','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2161,4,'InDunCountType_1100','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2162,4,'InDunCountType_8003','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2163,4,'InDunCountType_2','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2164,4,'InDunCountType_8000','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2165,4,'Indun_ResetTime','s','202604625100016','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2166,4,'IndunWeeklyResetTime','s','202604625100016','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2167,4,'FirstPlay','f','0','2026-04-25 17:01:29','pre_save_character_etc_properties'),(2171,4,'AbilityPoint','s','0','2026-04-25 17:02:08','pre_save_character_properties'),(2172,4,'CON_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2173,4,'CON_STAT','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2174,4,'DashRun','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2175,4,'DEX_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2176,4,'DEX_STAT','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2177,4,'HP','f','99','2026-04-25 17:02:08','pre_save_character_properties'),(2178,4,'INT_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2179,4,'INT_STAT','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2180,4,'Lv','f','1','2026-04-25 17:02:08','pre_save_character_properties'),(2181,4,'MAXSTA_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2182,4,'MaxWeight_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2183,4,'MHP_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2184,4,'MNA_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2185,4,'MNA_STAT','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2186,4,'MSPD_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2187,4,'MSP_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2188,4,'SP','f','207','2026-04-25 17:02:08','pre_save_character_properties'),(2189,4,'StatByBonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2190,4,'StatByLevel','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2191,4,'STR_Bonus','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2192,4,'STR_STAT','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2193,4,'UsedStat','f','0','2026-04-25 17:02:08','pre_save_character_properties'),(2202,4,'CompanionAutoAtk','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2203,4,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2204,4,'FirstPlay','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2205,4,'HAIR_WIG_Visible','f','1','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2206,4,'HAT_L_Visible','f','1','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2207,4,'HAT_T_Visible','f','1','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2208,4,'HAT_Visible','f','1','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2209,4,'InDunCountType_0','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2210,4,'InDunCountType_100','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2211,4,'InDunCountType_10000','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2212,4,'InDunCountType_1100','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2213,4,'InDunCountType_1200','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2214,4,'InDunCountType_2','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2215,4,'InDunCountType_200','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2216,4,'InDunCountType_300','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2217,4,'InDunCountType_400','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2218,4,'InDunCountType_500','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2219,4,'InDunCountType_600','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2220,4,'InDunCountType_700','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2221,4,'InDunCountType_8000','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2222,4,'InDunCountType_8003','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2223,4,'InDunCountType_900','f','0','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2224,4,'IndunWeeklyResetTime','s','202604625100016','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2225,4,'Indun_ResetTime','s','202604625100016','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2226,4,'LastPlayDate','f','20210728','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2227,4,'MaxWarehouseCount','f','2000','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2228,4,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2229,4,'SkintoneName','s','skintone2','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2230,4,'StartHairName','s','UnbalancedShortcut','2026-04-25 17:02:08','pre_save_character_etc_properties'),(2233,22,'AbilityPoint','s','0','2026-04-25 18:22:48','pre_save_character_properties'),(2234,22,'CON_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2235,22,'CON_STAT','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2236,22,'DashRun','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2237,22,'DEX_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2238,22,'DEX_STAT','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2239,22,'HP','f','367','2026-04-25 18:22:48','pre_save_character_properties'),(2240,22,'INT_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2241,22,'INT_STAT','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2242,22,'Lv','f','1','2026-04-25 18:22:48','pre_save_character_properties'),(2243,22,'MAXSTA_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2244,22,'MaxWeight_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2245,22,'MHP_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2246,22,'MNA_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2247,22,'MNA_STAT','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2248,22,'MSPD_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2249,22,'MSP_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2250,22,'SP','f','376','2026-04-25 18:22:48','pre_save_character_properties'),(2251,22,'StatByBonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2252,22,'StatByLevel','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2253,22,'STR_Bonus','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2254,22,'STR_STAT','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2255,22,'UsedStat','f','0','2026-04-25 18:22:48','pre_save_character_properties'),(2264,22,'CompanionAutoAtk','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2265,22,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2266,22,'FirstPlay','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2267,22,'HAIR_WIG_Visible','f','1','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2268,22,'HAT_L_Visible','f','1','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2269,22,'HAT_T_Visible','f','1','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2270,22,'HAT_Visible','f','1','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2271,22,'InDunCountType_0','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2272,22,'InDunCountType_100','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2273,22,'InDunCountType_10000','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2274,22,'InDunCountType_1100','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2275,22,'InDunCountType_1200','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2276,22,'InDunCountType_2','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2277,22,'InDunCountType_200','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2278,22,'InDunCountType_300','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2279,22,'InDunCountType_400','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2280,22,'InDunCountType_500','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2281,22,'InDunCountType_600','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2282,22,'InDunCountType_700','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2283,22,'InDunCountType_8000','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2284,22,'InDunCountType_8003','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2285,22,'InDunCountType_900','f','0','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2286,22,'IndunWeeklyResetTime','s','202604625182149','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2287,22,'Indun_ResetTime','s','202604625182149','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2288,22,'LastPlayDate','f','20210728','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2289,22,'MaxWarehouseCount','f','2000','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2290,22,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2291,22,'SkintoneName','s','skintone2','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2292,22,'StartHairName','s','UnbalancedShortcut','2026-04-25 18:22:48','pre_save_character_etc_properties'),(2295,1,'AbilityPoint','s','0','2026-04-25 18:39:44','pre_save_character_properties'),(2296,1,'CON_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2297,1,'CON_STAT','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2298,1,'DashRun','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2299,1,'DEX_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2300,1,'DEX_STAT','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2301,1,'HP','f','405','2026-04-25 18:39:44','pre_save_character_properties'),(2302,1,'INT_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2303,1,'INT_STAT','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2304,1,'Lv','f','1','2026-04-25 18:39:44','pre_save_character_properties'),(2305,1,'MAXSTA_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2306,1,'MaxWeight_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2307,1,'MHP_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2308,1,'MNA_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2309,1,'MNA_STAT','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2310,1,'MSPD_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2311,1,'MSP_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2312,1,'SP','f','207','2026-04-25 18:39:44','pre_save_character_properties'),(2313,1,'StatByBonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2314,1,'StatByLevel','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2315,1,'STR_Bonus','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2316,1,'STR_STAT','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2317,1,'UsedStat','f','0','2026-04-25 18:39:44','pre_save_character_properties'),(2326,1,'SkintoneName','s','skintone2','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2327,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2328,1,'LastPlayDate','f','20210728','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2329,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2330,1,'MaxWarehouseCount','f','2000','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2331,1,'CompanionAutoAtk','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2332,1,'HAT_Visible','f','1','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2333,1,'HAT_T_Visible','f','1','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2334,1,'HAT_L_Visible','f','1','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2335,1,'HAIR_WIG_Visible','f','1','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2336,1,'InDunCountType_100','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2337,1,'InDunCountType_200','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2338,1,'InDunCountType_0','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2339,1,'InDunCountType_400','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2340,1,'InDunCountType_300','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2341,1,'InDunCountType_500','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2342,1,'InDunCountType_600','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2343,1,'InDunCountType_700','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2344,1,'InDunCountType_10000','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2345,1,'InDunCountType_900','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2346,1,'InDunCountType_1200','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2347,1,'InDunCountType_1100','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2348,1,'InDunCountType_8003','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2349,1,'InDunCountType_2','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2350,1,'InDunCountType_8000','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2351,1,'Indun_ResetTime','s','202604625081405','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2352,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2353,1,'FirstPlay','f','0','2026-04-25 18:39:44','pre_save_character_etc_properties'),(2357,1,'AbilityPoint','s','0','2026-04-25 18:52:52','pre_save_character_properties'),(2358,1,'CON_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2359,1,'CON_STAT','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2360,1,'DashRun','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2361,1,'DEX_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2362,1,'DEX_STAT','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2363,1,'HP','f','405','2026-04-25 18:52:52','pre_save_character_properties'),(2364,1,'INT_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2365,1,'INT_STAT','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2366,1,'Lv','f','1','2026-04-25 18:52:52','pre_save_character_properties'),(2367,1,'MAXSTA_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2368,1,'MaxWeight_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2369,1,'MHP_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2370,1,'MNA_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2371,1,'MNA_STAT','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2372,1,'MSPD_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2373,1,'MSP_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2374,1,'SP','f','207','2026-04-25 18:52:52','pre_save_character_properties'),(2375,1,'StatByBonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2376,1,'StatByLevel','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2377,1,'STR_Bonus','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2378,1,'STR_STAT','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2379,1,'UsedStat','f','0','2026-04-25 18:52:52','pre_save_character_properties'),(2388,1,'CompanionAutoAtk','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2389,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2390,1,'FirstPlay','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2391,1,'HAIR_WIG_Visible','f','1','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2392,1,'HAT_L_Visible','f','1','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2393,1,'HAT_T_Visible','f','1','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2394,1,'HAT_Visible','f','1','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2395,1,'InDunCountType_0','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2396,1,'InDunCountType_100','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2397,1,'InDunCountType_10000','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2398,1,'InDunCountType_1100','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2399,1,'InDunCountType_1200','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2400,1,'InDunCountType_2','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2401,1,'InDunCountType_200','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2402,1,'InDunCountType_300','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2403,1,'InDunCountType_400','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2404,1,'InDunCountType_500','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2405,1,'InDunCountType_600','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2406,1,'InDunCountType_700','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2407,1,'InDunCountType_8000','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2408,1,'InDunCountType_8003','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2409,1,'InDunCountType_900','f','0','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2410,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2411,1,'Indun_ResetTime','s','202604625081405','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2412,1,'LastPlayDate','f','20210728','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2413,1,'MaxWarehouseCount','f','2000','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2414,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2415,1,'SkintoneName','s','skintone2','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2416,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 18:52:52','pre_save_character_etc_properties'),(2419,1,'AbilityPoint','s','0','2026-04-25 19:19:24','pre_save_character_properties'),(2420,1,'CON_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2421,1,'CON_STAT','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2422,1,'DashRun','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2423,1,'DEX_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2424,1,'DEX_STAT','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2425,1,'HP','f','405','2026-04-25 19:19:24','pre_save_character_properties'),(2426,1,'INT_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2427,1,'INT_STAT','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2428,1,'Lv','f','1','2026-04-25 19:19:24','pre_save_character_properties'),(2429,1,'MAXSTA_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2430,1,'MaxWeight_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2431,1,'MHP_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2432,1,'MNA_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2433,1,'MNA_STAT','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2434,1,'MSPD_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2435,1,'MSP_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2436,1,'SP','f','207','2026-04-25 19:19:24','pre_save_character_properties'),(2437,1,'StatByBonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2438,1,'StatByLevel','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2439,1,'STR_Bonus','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2440,1,'STR_STAT','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2441,1,'UsedStat','f','0','2026-04-25 19:19:24','pre_save_character_properties'),(2450,1,'CompanionAutoAtk','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2451,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2452,1,'FirstPlay','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2453,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2454,1,'HAT_L_Visible','f','1','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2455,1,'HAT_T_Visible','f','1','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2456,1,'HAT_Visible','f','1','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2457,1,'InDunCountType_0','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2458,1,'InDunCountType_100','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2459,1,'InDunCountType_10000','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2460,1,'InDunCountType_1100','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2461,1,'InDunCountType_1200','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2462,1,'InDunCountType_2','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2463,1,'InDunCountType_200','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2464,1,'InDunCountType_300','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2465,1,'InDunCountType_400','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2466,1,'InDunCountType_500','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2467,1,'InDunCountType_600','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2468,1,'InDunCountType_700','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2469,1,'InDunCountType_8000','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2470,1,'InDunCountType_8003','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2471,1,'InDunCountType_900','f','0','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2472,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2473,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2474,1,'LastPlayDate','f','20210728','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2475,1,'MaxWarehouseCount','f','2000','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2476,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2477,1,'SkintoneName','s','skintone2','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2478,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:19:24','pre_save_character_etc_properties'),(2481,1,'AbilityPoint','s','0','2026-04-25 19:27:44','pre_save_character_properties'),(2482,1,'CON_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2483,1,'CON_STAT','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2484,1,'DashRun','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2485,1,'DEX_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2486,1,'DEX_STAT','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2487,1,'HP','f','405','2026-04-25 19:27:44','pre_save_character_properties'),(2488,1,'INT_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2489,1,'INT_STAT','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2490,1,'Lv','f','1','2026-04-25 19:27:44','pre_save_character_properties'),(2491,1,'MAXSTA_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2492,1,'MaxWeight_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2493,1,'MHP_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2494,1,'MNA_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2495,1,'MNA_STAT','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2496,1,'MSPD_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2497,1,'MSP_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2498,1,'SP','f','207','2026-04-25 19:27:44','pre_save_character_properties'),(2499,1,'StatByBonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2500,1,'StatByLevel','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2501,1,'STR_Bonus','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2502,1,'STR_STAT','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2503,1,'UsedStat','f','0','2026-04-25 19:27:44','pre_save_character_properties'),(2512,1,'CompanionAutoAtk','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2513,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2514,1,'FirstPlay','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2515,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2516,1,'HAT_L_Visible','f','1','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2517,1,'HAT_T_Visible','f','1','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2518,1,'HAT_Visible','f','1','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2519,1,'InDunCountType_0','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2520,1,'InDunCountType_100','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2521,1,'InDunCountType_10000','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2522,1,'InDunCountType_1100','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2523,1,'InDunCountType_1200','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2524,1,'InDunCountType_2','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2525,1,'InDunCountType_200','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2526,1,'InDunCountType_300','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2527,1,'InDunCountType_400','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2528,1,'InDunCountType_500','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2529,1,'InDunCountType_600','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2530,1,'InDunCountType_700','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2531,1,'InDunCountType_8000','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2532,1,'InDunCountType_8003','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2533,1,'InDunCountType_900','f','0','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2534,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2535,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2536,1,'LastPlayDate','f','20210728','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2537,1,'MaxWarehouseCount','f','2000','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2538,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2539,1,'SkintoneName','s','skintone2','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2540,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:27:44','pre_save_character_etc_properties'),(2543,1,'AbilityPoint','s','0','2026-04-25 19:29:24','pre_save_character_properties'),(2544,1,'CON_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2545,1,'CON_STAT','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2546,1,'DashRun','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2547,1,'DEX_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2548,1,'DEX_STAT','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2549,1,'HP','f','405','2026-04-25 19:29:24','pre_save_character_properties'),(2550,1,'INT_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2551,1,'INT_STAT','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2552,1,'Lv','f','1','2026-04-25 19:29:24','pre_save_character_properties'),(2553,1,'MAXSTA_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2554,1,'MaxWeight_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2555,1,'MHP_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2556,1,'MNA_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2557,1,'MNA_STAT','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2558,1,'MSPD_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2559,1,'MSP_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2560,1,'SP','f','207','2026-04-25 19:29:24','pre_save_character_properties'),(2561,1,'StatByBonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2562,1,'StatByLevel','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2563,1,'STR_Bonus','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2564,1,'STR_STAT','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2565,1,'UsedStat','f','0','2026-04-25 19:29:24','pre_save_character_properties'),(2574,1,'CompanionAutoAtk','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2575,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2576,1,'FirstPlay','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2577,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2578,1,'HAT_L_Visible','f','1','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2579,1,'HAT_T_Visible','f','1','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2580,1,'HAT_Visible','f','1','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2581,1,'InDunCountType_0','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2582,1,'InDunCountType_100','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2583,1,'InDunCountType_10000','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2584,1,'InDunCountType_1100','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2585,1,'InDunCountType_1200','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2586,1,'InDunCountType_2','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2587,1,'InDunCountType_200','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2588,1,'InDunCountType_300','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2589,1,'InDunCountType_400','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2590,1,'InDunCountType_500','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2591,1,'InDunCountType_600','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2592,1,'InDunCountType_700','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2593,1,'InDunCountType_8000','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2594,1,'InDunCountType_8003','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2595,1,'InDunCountType_900','f','0','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2596,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2597,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2598,1,'LastPlayDate','f','20210728','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2599,1,'MaxWarehouseCount','f','2000','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2600,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2601,1,'SkintoneName','s','skintone2','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2602,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:29:24','pre_save_character_etc_properties'),(2605,1,'AbilityPoint','s','0','2026-04-25 19:32:20','pre_save_character_properties'),(2606,1,'CON_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2607,1,'CON_STAT','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2608,1,'DashRun','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2609,1,'DEX_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2610,1,'DEX_STAT','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2611,1,'HP','f','405','2026-04-25 19:32:20','pre_save_character_properties'),(2612,1,'INT_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2613,1,'INT_STAT','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2614,1,'Lv','f','1','2026-04-25 19:32:20','pre_save_character_properties'),(2615,1,'MAXSTA_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2616,1,'MaxWeight_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2617,1,'MHP_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2618,1,'MNA_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2619,1,'MNA_STAT','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2620,1,'MSPD_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2621,1,'MSP_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2622,1,'SP','f','207','2026-04-25 19:32:20','pre_save_character_properties'),(2623,1,'StatByBonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2624,1,'StatByLevel','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2625,1,'STR_Bonus','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2626,1,'STR_STAT','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2627,1,'UsedStat','f','0','2026-04-25 19:32:20','pre_save_character_properties'),(2636,1,'CompanionAutoAtk','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2637,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2638,1,'FirstPlay','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2639,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2640,1,'HAT_L_Visible','f','1','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2641,1,'HAT_T_Visible','f','1','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2642,1,'HAT_Visible','f','1','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2643,1,'InDunCountType_0','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2644,1,'InDunCountType_100','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2645,1,'InDunCountType_10000','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2646,1,'InDunCountType_1100','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2647,1,'InDunCountType_1200','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2648,1,'InDunCountType_2','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2649,1,'InDunCountType_200','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2650,1,'InDunCountType_300','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2651,1,'InDunCountType_400','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2652,1,'InDunCountType_500','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2653,1,'InDunCountType_600','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2654,1,'InDunCountType_700','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2655,1,'InDunCountType_8000','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2656,1,'InDunCountType_8003','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2657,1,'InDunCountType_900','f','0','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2658,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2659,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2660,1,'LastPlayDate','f','20210728','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2661,1,'MaxWarehouseCount','f','2000','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2662,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2663,1,'SkintoneName','s','skintone2','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2664,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:32:20','pre_save_character_etc_properties'),(2667,1,'AbilityPoint','s','0','2026-04-25 19:37:23','pre_save_character_properties'),(2668,1,'CON_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2669,1,'CON_STAT','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2670,1,'DashRun','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2671,1,'DEX_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2672,1,'DEX_STAT','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2673,1,'HP','f','351','2026-04-25 19:37:23','pre_save_character_properties'),(2674,1,'INT_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2675,1,'INT_STAT','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2676,1,'Lv','f','1','2026-04-25 19:37:23','pre_save_character_properties'),(2677,1,'MAXSTA_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2678,1,'MaxWeight_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2679,1,'MHP_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2680,1,'MNA_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2681,1,'MNA_STAT','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2682,1,'MSPD_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2683,1,'MSP_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2684,1,'SP','f','207','2026-04-25 19:37:23','pre_save_character_properties'),(2685,1,'StatByBonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2686,1,'StatByLevel','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2687,1,'STR_Bonus','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2688,1,'STR_STAT','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2689,1,'UsedStat','f','0','2026-04-25 19:37:23','pre_save_character_properties'),(2698,1,'CompanionAutoAtk','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2699,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2700,1,'FirstPlay','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2701,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2702,1,'HAT_L_Visible','f','1','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2703,1,'HAT_T_Visible','f','1','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2704,1,'HAT_Visible','f','1','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2705,1,'InDunCountType_0','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2706,1,'InDunCountType_100','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2707,1,'InDunCountType_10000','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2708,1,'InDunCountType_1100','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2709,1,'InDunCountType_1200','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2710,1,'InDunCountType_2','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2711,1,'InDunCountType_200','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2712,1,'InDunCountType_300','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2713,1,'InDunCountType_400','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2714,1,'InDunCountType_500','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2715,1,'InDunCountType_600','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2716,1,'InDunCountType_700','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2717,1,'InDunCountType_8000','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2718,1,'InDunCountType_8003','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2719,1,'InDunCountType_900','f','0','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2720,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2721,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2722,1,'LastPlayDate','f','20210728','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2723,1,'MaxWarehouseCount','f','2000','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2724,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2725,1,'SkintoneName','s','skintone2','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2726,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:37:23','pre_save_character_etc_properties'),(2729,1,'AbilityPoint','s','0','2026-04-25 19:39:24','pre_save_character_properties'),(2730,1,'CON_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2731,1,'CON_STAT','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2732,1,'DashRun','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2733,1,'DEX_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2734,1,'DEX_STAT','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2735,1,'HP','f','405','2026-04-25 19:39:24','pre_save_character_properties'),(2736,1,'INT_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2737,1,'INT_STAT','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2738,1,'Lv','f','1','2026-04-25 19:39:24','pre_save_character_properties'),(2739,1,'MAXSTA_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2740,1,'MaxWeight_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2741,1,'MHP_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2742,1,'MNA_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2743,1,'MNA_STAT','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2744,1,'MSPD_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2745,1,'MSP_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2746,1,'SP','f','207','2026-04-25 19:39:24','pre_save_character_properties'),(2747,1,'StatByBonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2748,1,'StatByLevel','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2749,1,'STR_Bonus','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2750,1,'STR_STAT','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2751,1,'UsedStat','f','0','2026-04-25 19:39:24','pre_save_character_properties'),(2760,1,'CompanionAutoAtk','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2761,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2762,1,'FirstPlay','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2763,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2764,1,'HAT_L_Visible','f','1','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2765,1,'HAT_T_Visible','f','1','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2766,1,'HAT_Visible','f','1','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2767,1,'InDunCountType_0','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2768,1,'InDunCountType_100','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2769,1,'InDunCountType_10000','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2770,1,'InDunCountType_1100','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2771,1,'InDunCountType_1200','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2772,1,'InDunCountType_2','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2773,1,'InDunCountType_200','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2774,1,'InDunCountType_300','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2775,1,'InDunCountType_400','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2776,1,'InDunCountType_500','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2777,1,'InDunCountType_600','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2778,1,'InDunCountType_700','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2779,1,'InDunCountType_8000','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2780,1,'InDunCountType_8003','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2781,1,'InDunCountType_900','f','0','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2782,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2783,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2784,1,'LastPlayDate','f','20210728','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2785,1,'MaxWarehouseCount','f','2000','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2786,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2787,1,'SkintoneName','s','skintone2','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2788,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:39:24','pre_save_character_etc_properties'),(2791,1,'AbilityPoint','s','0','2026-04-25 19:53:08','pre_save_character_properties'),(2792,1,'CON_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2793,1,'CON_STAT','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2794,1,'DashRun','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2795,1,'DEX_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2796,1,'DEX_STAT','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2797,1,'HP','f','405','2026-04-25 19:53:08','pre_save_character_properties'),(2798,1,'INT_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2799,1,'INT_STAT','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2800,1,'Lv','f','1','2026-04-25 19:53:08','pre_save_character_properties'),(2801,1,'MAXSTA_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2802,1,'MaxWeight_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2803,1,'MHP_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2804,1,'MNA_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2805,1,'MNA_STAT','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2806,1,'MSPD_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2807,1,'MSP_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2808,1,'SP','f','207','2026-04-25 19:53:08','pre_save_character_properties'),(2809,1,'StatByBonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2810,1,'StatByLevel','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2811,1,'STR_Bonus','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2812,1,'STR_STAT','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2813,1,'UsedStat','f','0','2026-04-25 19:53:08','pre_save_character_properties'),(2822,1,'CompanionAutoAtk','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2823,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2824,1,'FirstPlay','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2825,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2826,1,'HAT_L_Visible','f','1','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2827,1,'HAT_T_Visible','f','1','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2828,1,'HAT_Visible','f','1','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2829,1,'InDunCountType_0','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2830,1,'InDunCountType_100','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2831,1,'InDunCountType_10000','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2832,1,'InDunCountType_1100','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2833,1,'InDunCountType_1200','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2834,1,'InDunCountType_2','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2835,1,'InDunCountType_200','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2836,1,'InDunCountType_300','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2837,1,'InDunCountType_400','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2838,1,'InDunCountType_500','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2839,1,'InDunCountType_600','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2840,1,'InDunCountType_700','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2841,1,'InDunCountType_8000','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2842,1,'InDunCountType_8003','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2843,1,'InDunCountType_900','f','0','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2844,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2845,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2846,1,'LastPlayDate','f','20210728','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2847,1,'MaxWarehouseCount','f','2000','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2848,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2849,1,'SkintoneName','s','skintone2','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2850,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:53:08','pre_save_character_etc_properties'),(2853,1,'AbilityPoint','s','0','2026-04-25 19:55:37','pre_save_character_properties'),(2854,1,'CON_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2855,1,'CON_STAT','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2856,1,'DashRun','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2857,1,'DEX_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2858,1,'DEX_STAT','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2859,1,'HP','f','405','2026-04-25 19:55:37','pre_save_character_properties'),(2860,1,'INT_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2861,1,'INT_STAT','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2862,1,'Lv','f','1','2026-04-25 19:55:37','pre_save_character_properties'),(2863,1,'MAXSTA_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2864,1,'MaxWeight_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2865,1,'MHP_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2866,1,'MNA_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2867,1,'MNA_STAT','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2868,1,'MSPD_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2869,1,'MSP_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2870,1,'SP','f','207','2026-04-25 19:55:37','pre_save_character_properties'),(2871,1,'StatByBonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2872,1,'StatByLevel','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2873,1,'STR_Bonus','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2874,1,'STR_STAT','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2875,1,'UsedStat','f','0','2026-04-25 19:55:37','pre_save_character_properties'),(2884,1,'CompanionAutoAtk','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2885,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2886,1,'FirstPlay','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2887,1,'HAIR_WIG_Visible','f','1','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2888,1,'HAT_L_Visible','f','1','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2889,1,'HAT_T_Visible','f','1','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2890,1,'HAT_Visible','f','1','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2891,1,'InDunCountType_0','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2892,1,'InDunCountType_100','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2893,1,'InDunCountType_10000','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2894,1,'InDunCountType_1100','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2895,1,'InDunCountType_1200','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2896,1,'InDunCountType_2','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2897,1,'InDunCountType_200','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2898,1,'InDunCountType_300','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2899,1,'InDunCountType_400','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2900,1,'InDunCountType_500','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2901,1,'InDunCountType_600','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2902,1,'InDunCountType_700','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2903,1,'InDunCountType_8000','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2904,1,'InDunCountType_8003','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2905,1,'InDunCountType_900','f','0','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2906,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2907,1,'Indun_ResetTime','s','202604625081405','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2908,1,'LastPlayDate','f','20210728','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2909,1,'MaxWarehouseCount','f','2000','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2910,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2911,1,'SkintoneName','s','skintone2','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2912,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 19:55:37','pre_save_character_etc_properties'),(2915,1,'AbilityPoint','s','0','2026-04-25 20:30:14','pre_save_character_properties'),(2916,1,'CON_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2917,1,'CON_STAT','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2918,1,'DashRun','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2919,1,'DEX_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2920,1,'DEX_STAT','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2921,1,'HP','f','405','2026-04-25 20:30:14','pre_save_character_properties'),(2922,1,'INT_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2923,1,'INT_STAT','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2924,1,'Lv','f','1','2026-04-25 20:30:14','pre_save_character_properties'),(2925,1,'MAXSTA_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2926,1,'MaxWeight_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2927,1,'MHP_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2928,1,'MNA_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2929,1,'MNA_STAT','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2930,1,'MSPD_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2931,1,'MSP_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2932,1,'SP','f','207','2026-04-25 20:30:14','pre_save_character_properties'),(2933,1,'StatByBonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2934,1,'StatByLevel','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2935,1,'STR_Bonus','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2936,1,'STR_STAT','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2937,1,'UsedStat','f','0','2026-04-25 20:30:14','pre_save_character_properties'),(2946,1,'CompanionAutoAtk','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2947,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2948,1,'FirstPlay','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2949,1,'HAIR_WIG_Visible','f','1','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2950,1,'HAT_L_Visible','f','1','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2951,1,'HAT_T_Visible','f','1','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2952,1,'HAT_Visible','f','1','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2953,1,'InDunCountType_0','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2954,1,'InDunCountType_100','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2955,1,'InDunCountType_10000','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2956,1,'InDunCountType_1100','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2957,1,'InDunCountType_1200','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2958,1,'InDunCountType_2','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2959,1,'InDunCountType_200','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2960,1,'InDunCountType_300','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2961,1,'InDunCountType_400','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2962,1,'InDunCountType_500','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2963,1,'InDunCountType_600','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2964,1,'InDunCountType_700','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2965,1,'InDunCountType_8000','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2966,1,'InDunCountType_8003','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2967,1,'InDunCountType_900','f','0','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2968,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2969,1,'Indun_ResetTime','s','202604625081405','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2970,1,'LastPlayDate','f','20210728','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2971,1,'MaxWarehouseCount','f','2000','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2972,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2973,1,'SkintoneName','s','skintone2','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2974,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 20:30:14','pre_save_character_etc_properties'),(2977,1,'AbilityPoint','s','0','2026-04-25 20:30:50','pre_save_character_properties'),(2978,1,'CON_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2979,1,'CON_STAT','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2980,1,'DashRun','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2981,1,'DEX_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2982,1,'DEX_STAT','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2983,1,'HP','f','405','2026-04-25 20:30:50','pre_save_character_properties'),(2984,1,'INT_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2985,1,'INT_STAT','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2986,1,'Lv','f','1','2026-04-25 20:30:50','pre_save_character_properties'),(2987,1,'MAXSTA_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2988,1,'MaxWeight_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2989,1,'MHP_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2990,1,'MNA_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2991,1,'MNA_STAT','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2992,1,'MSPD_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2993,1,'MSP_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2994,1,'SP','f','207','2026-04-25 20:30:50','pre_save_character_properties'),(2995,1,'StatByBonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2996,1,'StatByLevel','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2997,1,'STR_Bonus','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2998,1,'STR_STAT','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(2999,1,'UsedStat','f','0','2026-04-25 20:30:50','pre_save_character_properties'),(3008,1,'CompanionAutoAtk','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3009,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3010,1,'FirstPlay','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3011,1,'HAIR_WIG_Visible','f','1','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3012,1,'HAT_L_Visible','f','1','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3013,1,'HAT_T_Visible','f','1','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3014,1,'HAT_Visible','f','1','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3015,1,'InDunCountType_0','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3016,1,'InDunCountType_100','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3017,1,'InDunCountType_10000','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3018,1,'InDunCountType_1100','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3019,1,'InDunCountType_1200','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3020,1,'InDunCountType_2','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3021,1,'InDunCountType_200','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3022,1,'InDunCountType_300','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3023,1,'InDunCountType_400','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3024,1,'InDunCountType_500','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3025,1,'InDunCountType_600','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3026,1,'InDunCountType_700','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3027,1,'InDunCountType_8000','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3028,1,'InDunCountType_8003','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3029,1,'InDunCountType_900','f','0','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3030,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3031,1,'Indun_ResetTime','s','202604625081405','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3032,1,'LastPlayDate','f','20210728','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3033,1,'MaxWarehouseCount','f','2000','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3034,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3035,1,'SkintoneName','s','skintone2','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3036,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 20:30:50','pre_save_character_etc_properties'),(3039,1,'AbilityPoint','s','0','2026-04-25 20:31:31','pre_save_character_properties'),(3040,1,'CON_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3041,1,'CON_STAT','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3042,1,'DashRun','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3043,1,'DEX_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3044,1,'DEX_STAT','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3045,1,'HP','f','405','2026-04-25 20:31:31','pre_save_character_properties'),(3046,1,'INT_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3047,1,'INT_STAT','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3048,1,'Lv','f','1','2026-04-25 20:31:31','pre_save_character_properties'),(3049,1,'MAXSTA_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3050,1,'MaxWeight_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3051,1,'MHP_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3052,1,'MNA_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3053,1,'MNA_STAT','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3054,1,'MSPD_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3055,1,'MSP_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3056,1,'SP','f','207','2026-04-25 20:31:31','pre_save_character_properties'),(3057,1,'StatByBonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3058,1,'StatByLevel','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3059,1,'STR_Bonus','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3060,1,'STR_STAT','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3061,1,'UsedStat','f','0','2026-04-25 20:31:31','pre_save_character_properties'),(3070,1,'CompanionAutoAtk','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3071,1,'CTRLTYPE_RESET_EXCEPT','f','1','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3072,1,'FirstPlay','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3073,1,'HAIR_WIG_Visible','f','1','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3074,1,'HAT_L_Visible','f','1','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3075,1,'HAT_T_Visible','f','1','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3076,1,'HAT_Visible','f','1','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3077,1,'InDunCountType_0','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3078,1,'InDunCountType_100','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3079,1,'InDunCountType_10000','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3080,1,'InDunCountType_1100','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3081,1,'InDunCountType_1200','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3082,1,'InDunCountType_2','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3083,1,'InDunCountType_200','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3084,1,'InDunCountType_300','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3085,1,'InDunCountType_400','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3086,1,'InDunCountType_500','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3087,1,'InDunCountType_600','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3088,1,'InDunCountType_700','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3089,1,'InDunCountType_8000','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3090,1,'InDunCountType_8003','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3091,1,'InDunCountType_900','f','0','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3092,1,'IndunWeeklyResetTime','s','202604524210144','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3093,1,'Indun_ResetTime','s','202604625081405','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3094,1,'LastPlayDate','f','20210728','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3095,1,'MaxWarehouseCount','f','2000','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3096,1,'SIAUL_WEST_MEET_TITAS_TRACK','f','1','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3097,1,'SkintoneName','s','skintone2','2026-04-25 20:31:31','pre_save_character_etc_properties'),(3098,1,'StartHairName','s','UnbalancedShortcut','2026-04-25 20:31:31','pre_save_character_etc_properties');
/*!40000 ALTER TABLE `character_properties_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_snapshots`
--

DROP TABLE IF EXISTS `character_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_snapshots` (
  `snapshotId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `accountId` bigint(20) NOT NULL,
  `snapshotReason` varchar(255) NOT NULL,
  `operationDetails` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `gameVersion` varchar(50) DEFAULT NULL,
  `characterLevel` int(11) DEFAULT 0,
  `mapId` int(11) DEFAULT 0,
  PRIMARY KEY (`snapshotId`),
  KEY `idx_character_snapshots_character` (`characterId`),
  KEY `idx_character_snapshots_account` (`accountId`),
  KEY `idx_character_snapshots_created` (`createdAt`),
  KEY `idx_character_snapshots_reason` (`snapshotReason`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_snapshots`
--

LOCK TABLES `character_snapshots` WRITE;
/*!40000 ALTER TABLE `character_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `characterId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `teamName` varchar(32) DEFAULT NULL,
  `job` smallint(6) NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `hair` int(11) NOT NULL,
  `skinColor` int(10) unsigned NOT NULL DEFAULT 4286611584,
  `level` int(11) NOT NULL DEFAULT 1,
  `slot` int(11) NOT NULL,
  `barrackLayer` int(11) NOT NULL DEFAULT 1,
  `bx` float NOT NULL,
  `by` float NOT NULL,
  `bz` float NOT NULL,
  `bd` float NOT NULL,
  `bdir` float NOT NULL DEFAULT 0,
  `zone` int(11) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `dir` float NOT NULL DEFAULT 0,
  `exp` bigint(20) NOT NULL DEFAULT 0,
  `maxExp` bigint(20) NOT NULL DEFAULT 1000,
  `totalExp` bigint(20) NOT NULL DEFAULT 0,
  `hp` int(11) NOT NULL DEFAULT 100,
  `hpRate` float NOT NULL DEFAULT 1,
  `maxHp` int(11) NOT NULL DEFAULT 100,
  `sp` int(11) NOT NULL DEFAULT 50,
  `spRate` float NOT NULL DEFAULT 1,
  `maxSp` int(11) NOT NULL DEFAULT 50,
  `stamina` int(11) NOT NULL DEFAULT 25000,
  `staminaByJob` int(11) NOT NULL DEFAULT 0,
  `maxStamina` int(11) NOT NULL DEFAULT 25000,
  `str` int(11) NOT NULL DEFAULT 0,
  `strByJob` int(11) NOT NULL DEFAULT 0,
  `con` int(11) NOT NULL DEFAULT 0,
  `conByJob` int(11) NOT NULL DEFAULT 0,
  `int` int(11) NOT NULL DEFAULT 0,
  `intByJob` int(11) NOT NULL DEFAULT 0,
  `spr` int(11) NOT NULL DEFAULT 0,
  `sprByJob` int(11) NOT NULL DEFAULT 0,
  `dex` int(11) NOT NULL DEFAULT 0,
  `dexByJob` int(11) NOT NULL DEFAULT 0,
  `statByLevel` int(11) NOT NULL DEFAULT 0,
  `statByBonus` int(11) NOT NULL DEFAULT 0,
  `usedStat` int(11) NOT NULL DEFAULT 0,
  `abilityPoints` int(11) NOT NULL DEFAULT 0,
  `silver` bigint(20) NOT NULL DEFAULT 0,
  `equipVisibility` int(11) NOT NULL DEFAULT 65535,
  `equippedTitleId` int(11) NOT NULL DEFAULT -1,
  `partyId` bigint(20) NOT NULL DEFAULT 0,
  `guildId` bigint(20) NOT NULL DEFAULT 0,
  `houseId` int(11) NOT NULL DEFAULT 0,
  `sessionKey` varchar(41) DEFAULT '',
  `duelWins` int(11) DEFAULT 0,
  `duelLosses` int(11) DEFAULT 0,
  PRIMARY KEY (`characterId`),
  KEY `accountId` (`accountId`),
  KEY `idx_partyId` (`partyId`),
  CONSTRAINT `characters_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (1,1,'Yuki','Gotei',5001,1,21,4286611584,1,1,1,-2,19.6864,-10,90,0,1021,-9.60876,149.167,107.136,135,24,100,24,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'C34CDB038AD19D341468C1F913A7BB9BF778843A',0,0),(3,1,'Shogo','Gotei',2001,1,11,4286611584,1,2,1,5,22.0001,42,90,0,1001,287.885,79.9596,210.697,0,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'1D444CEE04827C3BD2D069F22EBCF4BCF7C3FB27',0,0),(4,1,'Wood','Gotei',3001,1,36,4286611584,1,3,1,-2036,176.785,-3505,18.6636,0,1021,-497,-1.05655,-747,90,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'A7F9946DB9ED4387D90EB4914E823A65F4D3D41F',0,0),(5,1,'Hiru','Gotei',4001,1,21,4286611584,1,4,1,7,14.6033,-43,90,0,1021,-630.397,260.925,-1048.62,315,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'C951A29B70B169DF44A289E98593C92EC8FDEDBA',0,0),(6,1,'Tux','Gotei',1001,1,1,4286611584,1,5,1,-5,27.7655,27,90,0,1021,-528.939,260.925,-632.353,0,0,100,0,0,0,100,0,0,50,12850,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'6581E012253BB101624C8788C81A1FA4B1BB9E4D',0,0),(8,1,'mula1','Gotei',5001,1,21,4286611584,1,6,1,-1861,222.146,-2682,46.9273,0,1021,331.858,79.9596,119.547,225,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'BF01EEC205EF53D40ED1AE74E340936362CAE2B1',0,0),(9,1,'mula2','Gotei',2001,1,11,4286611584,1,7,1,-2082,176.093,-2678,18.6636,0,1021,-585.062,260.925,-914.917,180,0,100,0,0,0,100,0,0,50,16550,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'1699CC5DD81532CF0B65714C7589BAC6B951EEC9',0,0),(10,1,'mula3','Gotei',2001,1,11,4286611584,1,8,1,-1607,175.948,-2526,18.6636,0,1021,-497,-0.213305,-747,90,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'24935DCD236E93B3D460D24BA6995B80CEFF861A',0,0),(11,1,'mula4','Gotei',3001,2,6,4286611584,1,9,1,23,16.5748,-18,90,0,1021,-643.731,260.925,-976.581,198.592,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'B324C104878111E5443E900522FE200557CF0FD7',0,0),(12,1,'mula5','Gotei',2001,1,11,4286611584,1,10,1,-46,22.0001,35,90,0,1021,-628,260,-1025,0,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'B30AB8259D086DAF954B9C9EEB9E78CAD2669847',0,0),(13,1,'mula6','Gotei',4001,1,21,4286611584,1,11,1,-48,22.0001,35,90,0,1021,-1096.43,260.925,-560.551,135,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'71ECCA02EC63DD0FF7368374F466C6622B71D7EE',0,0),(14,1,'mula7','Gotei',1001,1,1,4286611584,1,12,1,-46,22.0001,7,90,0,1021,-1111.05,260.925,-541.296,180,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'E2B6C6680B61CC002CDC2DEDA41B92E727A839F3',0,0),(15,1,'mula8','Gotei',3001,1,6,4286611584,1,13,1,-47,22.0001,-1,90,0,1021,-1265.69,260.925,-633.541,135,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'21F8AAE52A14BBBB6DE789E8087429D54DB8F80E',0,0),(16,1,'mula9','Gotei',4001,2,16,4286611584,1,14,1,-18,22.0001,43,90,0,1021,-663.858,260.925,-432.118,90,0,100,0,0,0,100,0,0,50,19650,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'88A82E6C3AB747EC5B4A5748D707023D92575C92',0,0),(17,1,'mula10','Gotei',4001,1,21,4286611584,1,15,1,-50,17.991,-15,90,0,1021,-1217.56,260.925,-481.327,45,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'156947A961D39777F609FF89BEB18F8E1085E7F6',0,0),(18,1,'mula11','Gotei',1001,1,1,4286611584,1,16,1,-41,25.8437,27,90,0,1021,-455.855,260.925,-422.25,225,0,100,0,0,0,100,0,0,50,2000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'331BA5271C8B915889A5C69AB3BDF4F54CE78781',0,0),(19,1,'mula12','Gotei',5001,1,21,4286611584,1,17,1,-2714,471.671,-3142,46.9273,0,1021,-1102.74,260.925,-548.018,90,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'49FFD5C9A4520023837E1B85F1CFFCF7068BC938',0,0),(20,1,'mula15','Gotei',2001,2,21,4286611584,1,18,1,-1537,178.089,-2957,103.323,0,1021,-394.528,149.21,15.506,315,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'A52EE2769E35D555498B1914CF836DD394A86563',0,0),(21,1,'mula16','Gotei',3001,1,6,4286611584,1,19,1,-1575,176.438,-2129,18.6636,0,1021,-628,260.925,-1025,90,0,100,0,0,0,100,0,0,50,25000,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'85649CCA59A2538D50659882FD5499EAD4298692',0,0),(22,1,'mula17','Gotei',2001,1,11,4286611584,1,20,1,-2422,176.084,-3082,18.6636,0,1021,-1073.55,260.925,-530.963,315,0,100,0,0,0,100,0,0,50,13100,0,25000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,65535,-1,0,0,0,'99496E38CD74D62955D20D9000FBD4581408302E',0,0);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_members`
--

DROP TABLE IF EXISTS `chat_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_members` (
  `memberId` bigint(20) NOT NULL AUTO_INCREMENT,
  `roomId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `teamName` varchar(64) NOT NULL,
  PRIMARY KEY (`memberId`),
  KEY `roomId` (`roomId`),
  KEY `userId` (`userId`),
  CONSTRAINT `chat_members_ibfk_1` FOREIGN KEY (`roomId`) REFERENCES `chat_rooms` (`roomId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_members`
--

LOCK TABLES `chat_members` WRITE;
/*!40000 ALTER TABLE `chat_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_messages` (
  `messageId` bigint(20) NOT NULL AUTO_INCREMENT,
  `roomId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `teamName` varchar(64) NOT NULL,
  `message` varchar(2048) NOT NULL,
  `sentTime` datetime NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `roomId` (`roomId`),
  KEY `userId` (`userId`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`roomId`) REFERENCES `chat_rooms` (`roomId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_rooms`
--

DROP TABLE IF EXISTS `chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_rooms` (
  `roomId` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `creatorId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`roomId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_rooms`
--

LOCK TABLES `chat_rooms` WRITE;
/*!40000 ALTER TABLE `chat_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chatmacros`
--

DROP TABLE IF EXISTS `chatmacros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chatmacros` (
  `chatMacroId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `index` tinyint(4) NOT NULL,
  `message` varchar(128) NOT NULL,
  `pose` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`chatMacroId`),
  UNIQUE KEY `UQ_ChatMacro_index` (`accountId`,`index`),
  CONSTRAINT `FK_ChatMacro_accountId` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE,
  CONSTRAINT `chatmacros_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=721 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatmacros`
--

LOCK TABLES `chatmacros` WRITE;
/*!40000 ALTER TABLE `chatmacros` DISABLE KEYS */;
INSERT INTO `chatmacros` VALUES (1,1,1,'{img emoticon_0022 30 30} I\'m sorry',8),(2,1,2,'{img emoticon_0001 30 30} Thanks',9),(3,1,3,'{img emoticon_0002 30 30} Good',10),(4,1,4,'{img emoticon_0010 30 30} Surprised',16),(5,1,5,'{img emoticon_0016 30 30} Crying',17),(6,1,6,'{img emoticon_0007 30 30} Love',1),(7,1,7,'{img emoticon_0006 30 30} Hello',6),(8,1,8,'',0),(9,1,9,'',0),(10,1,10,'',0);
/*!40000 ALTER TABLE `chatmacros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_items`
--

DROP TABLE IF EXISTS `collection_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_items` (
  `accountId` bigint(20) NOT NULL,
  `collectionId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  KEY `accountId` (`accountId`,`collectionId`),
  CONSTRAINT `collection_item_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_items`
--

LOCK TABLES `collection_items` WRITE;
/*!40000 ALTER TABLE `collection_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections` (
  `accountId` bigint(20) NOT NULL,
  `collectionId` int(11) NOT NULL,
  `isComplete` tinyint(1) NOT NULL DEFAULT 0,
  `timesRedeemed` tinyint(4) NOT NULL DEFAULT 0,
  KEY `accountId` (`accountId`,`collectionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companions`
--

DROP TABLE IF EXISTS `companions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companions` (
  `companionId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `characterId` bigint(20) DEFAULT NULL,
  `monsterId` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `slot` tinyint(1) NOT NULL,
  `barrackLayer` tinyint(1) NOT NULL DEFAULT 1,
  `bx` float NOT NULL,
  `by` float NOT NULL,
  `bz` float NOT NULL,
  `dx` float NOT NULL,
  `dy` float NOT NULL,
  `exp` int(11) NOT NULL DEFAULT 0,
  `stamina` int(11) NOT NULL DEFAULT 60000,
  `adoptTime` datetime DEFAULT current_timestamp(),
  `active` tinyint(1) DEFAULT 1,
  `stat_mhp` int(11) NOT NULL DEFAULT 1,
  `stat_atk` int(11) NOT NULL DEFAULT 1,
  `stat_def` int(11) NOT NULL DEFAULT 1,
  `stat_mdef` int(11) NOT NULL DEFAULT 1,
  `stat_hr` int(11) NOT NULL DEFAULT 1,
  `stat_crthr` int(11) NOT NULL DEFAULT 1,
  `stat_dr` int(11) NOT NULL DEFAULT 1,
  `hp` int(11) NOT NULL DEFAULT 0,
  `totalExp` bigint(20) NOT NULL DEFAULT 0,
  `level` int(11) NOT NULL DEFAULT 1,
  `maxExp` bigint(20) NOT NULL DEFAULT 1000,
  `isAggressiveMode` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`companionId`),
  KEY `accountId` (`accountId`),
  KEY `companions_ibfk_2` (`characterId`),
  CONSTRAINT `companions_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `companions_ibfk_2` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companions`
--

LOCK TABLES `companions` WRITE;
/*!40000 ALTER TABLE `companions` DISABLE KEYS */;
INSERT INTO `companions` VALUES (1,1,1,60045,'asdasd',2,1,-2,17.9487,5,0,0,6,44,'2026-04-25 19:25:48',1,1,1,1,1,1,1,1,241,6,1,100,0),(2,1,1,60045,'adada',1,1,-2,17.9487,5,0,0,0,57,'2026-04-25 19:52:55',1,1,1,1,1,1,1,1,241,0,1,100,0);
/*!40000 ALTER TABLE `companions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cooldowns`
--

DROP TABLE IF EXISTS `cooldowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cooldowns` (
  `cooldownId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `classId` int(11) NOT NULL,
  `remaining` time NOT NULL,
  `duration` time NOT NULL,
  `startTime` datetime NOT NULL,
  PRIMARY KEY (`cooldownId`),
  UNIQUE KEY `uk_character_cooldown` (`characterId`,`classId`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `cooldowns_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cooldowns`
--

LOCK TABLES `cooldowns` WRITE;
/*!40000 ALTER TABLE `cooldowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `cooldowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `duels`
--

DROP TABLE IF EXISTS `duels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `duels` (
  `duelId` bigint(20) NOT NULL AUTO_INCREMENT,
  `winnerId` bigint(20) NOT NULL,
  `loserId` bigint(20) NOT NULL,
  `duelTime` datetime NOT NULL,
  PRIMARY KEY (`duelId`),
  KEY `winnerId` (`winnerId`),
  KEY `loserId` (`loserId`),
  CONSTRAINT `duels_ibfk_1` FOREIGN KEY (`winnerId`) REFERENCES `characters` (`characterId`),
  CONSTRAINT `duels_ibfk_2` FOREIGN KEY (`loserId`) REFERENCES `characters` (`characterId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `duels`
--

LOCK TABLES `duels` WRITE;
/*!40000 ALTER TABLE `duels` DISABLE KEYS */;
/*!40000 ALTER TABLE `duels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friends`
--

DROP TABLE IF EXISTS `friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friends` (
  `friendId` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `friendUserId` bigint(20) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 0,
  `registerDate` datetime DEFAULT current_timestamp(),
  `group` varchar(20) NOT NULL DEFAULT '',
  `note` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`friendId`),
  UNIQUE KEY `accountId` (`userId`,`friendUserId`),
  KEY `friends_ibfk_2` (`friendUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friends`
--

LOCK TABLES `friends` WRITE;
/*!40000 ALTER TABLE `friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guilds`
--

DROP TABLE IF EXISTS `guilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guilds` (
  `guildId` bigint(20) NOT NULL AUTO_INCREMENT,
  `leaderId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `dateCreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`guildId`),
  KEY `leaderId` (`leaderId`),
  KEY `guilds_ibfk_1` (`guildId`),
  CONSTRAINT `guilds_ibfk_1` FOREIGN KEY (`guildId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guilds`
--

LOCK TABLES `guilds` WRITE;
/*!40000 ALTER TABLE `guilds` DISABLE KEYS */;
/*!40000 ALTER TABLE `guilds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `help`
--

DROP TABLE IF EXISTS `help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `help` (
  `accountId` bigint(20) NOT NULL,
  `helpId` smallint(6) NOT NULL,
  `shown` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`accountId`,`helpId`),
  CONSTRAINT `help_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `help`
--

LOCK TABLES `help` WRITE;
/*!40000 ALTER TABLE `help` DISABLE KEYS */;
INSERT INTO `help` VALUES (1,1,1),(1,13,1),(1,17,1),(1,27,1),(1,34,1),(1,863,1),(1,865,1);
/*!40000 ALTER TABLE `help` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `house_props`
--

DROP TABLE IF EXISTS `house_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house_props` (
  `propId` bigint(20) NOT NULL AUTO_INCREMENT,
  `houseId` bigint(20) NOT NULL,
  `furnitureId` int(11) NOT NULL,
  `monsterId` int(11) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `dir` tinyint(4) NOT NULL,
  PRIMARY KEY (`propId`),
  KEY `houseId` (`houseId`),
  KEY `house_props` (`propId`),
  CONSTRAINT `house_props_ibfk_1` FOREIGN KEY (`houseId`) REFERENCES `houses` (`houseId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house_props`
--

LOCK TABLES `house_props` WRITE;
/*!40000 ALTER TABLE `house_props` DISABLE KEYS */;
/*!40000 ALTER TABLE `house_props` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `houses`
--

DROP TABLE IF EXISTS `houses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `houses` (
  `houseId` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ownerId` bigint(20) NOT NULL,
  `ownerName` varchar(255) NOT NULL,
  `mapId` int(11) NOT NULL,
  `lastEnterTime` datetime NOT NULL,
  PRIMARY KEY (`houseId`),
  KEY `ownerId` (`ownerId`),
  KEY `houses` (`houseId`),
  CONSTRAINT `house_ibfk_1` FOREIGN KEY (`ownerId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `houses`
--

LOCK TABLES `houses` WRITE;
/*!40000 ALTER TABLE `houses` DISABLE KEYS */;
/*!40000 ALTER TABLE `houses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `characterId` bigint(20) NOT NULL,
  `itemId` bigint(20) NOT NULL,
  `sort` int(11) NOT NULL,
  `equipSlot` tinyint(4) NOT NULL DEFAULT 127,
  PRIMARY KEY (`characterId`,`itemId`),
  KEY `itemId` (`itemId`),
  CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`itemId`) REFERENCES `items` (`itemUniqueId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,1,1,127),(1,2,0,8),(1,3,6,127),(1,4,7,127),(1,5,8,127),(1,6,10,127),(1,13,9,127),(1,253,0,3),(1,254,0,4),(1,255,0,5),(1,256,5,127),(1,257,0,9),(1,258,0,14),(1,259,2,127),(1,260,0,127),(1,261,3,127),(1,262,4,127),(3,28,0,127),(3,29,1,127),(3,30,2,127),(3,31,3,127),(3,32,4,127),(3,33,5,127),(3,34,0,3),(3,35,0,4),(3,36,0,5),(3,37,0,8),(3,38,0,9),(3,39,0,14),(4,40,0,127),(4,41,1,127),(4,42,2,127),(4,43,3,127),(4,44,4,127),(4,45,0,3),(4,46,0,4),(4,47,0,5),(4,48,0,8),(4,49,0,14),(5,50,0,127),(5,51,1,127),(5,52,2,127),(5,53,3,127),(5,54,4,127),(5,55,0,3),(5,56,0,4),(5,57,0,5),(5,58,0,8),(5,59,0,9),(5,60,0,14),(6,67,0,127),(6,68,1,127),(6,69,2,127),(6,70,3,127),(6,71,4,127),(6,72,5,127),(6,73,6,127),(6,74,7,127),(6,75,8,127),(6,76,9,127),(6,77,10,127),(8,89,0,127),(8,90,1,127),(8,91,2,127),(8,92,3,127),(8,93,4,127),(8,94,5,127),(8,95,0,3),(8,96,0,4),(8,97,0,5),(8,98,0,8),(8,99,0,9),(8,100,0,14),(9,101,0,127),(9,102,1,127),(9,103,2,127),(9,104,3,127),(9,105,4,127),(9,106,0,3),(9,107,0,4),(9,108,0,5),(9,109,0,8),(9,110,0,9),(9,111,0,14),(10,112,0,127),(10,113,1,127),(10,114,2,127),(10,115,3,127),(10,116,4,127),(10,117,0,3),(10,118,0,4),(10,119,0,5),(10,120,0,8),(10,121,0,9),(10,122,0,14),(11,123,0,127),(11,124,1,127),(11,125,2,127),(11,126,3,127),(11,127,4,127),(11,128,0,3),(11,129,0,4),(11,130,0,5),(11,131,0,8),(11,132,0,14),(12,133,0,127),(12,134,1,127),(12,135,2,127),(12,136,3,127),(12,137,4,127),(12,138,0,3),(12,139,0,4),(12,140,0,5),(12,141,0,8),(12,142,0,9),(12,143,0,14),(13,144,0,127),(13,145,1,127),(13,146,2,127),(13,147,3,127),(13,148,4,127),(13,149,0,3),(13,150,0,4),(13,151,0,5),(13,152,0,8),(13,153,0,9),(13,154,0,14),(14,155,0,127),(14,156,1,127),(14,157,2,127),(14,158,3,127),(14,159,4,127),(14,160,0,3),(14,161,0,4),(14,162,0,5),(14,163,0,8),(14,164,0,9),(14,165,0,14),(15,166,0,127),(15,167,1,127),(15,168,2,127),(15,169,3,127),(15,170,4,127),(15,171,0,3),(15,172,0,4),(15,173,0,5),(15,174,0,8),(15,175,0,14),(16,176,0,127),(16,177,1,127),(16,178,2,127),(16,179,3,127),(16,180,4,127),(16,181,0,3),(16,182,0,4),(16,183,0,5),(16,184,0,8),(16,185,0,9),(16,186,0,14),(17,187,0,127),(17,188,1,127),(17,189,2,127),(17,190,3,127),(17,191,4,127),(17,192,0,3),(17,193,0,4),(17,194,0,5),(17,195,0,8),(17,196,0,9),(17,197,0,14),(18,198,0,127),(18,199,1,127),(18,200,2,127),(18,201,3,127),(18,202,4,127),(18,203,0,3),(18,204,0,4),(18,205,0,5),(18,206,0,8),(18,207,0,9),(18,208,0,14),(19,209,0,127),(19,210,1,127),(19,211,2,127),(19,212,3,127),(19,213,4,127),(19,214,5,127),(19,215,0,3),(19,216,0,4),(19,217,0,5),(19,218,0,8),(19,219,0,9),(19,220,0,14),(20,221,0,127),(20,222,5,127),(20,223,6,127),(20,224,7,127),(20,225,8,127),(20,226,4,127),(20,227,2,127),(20,228,1,127),(20,229,0,8),(20,230,0,9),(20,231,3,127),(21,232,0,127),(21,233,1,127),(21,234,2,127),(21,235,3,127),(21,236,4,127),(21,237,0,3),(21,238,0,4),(21,239,0,5),(21,240,0,8),(21,241,0,14),(22,242,0,127),(22,243,1,127),(22,244,2,127),(22,245,3,127),(22,246,4,127),(22,247,0,3),(22,248,0,4),(22,249,0,5),(22,250,0,8),(22,251,0,9),(22,252,0,14);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`melia`@`localhost`*/ /*!50003 TRIGGER `cascadeDeleteItem` AFTER DELETE ON `inventory` FOR EACH ROW
	DELETE FROM `items` WHERE `itemUniqueId` = OLD.`itemId` */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ip_bans`
--

DROP TABLE IF EXISTS `ip_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_bans` (
  `ipBanId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL,
  `fromDate` datetime NOT NULL,
  `toDate` datetime NOT NULL,
  `reason` varchar(128) NOT NULL,
  PRIMARY KEY (`ipBanId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_bans`
--

LOCK TABLES `ip_bans` WRITE;
/*!40000 ALTER TABLE `ip_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_properties`
--

DROP TABLE IF EXISTS `item_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_properties` (
  `propertyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `itemId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(1) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`propertyId`),
  UNIQUE KEY `uk_item_property` (`itemId`,`name`),
  KEY `itemId` (`itemId`),
  CONSTRAINT `item_properties_ibfk_1` FOREIGN KEY (`itemId`) REFERENCES `items` (`itemUniqueId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5136 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_properties`
--

LOCK TABLES `item_properties` WRITE;
/*!40000 ALTER TABLE `item_properties` DISABLE KEYS */;
INSERT INTO `item_properties` VALUES (1,1,'UseLv','f','1'),(2,2,'UseLv','f','1'),(3,2,'ItemGrade','f','1'),(4,2,'SellPrice','f','200'),(5,2,'PR','f','2'),(6,2,'MaxPR','f','2'),(7,2,'MaxDur','f','5000'),(8,2,'Dur','f','5000'),(9,3,'UseLv','f','1'),(10,3,'SellPrice','f','16'),(11,4,'UseLv','f','1'),(12,4,'SellPrice','f','24'),(13,5,'UseLv','f','1'),(14,6,'UseLv','f','1'),(15,6,'SellPrice','f','6'),(74,13,'UseLv','f','1'),(75,13,'SellPrice','f','100'),(1418,28,'UseLv','f','1'),(1419,29,'UseLv','f','1'),(1420,29,'SellPrice','f','16'),(1421,30,'UseLv','f','1'),(1422,30,'SellPrice','f','24'),(1423,31,'UseLv','f','1'),(1424,32,'UseLv','f','1'),(1425,32,'SellPrice','f','100'),(1426,33,'UseLv','f','1'),(1427,33,'SellPrice','f','6'),(1428,34,'UseLv','f','1'),(1429,34,'ItemGrade','f','1'),(1430,34,'SellPrice','f','72'),(1431,34,'BaseSocket','f','1'),(1432,34,'MaxSocket_COUNT','f','1'),(1433,34,'PR','f','4'),(1434,34,'MaxPR','f','4'),(1435,34,'MaxSocket','f','1'),(1436,34,'MaxDur','f','4000'),(1437,34,'Dur','f','4000'),(1438,35,'UseLv','f','1'),(1439,35,'ItemGrade','f','1'),(1440,35,'SellPrice','f','36'),(1441,35,'BaseSocket','f','1'),(1442,35,'MaxSocket_COUNT','f','1'),(1443,35,'PR','f','4'),(1444,35,'MaxPR','f','4'),(1445,35,'MaxSocket','f','1'),(1446,35,'MaxDur','f','4000'),(1447,35,'Dur','f','4000'),(1448,36,'UseLv','f','1'),(1449,36,'ItemGrade','f','1'),(1450,36,'SellPrice','f','36'),(1451,36,'BaseSocket','f','1'),(1452,36,'MaxSocket_COUNT','f','1'),(1453,36,'PR','f','4'),(1454,36,'MaxPR','f','4'),(1455,36,'MaxSocket','f','1'),(1456,36,'MaxDur','f','4000'),(1457,36,'Dur','f','4000'),(1458,37,'UseLv','f','1'),(1459,37,'ItemGrade','f','1'),(1460,37,'SellPrice','f','80'),(1461,37,'MNA','f','2'),(1462,37,'PR','f','3'),(1463,37,'MaxPR','f','3'),(1464,37,'MaxDur','f','1800'),(1465,37,'Dur','f','1800'),(1466,38,'UseLv','f','1'),(1467,38,'ItemGrade','f','1'),(1468,38,'SellPrice','f','48'),(1469,38,'MGP','f','100'),(1470,38,'BlockRate','f','1'),(1471,38,'BLK','f','4'),(1472,38,'BaseSocket','f','1'),(1473,38,'MaxSocket_COUNT','f','1'),(1474,38,'PR','f','2'),(1475,38,'MaxPR','f','2'),(1476,38,'MaxSocket','f','1'),(1477,38,'MaxDur','f','3800'),(1478,38,'Dur','f','3800'),(1479,39,'UseLv','f','1'),(1480,39,'ItemGrade','f','1'),(1481,39,'SellPrice','f','72'),(1482,39,'BaseSocket','f','1'),(1483,39,'MaxSocket_COUNT','f','1'),(1484,39,'PR','f','4'),(1485,39,'MaxPR','f','4'),(1486,39,'MaxSocket','f','1'),(1487,39,'MaxDur','f','4000'),(1488,39,'Dur','f','4000'),(1631,40,'UseLv','f','1'),(1632,41,'UseLv','f','1'),(1633,41,'SellPrice','f','16'),(1634,42,'UseLv','f','1'),(1635,42,'SellPrice','f','24'),(1636,43,'UseLv','f','1'),(1637,44,'UseLv','f','1'),(1638,44,'SellPrice','f','6'),(1639,45,'UseLv','f','1'),(1640,45,'ItemGrade','f','1'),(1641,45,'SellPrice','f','72'),(1642,45,'BaseSocket','f','1'),(1643,45,'MaxSocket_COUNT','f','1'),(1644,45,'PR','f','3'),(1645,45,'MaxPR','f','3'),(1646,45,'MaxSocket','f','1'),(1647,45,'MaxDur','f','4200'),(1648,45,'Dur','f','1680'),(1649,46,'UseLv','f','1'),(1650,46,'ItemGrade','f','1'),(1651,46,'SellPrice','f','36'),(1652,46,'BaseSocket','f','1'),(1653,46,'MaxSocket_COUNT','f','1'),(1654,46,'PR','f','3'),(1655,46,'MaxPR','f','3'),(1656,46,'MaxSocket','f','1'),(1657,46,'MaxDur','f','4200'),(1658,46,'Dur','f','1680'),(1659,47,'UseLv','f','1'),(1660,47,'ItemGrade','f','1'),(1661,47,'SellPrice','f','36'),(1662,47,'BaseSocket','f','1'),(1663,47,'MaxSocket_COUNT','f','1'),(1664,47,'PR','f','3'),(1665,47,'MaxPR','f','3'),(1666,47,'MaxSocket','f','1'),(1667,47,'MaxDur','f','4200'),(1668,47,'Dur','f','1680'),(1669,48,'UseLv','f','1'),(1670,48,'ItemGrade','f','1'),(1671,48,'SellPrice','f','128'),(1672,48,'DEX','f','2'),(1673,48,'PR','f','3'),(1674,48,'MaxPR','f','3'),(1675,48,'MaxDur','f','1900'),(1676,48,'Dur','f','760'),(1677,49,'UseLv','f','1'),(1678,49,'ItemGrade','f','1'),(1679,49,'SellPrice','f','72'),(1680,49,'BaseSocket','f','1'),(1681,49,'MaxSocket_COUNT','f','1'),(1682,49,'PR','f','3'),(1683,49,'MaxPR','f','3'),(1684,49,'MaxSocket','f','1'),(1685,49,'MaxDur','f','4200'),(1686,49,'Dur','f','1680'),(1799,50,'UseLv','f','1'),(1800,51,'UseLv','f','1'),(1801,51,'SellPrice','f','16'),(1802,52,'UseLv','f','1'),(1803,52,'SellPrice','f','24'),(1804,53,'UseLv','f','1'),(1805,54,'UseLv','f','1'),(1806,54,'SellPrice','f','6'),(1807,55,'UseLv','f','1'),(1808,55,'ItemGrade','f','1'),(1809,55,'SellPrice','f','72'),(1810,55,'BaseSocket','f','1'),(1811,55,'MaxSocket_COUNT','f','1'),(1812,55,'PR','f','4'),(1813,55,'MaxPR','f','4'),(1814,55,'MaxSocket','f','1'),(1815,55,'MaxDur','f','4000'),(1816,55,'Dur','f','4000'),(1817,56,'UseLv','f','1'),(1818,56,'ItemGrade','f','1'),(1819,56,'SellPrice','f','36'),(1820,56,'BaseSocket','f','1'),(1821,56,'MaxSocket_COUNT','f','1'),(1822,56,'PR','f','4'),(1823,56,'MaxPR','f','4'),(1824,56,'MaxSocket','f','1'),(1825,56,'MaxDur','f','4000'),(1826,56,'Dur','f','4000'),(1827,57,'UseLv','f','1'),(1828,57,'ItemGrade','f','1'),(1829,57,'SellPrice','f','36'),(1830,57,'BaseSocket','f','1'),(1831,57,'MaxSocket_COUNT','f','1'),(1832,57,'PR','f','4'),(1833,57,'MaxPR','f','4'),(1834,57,'MaxSocket','f','1'),(1835,57,'MaxDur','f','4000'),(1836,57,'Dur','f','4000'),(1837,58,'UseLv','f','1'),(1838,58,'ItemGrade','f','1'),(1839,58,'SellPrice','f','80'),(1840,58,'Strike','f','2'),(1841,58,'PR','f','3'),(1842,58,'MaxPR','f','3'),(1843,58,'MaxDur','f','1900'),(1844,58,'Dur','f','1900'),(1845,59,'UseLv','f','1'),(1846,59,'ItemGrade','f','1'),(1847,59,'SellPrice','f','48'),(1848,59,'MGP','f','100'),(1849,59,'BlockRate','f','1'),(1850,59,'BLK','f','4'),(1851,59,'BaseSocket','f','1'),(1852,59,'MaxSocket_COUNT','f','1'),(1853,59,'PR','f','2'),(1854,59,'MaxPR','f','2'),(1855,59,'MaxSocket','f','1'),(1856,59,'MaxDur','f','3800'),(1857,59,'Dur','f','3800'),(1858,60,'UseLv','f','1'),(1859,60,'ItemGrade','f','1'),(1860,60,'SellPrice','f','72'),(1861,60,'BaseSocket','f','1'),(1862,60,'MaxSocket_COUNT','f','1'),(1863,60,'PR','f','4'),(1864,60,'MaxPR','f','4'),(1865,60,'MaxSocket','f','1'),(1866,60,'MaxDur','f','4000'),(1867,60,'Dur','f','4000'),(1941,67,'UseLv','f','1'),(1942,68,'UseLv','f','1'),(1943,68,'ItemGrade','f','1'),(1944,68,'SellPrice','f','80'),(1945,68,'Slash','f','3'),(1946,68,'PR','f','3'),(1947,68,'MaxPR','f','3'),(1948,68,'MaxDur','f','1800'),(1949,68,'Dur','f','1800'),(1950,69,'UseLv','f','1'),(1951,69,'ItemGrade','f','1'),(1952,69,'SellPrice','f','36'),(1953,69,'BaseSocket','f','1'),(1954,69,'MaxSocket_COUNT','f','1'),(1955,69,'PR','f','3'),(1956,69,'MaxPR','f','3'),(1957,69,'MaxSocket','f','1'),(1958,69,'MaxDur','f','4200'),(1959,69,'Dur','f','4200'),(1960,70,'UseLv','f','1'),(1961,70,'ItemGrade','f','1'),(1962,70,'SellPrice','f','36'),(1963,70,'BaseSocket','f','1'),(1964,70,'MaxSocket_COUNT','f','1'),(1965,70,'PR','f','3'),(1966,70,'MaxPR','f','3'),(1967,70,'MaxSocket','f','1'),(1968,70,'MaxDur','f','4200'),(1969,70,'Dur','f','4200'),(1970,71,'UseLv','f','1'),(1971,71,'ItemGrade','f','1'),(1972,71,'SellPrice','f','72'),(1973,71,'BaseSocket','f','1'),(1974,71,'MaxSocket_COUNT','f','1'),(1975,71,'PR','f','3'),(1976,71,'MaxPR','f','3'),(1977,71,'MaxSocket','f','1'),(1978,71,'MaxDur','f','4200'),(1979,71,'Dur','f','4200'),(1980,72,'UseLv','f','1'),(1981,72,'ItemGrade','f','1'),(1982,72,'SellPrice','f','48'),(1983,72,'MGP','f','100'),(1984,72,'BlockRate','f','1'),(1985,72,'BLK','f','4'),(1986,72,'BaseSocket','f','1'),(1987,72,'MaxSocket_COUNT','f','1'),(1988,72,'PR','f','2'),(1989,72,'MaxPR','f','2'),(1990,72,'MaxSocket','f','1'),(1991,72,'MaxDur','f','3800'),(1992,72,'Dur','f','3800'),(1993,73,'UseLv','f','1'),(1994,73,'ItemGrade','f','1'),(1995,73,'SellPrice','f','72'),(1996,73,'BaseSocket','f','1'),(1997,73,'MaxSocket_COUNT','f','1'),(1998,73,'PR','f','3'),(1999,73,'MaxPR','f','3'),(2000,73,'MaxSocket','f','1'),(2001,73,'MaxDur','f','4200'),(2002,73,'Dur','f','4200'),(2003,74,'UseLv','f','1'),(2004,74,'SellPrice','f','16'),(2005,75,'UseLv','f','1'),(2006,75,'SellPrice','f','24'),(2007,76,'UseLv','f','1'),(2008,77,'UseLv','f','1'),(2009,77,'SellPrice','f','6'),(2148,89,'UseLv','f','1'),(2149,90,'UseLv','f','1'),(2150,90,'ItemGrade','f','1'),(2151,90,'SellPrice','f','200'),(2152,90,'PR','f','2'),(2153,90,'MaxPR','f','2'),(2154,90,'MaxDur','f','5000'),(2155,90,'Dur','f','5000'),(2156,91,'UseLv','f','1'),(2157,91,'SellPrice','f','16'),(2158,92,'UseLv','f','1'),(2159,92,'SellPrice','f','24'),(2160,93,'UseLv','f','1'),(2161,94,'UseLv','f','1'),(2162,94,'SellPrice','f','6'),(2163,95,'UseLv','f','1'),(2164,95,'ItemGrade','f','1'),(2165,95,'SellPrice','f','72'),(2166,95,'BaseSocket','f','1'),(2167,95,'MaxSocket_COUNT','f','1'),(2168,95,'PR','f','3'),(2169,95,'MaxPR','f','3'),(2170,95,'MaxSocket','f','1'),(2171,95,'MaxDur','f','4200'),(2172,95,'Dur','f','840'),(2173,96,'UseLv','f','1'),(2174,96,'ItemGrade','f','1'),(2175,96,'SellPrice','f','36'),(2176,96,'BaseSocket','f','1'),(2177,96,'MaxSocket_COUNT','f','1'),(2178,96,'PR','f','3'),(2179,96,'MaxPR','f','3'),(2180,96,'MaxSocket','f','1'),(2181,96,'MaxDur','f','4200'),(2182,96,'Dur','f','840'),(2183,97,'UseLv','f','1'),(2184,97,'ItemGrade','f','1'),(2185,97,'SellPrice','f','36'),(2186,97,'BaseSocket','f','1'),(2187,97,'MaxSocket_COUNT','f','1'),(2188,97,'PR','f','3'),(2189,97,'MaxPR','f','3'),(2190,97,'MaxSocket','f','1'),(2191,97,'MaxDur','f','4200'),(2192,97,'Dur','f','840'),(2193,98,'UseLv','f','1'),(2194,98,'ItemGrade','f','1'),(2195,98,'SellPrice','f','200'),(2196,98,'BaseSocket','f','1'),(2197,98,'MaxSocket_COUNT','f','1'),(2198,98,'PR','f','6'),(2199,98,'MaxPR','f','6'),(2200,98,'MaxSocket','f','1'),(2201,98,'MaxDur','f','3800'),(2202,98,'Dur','f','760'),(2203,99,'UseLv','f','1'),(2204,99,'ItemGrade','f','1'),(2205,99,'SellPrice','f','80'),(2206,99,'Slash','f','3'),(2207,99,'PR','f','3'),(2208,99,'MaxPR','f','3'),(2209,99,'MaxDur','f','1800'),(2210,99,'Dur','f','360'),(2211,100,'UseLv','f','1'),(2212,100,'ItemGrade','f','1'),(2213,100,'SellPrice','f','72'),(2214,100,'BaseSocket','f','1'),(2215,100,'MaxSocket_COUNT','f','1'),(2216,100,'PR','f','3'),(2217,100,'MaxPR','f','3'),(2218,100,'MaxSocket','f','1'),(2219,100,'MaxDur','f','4200'),(2220,100,'Dur','f','840'),(2367,101,'UseLv','f','1'),(2368,102,'UseLv','f','1'),(2369,102,'SellPrice','f','16'),(2370,103,'UseLv','f','1'),(2371,103,'SellPrice','f','24'),(2372,104,'UseLv','f','1'),(2373,105,'UseLv','f','1'),(2374,105,'SellPrice','f','6'),(2375,106,'UseLv','f','1'),(2376,106,'ItemGrade','f','1'),(2377,106,'SellPrice','f','72'),(2378,106,'BaseSocket','f','1'),(2379,106,'MaxSocket_COUNT','f','1'),(2380,106,'PR','f','4'),(2381,106,'MaxPR','f','4'),(2382,106,'MaxSocket','f','1'),(2383,106,'MaxDur','f','4000'),(2384,106,'Dur','f','4000'),(2385,107,'UseLv','f','1'),(2386,107,'ItemGrade','f','1'),(2387,107,'SellPrice','f','36'),(2388,107,'BaseSocket','f','1'),(2389,107,'MaxSocket_COUNT','f','1'),(2390,107,'PR','f','4'),(2391,107,'MaxPR','f','4'),(2392,107,'MaxSocket','f','1'),(2393,107,'MaxDur','f','4000'),(2394,107,'Dur','f','4000'),(2395,108,'UseLv','f','1'),(2396,108,'ItemGrade','f','1'),(2397,108,'SellPrice','f','36'),(2398,108,'BaseSocket','f','1'),(2399,108,'MaxSocket_COUNT','f','1'),(2400,108,'PR','f','4'),(2401,108,'MaxPR','f','4'),(2402,108,'MaxSocket','f','1'),(2403,108,'MaxDur','f','4000'),(2404,108,'Dur','f','4000'),(2405,109,'UseLv','f','1'),(2406,109,'ItemGrade','f','1'),(2407,109,'SellPrice','f','80'),(2408,109,'MNA','f','2'),(2409,109,'PR','f','3'),(2410,109,'MaxPR','f','3'),(2411,109,'MaxDur','f','1800'),(2412,109,'Dur','f','1800'),(2413,110,'UseLv','f','1'),(2414,110,'ItemGrade','f','1'),(2415,110,'SellPrice','f','48'),(2416,110,'MGP','f','100'),(2417,110,'BlockRate','f','1'),(2418,110,'BLK','f','4'),(2419,110,'BaseSocket','f','1'),(2420,110,'MaxSocket_COUNT','f','1'),(2421,110,'PR','f','2'),(2422,110,'MaxPR','f','2'),(2423,110,'MaxSocket','f','1'),(2424,110,'MaxDur','f','3800'),(2425,110,'Dur','f','3800'),(2426,111,'UseLv','f','1'),(2427,111,'ItemGrade','f','1'),(2428,111,'SellPrice','f','72'),(2429,111,'BaseSocket','f','1'),(2430,111,'MaxSocket_COUNT','f','1'),(2431,111,'PR','f','4'),(2432,111,'MaxPR','f','4'),(2433,111,'MaxSocket','f','1'),(2434,111,'MaxDur','f','4000'),(2435,111,'Dur','f','4000'),(2505,112,'UseLv','f','1'),(2506,113,'UseLv','f','1'),(2507,113,'SellPrice','f','16'),(2508,114,'UseLv','f','1'),(2509,114,'SellPrice','f','24'),(2510,115,'UseLv','f','1'),(2511,116,'UseLv','f','1'),(2512,116,'SellPrice','f','6'),(2513,117,'UseLv','f','1'),(2514,117,'ItemGrade','f','1'),(2515,117,'SellPrice','f','72'),(2516,117,'BaseSocket','f','1'),(2517,117,'MaxSocket_COUNT','f','1'),(2518,117,'PR','f','4'),(2519,117,'MaxPR','f','4'),(2520,117,'MaxSocket','f','1'),(2521,117,'MaxDur','f','4000'),(2522,117,'Dur','f','3200'),(2523,118,'UseLv','f','1'),(2524,118,'ItemGrade','f','1'),(2525,118,'SellPrice','f','36'),(2526,118,'BaseSocket','f','1'),(2527,118,'MaxSocket_COUNT','f','1'),(2528,118,'PR','f','4'),(2529,118,'MaxPR','f','4'),(2530,118,'MaxSocket','f','1'),(2531,118,'MaxDur','f','4000'),(2532,118,'Dur','f','3200'),(2533,119,'UseLv','f','1'),(2534,119,'ItemGrade','f','1'),(2535,119,'SellPrice','f','36'),(2536,119,'BaseSocket','f','1'),(2537,119,'MaxSocket_COUNT','f','1'),(2538,119,'PR','f','4'),(2539,119,'MaxPR','f','4'),(2540,119,'MaxSocket','f','1'),(2541,119,'MaxDur','f','4000'),(2542,119,'Dur','f','3200'),(2543,120,'UseLv','f','1'),(2544,120,'ItemGrade','f','1'),(2545,120,'SellPrice','f','80'),(2546,120,'MNA','f','2'),(2547,120,'PR','f','3'),(2548,120,'MaxPR','f','3'),(2549,120,'MaxDur','f','1800'),(2550,120,'Dur','f','1440'),(2551,121,'UseLv','f','1'),(2552,121,'ItemGrade','f','1'),(2553,121,'SellPrice','f','48'),(2554,121,'MGP','f','100'),(2555,121,'BlockRate','f','1'),(2556,121,'BLK','f','4'),(2557,121,'BaseSocket','f','1'),(2558,121,'MaxSocket_COUNT','f','1'),(2559,121,'PR','f','2'),(2560,121,'MaxPR','f','2'),(2561,121,'MaxSocket','f','1'),(2562,121,'MaxDur','f','3800'),(2563,121,'Dur','f','3040'),(2564,122,'UseLv','f','1'),(2565,122,'ItemGrade','f','1'),(2566,122,'SellPrice','f','72'),(2567,122,'BaseSocket','f','1'),(2568,122,'MaxSocket_COUNT','f','1'),(2569,122,'PR','f','4'),(2570,122,'MaxPR','f','4'),(2571,122,'MaxSocket','f','1'),(2572,122,'MaxDur','f','4000'),(2573,122,'Dur','f','3200'),(2643,123,'UseLv','f','1'),(2644,124,'UseLv','f','1'),(2645,124,'SellPrice','f','16'),(2646,125,'UseLv','f','1'),(2647,125,'SellPrice','f','24'),(2648,126,'UseLv','f','1'),(2649,127,'UseLv','f','1'),(2650,127,'SellPrice','f','6'),(2651,128,'UseLv','f','1'),(2652,128,'ItemGrade','f','1'),(2653,128,'SellPrice','f','72'),(2654,128,'BaseSocket','f','1'),(2655,128,'MaxSocket_COUNT','f','1'),(2656,128,'PR','f','3'),(2657,128,'MaxPR','f','3'),(2658,128,'MaxSocket','f','1'),(2659,128,'MaxDur','f','4200'),(2660,128,'Dur','f','4200'),(2661,129,'UseLv','f','1'),(2662,129,'ItemGrade','f','1'),(2663,129,'SellPrice','f','36'),(2664,129,'BaseSocket','f','1'),(2665,129,'MaxSocket_COUNT','f','1'),(2666,129,'PR','f','3'),(2667,129,'MaxPR','f','3'),(2668,129,'MaxSocket','f','1'),(2669,129,'MaxDur','f','4200'),(2670,129,'Dur','f','4200'),(2671,130,'UseLv','f','1'),(2672,130,'ItemGrade','f','1'),(2673,130,'SellPrice','f','36'),(2674,130,'BaseSocket','f','1'),(2675,130,'MaxSocket_COUNT','f','1'),(2676,130,'PR','f','3'),(2677,130,'MaxPR','f','3'),(2678,130,'MaxSocket','f','1'),(2679,130,'MaxDur','f','4200'),(2680,130,'Dur','f','4200'),(2681,131,'UseLv','f','1'),(2682,131,'ItemGrade','f','1'),(2683,131,'SellPrice','f','128'),(2684,131,'DEX','f','2'),(2685,131,'PR','f','3'),(2686,131,'MaxPR','f','3'),(2687,131,'MaxDur','f','1900'),(2688,131,'Dur','f','1900'),(2689,132,'UseLv','f','1'),(2690,132,'ItemGrade','f','1'),(2691,132,'SellPrice','f','72'),(2692,132,'BaseSocket','f','1'),(2693,132,'MaxSocket_COUNT','f','1'),(2694,132,'PR','f','3'),(2695,132,'MaxPR','f','3'),(2696,132,'MaxSocket','f','1'),(2697,132,'MaxDur','f','4200'),(2698,132,'Dur','f','4200'),(2699,133,'UseLv','f','1'),(2700,134,'UseLv','f','1'),(2701,134,'SellPrice','f','16'),(2702,135,'UseLv','f','1'),(2703,135,'SellPrice','f','24'),(2704,136,'UseLv','f','1'),(2705,137,'UseLv','f','1'),(2706,137,'SellPrice','f','6'),(2707,138,'UseLv','f','1'),(2708,138,'ItemGrade','f','1'),(2709,138,'SellPrice','f','72'),(2710,138,'BaseSocket','f','1'),(2711,138,'MaxSocket_COUNT','f','1'),(2712,138,'PR','f','4'),(2713,138,'MaxPR','f','4'),(2714,138,'MaxSocket','f','1'),(2715,138,'MaxDur','f','4000'),(2716,138,'Dur','f','4000'),(2717,139,'UseLv','f','1'),(2718,139,'ItemGrade','f','1'),(2719,139,'SellPrice','f','36'),(2720,139,'BaseSocket','f','1'),(2721,139,'MaxSocket_COUNT','f','1'),(2722,139,'PR','f','4'),(2723,139,'MaxPR','f','4'),(2724,139,'MaxSocket','f','1'),(2725,139,'MaxDur','f','4000'),(2726,139,'Dur','f','4000'),(2727,140,'UseLv','f','1'),(2728,140,'ItemGrade','f','1'),(2729,140,'SellPrice','f','36'),(2730,140,'BaseSocket','f','1'),(2731,140,'MaxSocket_COUNT','f','1'),(2732,140,'PR','f','4'),(2733,140,'MaxPR','f','4'),(2734,140,'MaxSocket','f','1'),(2735,140,'MaxDur','f','4000'),(2736,140,'Dur','f','4000'),(2737,141,'UseLv','f','1'),(2738,141,'ItemGrade','f','1'),(2739,141,'SellPrice','f','80'),(2740,141,'MNA','f','2'),(2741,141,'PR','f','3'),(2742,141,'MaxPR','f','3'),(2743,141,'MaxDur','f','1800'),(2744,141,'Dur','f','1800'),(2745,142,'UseLv','f','1'),(2746,142,'ItemGrade','f','1'),(2747,142,'SellPrice','f','48'),(2748,142,'MGP','f','100'),(2749,142,'BlockRate','f','1'),(2750,142,'BLK','f','4'),(2751,142,'BaseSocket','f','1'),(2752,142,'MaxSocket_COUNT','f','1'),(2753,142,'PR','f','2'),(2754,142,'MaxPR','f','2'),(2755,142,'MaxSocket','f','1'),(2756,142,'MaxDur','f','3800'),(2757,142,'Dur','f','3800'),(2758,143,'UseLv','f','1'),(2759,143,'ItemGrade','f','1'),(2760,143,'SellPrice','f','72'),(2761,143,'BaseSocket','f','1'),(2762,143,'MaxSocket_COUNT','f','1'),(2763,143,'PR','f','4'),(2764,143,'MaxPR','f','4'),(2765,143,'MaxSocket','f','1'),(2766,143,'MaxDur','f','4000'),(2767,143,'Dur','f','4000'),(2768,144,'UseLv','f','1'),(2769,145,'UseLv','f','1'),(2770,145,'SellPrice','f','16'),(2771,146,'UseLv','f','1'),(2772,146,'SellPrice','f','24'),(2773,147,'UseLv','f','1'),(2774,148,'UseLv','f','1'),(2775,148,'SellPrice','f','6'),(2776,149,'UseLv','f','1'),(2777,149,'ItemGrade','f','1'),(2778,149,'SellPrice','f','72'),(2779,149,'BaseSocket','f','1'),(2780,149,'MaxSocket_COUNT','f','1'),(2781,149,'PR','f','4'),(2782,149,'MaxPR','f','4'),(2783,149,'MaxSocket','f','1'),(2784,149,'MaxDur','f','4000'),(2785,149,'Dur','f','4000'),(2786,150,'UseLv','f','1'),(2787,150,'ItemGrade','f','1'),(2788,150,'SellPrice','f','36'),(2789,150,'BaseSocket','f','1'),(2790,150,'MaxSocket_COUNT','f','1'),(2791,150,'PR','f','4'),(2792,150,'MaxPR','f','4'),(2793,150,'MaxSocket','f','1'),(2794,150,'MaxDur','f','4000'),(2795,150,'Dur','f','4000'),(2796,151,'UseLv','f','1'),(2797,151,'ItemGrade','f','1'),(2798,151,'SellPrice','f','36'),(2799,151,'BaseSocket','f','1'),(2800,151,'MaxSocket_COUNT','f','1'),(2801,151,'PR','f','4'),(2802,151,'MaxPR','f','4'),(2803,151,'MaxSocket','f','1'),(2804,151,'MaxDur','f','4000'),(2805,151,'Dur','f','4000'),(2806,152,'UseLv','f','1'),(2807,152,'ItemGrade','f','1'),(2808,152,'SellPrice','f','80'),(2809,152,'Strike','f','2'),(2810,152,'PR','f','3'),(2811,152,'MaxPR','f','3'),(2812,152,'MaxDur','f','1900'),(2813,152,'Dur','f','1900'),(2814,153,'UseLv','f','1'),(2815,153,'ItemGrade','f','1'),(2816,153,'SellPrice','f','48'),(2817,153,'MGP','f','100'),(2818,153,'BlockRate','f','1'),(2819,153,'BLK','f','4'),(2820,153,'BaseSocket','f','1'),(2821,153,'MaxSocket_COUNT','f','1'),(2822,153,'PR','f','2'),(2823,153,'MaxPR','f','2'),(2824,153,'MaxSocket','f','1'),(2825,153,'MaxDur','f','3800'),(2826,153,'Dur','f','3800'),(2827,154,'UseLv','f','1'),(2828,154,'ItemGrade','f','1'),(2829,154,'SellPrice','f','72'),(2830,154,'BaseSocket','f','1'),(2831,154,'MaxSocket_COUNT','f','1'),(2832,154,'PR','f','4'),(2833,154,'MaxPR','f','4'),(2834,154,'MaxSocket','f','1'),(2835,154,'MaxDur','f','4000'),(2836,154,'Dur','f','4000'),(2837,155,'UseLv','f','1'),(2838,156,'UseLv','f','1'),(2839,156,'SellPrice','f','16'),(2840,157,'UseLv','f','1'),(2841,157,'SellPrice','f','24'),(2842,158,'UseLv','f','1'),(2843,159,'UseLv','f','1'),(2844,159,'SellPrice','f','6'),(2845,160,'UseLv','f','1'),(2846,160,'ItemGrade','f','1'),(2847,160,'SellPrice','f','72'),(2848,160,'BaseSocket','f','1'),(2849,160,'MaxSocket_COUNT','f','1'),(2850,160,'PR','f','3'),(2851,160,'MaxPR','f','3'),(2852,160,'MaxSocket','f','1'),(2853,160,'MaxDur','f','4200'),(2854,160,'Dur','f','4200'),(2855,161,'UseLv','f','1'),(2856,161,'ItemGrade','f','1'),(2857,161,'SellPrice','f','36'),(2858,161,'BaseSocket','f','1'),(2859,161,'MaxSocket_COUNT','f','1'),(2860,161,'PR','f','3'),(2861,161,'MaxPR','f','3'),(2862,161,'MaxSocket','f','1'),(2863,161,'MaxDur','f','4200'),(2864,161,'Dur','f','4200'),(2865,162,'UseLv','f','1'),(2866,162,'ItemGrade','f','1'),(2867,162,'SellPrice','f','36'),(2868,162,'BaseSocket','f','1'),(2869,162,'MaxSocket_COUNT','f','1'),(2870,162,'PR','f','3'),(2871,162,'MaxPR','f','3'),(2872,162,'MaxSocket','f','1'),(2873,162,'MaxDur','f','4200'),(2874,162,'Dur','f','4200'),(2875,163,'UseLv','f','1'),(2876,163,'ItemGrade','f','1'),(2877,163,'SellPrice','f','80'),(2878,163,'Slash','f','3'),(2879,163,'PR','f','3'),(2880,163,'MaxPR','f','3'),(2881,163,'MaxDur','f','1800'),(2882,163,'Dur','f','1800'),(2883,164,'UseLv','f','1'),(2884,164,'ItemGrade','f','1'),(2885,164,'SellPrice','f','48'),(2886,164,'MGP','f','100'),(2887,164,'BlockRate','f','1'),(2888,164,'BLK','f','4'),(2889,164,'BaseSocket','f','1'),(2890,164,'MaxSocket_COUNT','f','1'),(2891,164,'PR','f','2'),(2892,164,'MaxPR','f','2'),(2893,164,'MaxSocket','f','1'),(2894,164,'MaxDur','f','3800'),(2895,164,'Dur','f','3800'),(2896,165,'UseLv','f','1'),(2897,165,'ItemGrade','f','1'),(2898,165,'SellPrice','f','72'),(2899,165,'BaseSocket','f','1'),(2900,165,'MaxSocket_COUNT','f','1'),(2901,165,'PR','f','3'),(2902,165,'MaxPR','f','3'),(2903,165,'MaxSocket','f','1'),(2904,165,'MaxDur','f','4200'),(2905,165,'Dur','f','4200'),(2975,166,'UseLv','f','1'),(2976,167,'UseLv','f','1'),(2977,167,'SellPrice','f','16'),(2978,168,'UseLv','f','1'),(2979,168,'SellPrice','f','24'),(2980,169,'UseLv','f','1'),(2981,170,'UseLv','f','1'),(2982,170,'SellPrice','f','6'),(2983,171,'UseLv','f','1'),(2984,171,'ItemGrade','f','1'),(2985,171,'SellPrice','f','72'),(2986,171,'BaseSocket','f','1'),(2987,171,'MaxSocket_COUNT','f','1'),(2988,171,'PR','f','3'),(2989,171,'MaxPR','f','3'),(2990,171,'MaxSocket','f','1'),(2991,171,'MaxDur','f','4200'),(2992,171,'Dur','f','4200'),(2993,172,'UseLv','f','1'),(2994,172,'ItemGrade','f','1'),(2995,172,'SellPrice','f','36'),(2996,172,'BaseSocket','f','1'),(2997,172,'MaxSocket_COUNT','f','1'),(2998,172,'PR','f','3'),(2999,172,'MaxPR','f','3'),(3000,172,'MaxSocket','f','1'),(3001,172,'MaxDur','f','4200'),(3002,172,'Dur','f','4200'),(3003,173,'UseLv','f','1'),(3004,173,'ItemGrade','f','1'),(3005,173,'SellPrice','f','36'),(3006,173,'BaseSocket','f','1'),(3007,173,'MaxSocket_COUNT','f','1'),(3008,173,'PR','f','3'),(3009,173,'MaxPR','f','3'),(3010,173,'MaxSocket','f','1'),(3011,173,'MaxDur','f','4200'),(3012,173,'Dur','f','4200'),(3013,174,'UseLv','f','1'),(3014,174,'ItemGrade','f','1'),(3015,174,'SellPrice','f','128'),(3016,174,'DEX','f','2'),(3017,174,'PR','f','3'),(3018,174,'MaxPR','f','3'),(3019,174,'MaxDur','f','1900'),(3020,174,'Dur','f','1900'),(3021,175,'UseLv','f','1'),(3022,175,'ItemGrade','f','1'),(3023,175,'SellPrice','f','72'),(3024,175,'BaseSocket','f','1'),(3025,175,'MaxSocket_COUNT','f','1'),(3026,175,'PR','f','3'),(3027,175,'MaxPR','f','3'),(3028,175,'MaxSocket','f','1'),(3029,175,'MaxDur','f','4200'),(3030,175,'Dur','f','4200'),(3087,176,'UseLv','f','1'),(3088,177,'UseLv','f','1'),(3089,177,'SellPrice','f','16'),(3090,178,'UseLv','f','1'),(3091,178,'SellPrice','f','24'),(3092,179,'UseLv','f','1'),(3093,180,'UseLv','f','1'),(3094,180,'SellPrice','f','6'),(3095,181,'UseLv','f','1'),(3096,181,'ItemGrade','f','1'),(3097,181,'SellPrice','f','72'),(3098,181,'BaseSocket','f','1'),(3099,181,'MaxSocket_COUNT','f','1'),(3100,181,'PR','f','4'),(3101,181,'MaxPR','f','4'),(3102,181,'MaxSocket','f','1'),(3103,181,'MaxDur','f','4000'),(3104,181,'Dur','f','4000'),(3105,182,'UseLv','f','1'),(3106,182,'ItemGrade','f','1'),(3107,182,'SellPrice','f','36'),(3108,182,'BaseSocket','f','1'),(3109,182,'MaxSocket_COUNT','f','1'),(3110,182,'PR','f','4'),(3111,182,'MaxPR','f','4'),(3112,182,'MaxSocket','f','1'),(3113,182,'MaxDur','f','4000'),(3114,182,'Dur','f','4000'),(3115,183,'UseLv','f','1'),(3116,183,'ItemGrade','f','1'),(3117,183,'SellPrice','f','36'),(3118,183,'BaseSocket','f','1'),(3119,183,'MaxSocket_COUNT','f','1'),(3120,183,'PR','f','4'),(3121,183,'MaxPR','f','4'),(3122,183,'MaxSocket','f','1'),(3123,183,'MaxDur','f','4000'),(3124,183,'Dur','f','4000'),(3125,184,'UseLv','f','1'),(3126,184,'ItemGrade','f','1'),(3127,184,'SellPrice','f','80'),(3128,184,'Strike','f','2'),(3129,184,'PR','f','3'),(3130,184,'MaxPR','f','3'),(3131,184,'MaxDur','f','1900'),(3132,184,'Dur','f','1900'),(3133,185,'UseLv','f','1'),(3134,185,'ItemGrade','f','1'),(3135,185,'SellPrice','f','48'),(3136,185,'MGP','f','100'),(3137,185,'BlockRate','f','1'),(3138,185,'BLK','f','4'),(3139,185,'BaseSocket','f','1'),(3140,185,'MaxSocket_COUNT','f','1'),(3141,185,'PR','f','2'),(3142,185,'MaxPR','f','2'),(3143,185,'MaxSocket','f','1'),(3144,185,'MaxDur','f','3800'),(3145,185,'Dur','f','3800'),(3146,186,'UseLv','f','1'),(3147,186,'ItemGrade','f','1'),(3148,186,'SellPrice','f','72'),(3149,186,'BaseSocket','f','1'),(3150,186,'MaxSocket_COUNT','f','1'),(3151,186,'PR','f','4'),(3152,186,'MaxPR','f','4'),(3153,186,'MaxSocket','f','1'),(3154,186,'MaxDur','f','4000'),(3155,186,'Dur','f','4000'),(3225,187,'UseLv','f','1'),(3226,188,'UseLv','f','1'),(3227,188,'SellPrice','f','16'),(3228,189,'UseLv','f','1'),(3229,189,'SellPrice','f','24'),(3230,190,'UseLv','f','1'),(3231,191,'UseLv','f','1'),(3232,191,'SellPrice','f','6'),(3233,192,'UseLv','f','1'),(3234,192,'ItemGrade','f','1'),(3235,192,'SellPrice','f','72'),(3236,192,'BaseSocket','f','1'),(3237,192,'MaxSocket_COUNT','f','1'),(3238,192,'PR','f','4'),(3239,192,'MaxPR','f','4'),(3240,192,'MaxSocket','f','1'),(3241,192,'MaxDur','f','4000'),(3242,192,'Dur','f','4000'),(3243,193,'UseLv','f','1'),(3244,193,'ItemGrade','f','1'),(3245,193,'SellPrice','f','36'),(3246,193,'BaseSocket','f','1'),(3247,193,'MaxSocket_COUNT','f','1'),(3248,193,'PR','f','4'),(3249,193,'MaxPR','f','4'),(3250,193,'MaxSocket','f','1'),(3251,193,'MaxDur','f','4000'),(3252,193,'Dur','f','4000'),(3253,194,'UseLv','f','1'),(3254,194,'ItemGrade','f','1'),(3255,194,'SellPrice','f','36'),(3256,194,'BaseSocket','f','1'),(3257,194,'MaxSocket_COUNT','f','1'),(3258,194,'PR','f','4'),(3259,194,'MaxPR','f','4'),(3260,194,'MaxSocket','f','1'),(3261,194,'MaxDur','f','4000'),(3262,194,'Dur','f','4000'),(3263,195,'UseLv','f','1'),(3264,195,'ItemGrade','f','1'),(3265,195,'SellPrice','f','80'),(3266,195,'Strike','f','2'),(3267,195,'PR','f','3'),(3268,195,'MaxPR','f','3'),(3269,195,'MaxDur','f','1900'),(3270,195,'Dur','f','1900'),(3271,196,'UseLv','f','1'),(3272,196,'ItemGrade','f','1'),(3273,196,'SellPrice','f','48'),(3274,196,'MGP','f','100'),(3275,196,'BlockRate','f','1'),(3276,196,'BLK','f','4'),(3277,196,'BaseSocket','f','1'),(3278,196,'MaxSocket_COUNT','f','1'),(3279,196,'PR','f','2'),(3280,196,'MaxPR','f','2'),(3281,196,'MaxSocket','f','1'),(3282,196,'MaxDur','f','3800'),(3283,196,'Dur','f','3800'),(3284,197,'UseLv','f','1'),(3285,197,'ItemGrade','f','1'),(3286,197,'SellPrice','f','72'),(3287,197,'BaseSocket','f','1'),(3288,197,'MaxSocket_COUNT','f','1'),(3289,197,'PR','f','4'),(3290,197,'MaxPR','f','4'),(3291,197,'MaxSocket','f','1'),(3292,197,'MaxDur','f','4000'),(3293,197,'Dur','f','4000'),(3363,198,'UseLv','f','1'),(3364,199,'UseLv','f','1'),(3365,199,'SellPrice','f','16'),(3366,200,'UseLv','f','1'),(3367,200,'SellPrice','f','24'),(3368,201,'UseLv','f','1'),(3369,202,'UseLv','f','1'),(3370,202,'SellPrice','f','6'),(3371,203,'UseLv','f','1'),(3372,203,'ItemGrade','f','1'),(3373,203,'SellPrice','f','72'),(3374,203,'BaseSocket','f','1'),(3375,203,'MaxSocket_COUNT','f','1'),(3376,203,'PR','f','3'),(3377,203,'MaxPR','f','3'),(3378,203,'MaxSocket','f','1'),(3379,203,'MaxDur','f','4200'),(3380,203,'Dur','f','4200'),(3381,204,'UseLv','f','1'),(3382,204,'ItemGrade','f','1'),(3383,204,'SellPrice','f','36'),(3384,204,'BaseSocket','f','1'),(3385,204,'MaxSocket_COUNT','f','1'),(3386,204,'PR','f','3'),(3387,204,'MaxPR','f','3'),(3388,204,'MaxSocket','f','1'),(3389,204,'MaxDur','f','4200'),(3390,204,'Dur','f','4200'),(3391,205,'UseLv','f','1'),(3392,205,'ItemGrade','f','1'),(3393,205,'SellPrice','f','36'),(3394,205,'BaseSocket','f','1'),(3395,205,'MaxSocket_COUNT','f','1'),(3396,205,'PR','f','3'),(3397,205,'MaxPR','f','3'),(3398,205,'MaxSocket','f','1'),(3399,205,'MaxDur','f','4200'),(3400,205,'Dur','f','4200'),(3401,206,'UseLv','f','1'),(3402,206,'ItemGrade','f','1'),(3403,206,'SellPrice','f','80'),(3404,206,'Slash','f','3'),(3405,206,'PR','f','3'),(3406,206,'MaxPR','f','3'),(3407,206,'MaxDur','f','1800'),(3408,206,'Dur','f','1800'),(3409,207,'UseLv','f','1'),(3410,207,'ItemGrade','f','1'),(3411,207,'SellPrice','f','48'),(3412,207,'MGP','f','100'),(3413,207,'BlockRate','f','1'),(3414,207,'BLK','f','4'),(3415,207,'BaseSocket','f','1'),(3416,207,'MaxSocket_COUNT','f','1'),(3417,207,'PR','f','2'),(3418,207,'MaxPR','f','2'),(3419,207,'MaxSocket','f','1'),(3420,207,'MaxDur','f','3800'),(3421,207,'Dur','f','3800'),(3422,208,'UseLv','f','1'),(3423,208,'ItemGrade','f','1'),(3424,208,'SellPrice','f','72'),(3425,208,'BaseSocket','f','1'),(3426,208,'MaxSocket_COUNT','f','1'),(3427,208,'PR','f','3'),(3428,208,'MaxPR','f','3'),(3429,208,'MaxSocket','f','1'),(3430,208,'MaxDur','f','4200'),(3431,208,'Dur','f','4200'),(3432,209,'UseLv','f','1'),(3433,210,'UseLv','f','1'),(3434,210,'ItemGrade','f','1'),(3435,210,'SellPrice','f','200'),(3436,210,'PR','f','2'),(3437,210,'MaxPR','f','2'),(3438,210,'MaxDur','f','5000'),(3439,210,'Dur','f','5000'),(3440,211,'UseLv','f','1'),(3441,211,'SellPrice','f','16'),(3442,212,'UseLv','f','1'),(3443,212,'SellPrice','f','24'),(3444,213,'UseLv','f','1'),(3445,214,'UseLv','f','1'),(3446,214,'SellPrice','f','6'),(3447,215,'UseLv','f','1'),(3448,215,'ItemGrade','f','1'),(3449,215,'SellPrice','f','72'),(3450,215,'BaseSocket','f','1'),(3451,215,'MaxSocket_COUNT','f','1'),(3452,215,'PR','f','3'),(3453,215,'MaxPR','f','3'),(3454,215,'MaxSocket','f','1'),(3455,215,'MaxDur','f','4200'),(3456,215,'Dur','f','4200'),(3457,216,'UseLv','f','1'),(3458,216,'ItemGrade','f','1'),(3459,216,'SellPrice','f','36'),(3460,216,'BaseSocket','f','1'),(3461,216,'MaxSocket_COUNT','f','1'),(3462,216,'PR','f','3'),(3463,216,'MaxPR','f','3'),(3464,216,'MaxSocket','f','1'),(3465,216,'MaxDur','f','4200'),(3466,216,'Dur','f','4200'),(3467,217,'UseLv','f','1'),(3468,217,'ItemGrade','f','1'),(3469,217,'SellPrice','f','36'),(3470,217,'BaseSocket','f','1'),(3471,217,'MaxSocket_COUNT','f','1'),(3472,217,'PR','f','3'),(3473,217,'MaxPR','f','3'),(3474,217,'MaxSocket','f','1'),(3475,217,'MaxDur','f','4200'),(3476,217,'Dur','f','4200'),(3477,218,'UseLv','f','1'),(3478,218,'ItemGrade','f','1'),(3479,218,'SellPrice','f','200'),(3480,218,'BaseSocket','f','1'),(3481,218,'MaxSocket_COUNT','f','1'),(3482,218,'PR','f','6'),(3483,218,'MaxPR','f','6'),(3484,218,'MaxSocket','f','1'),(3485,218,'MaxDur','f','3800'),(3486,218,'Dur','f','3800'),(3487,219,'UseLv','f','1'),(3488,219,'ItemGrade','f','1'),(3489,219,'SellPrice','f','80'),(3490,219,'Slash','f','3'),(3491,219,'PR','f','3'),(3492,219,'MaxPR','f','3'),(3493,219,'MaxDur','f','1800'),(3494,219,'Dur','f','1800'),(3495,220,'UseLv','f','1'),(3496,220,'ItemGrade','f','1'),(3497,220,'SellPrice','f','72'),(3498,220,'BaseSocket','f','1'),(3499,220,'MaxSocket_COUNT','f','1'),(3500,220,'PR','f','3'),(3501,220,'MaxPR','f','3'),(3502,220,'MaxSocket','f','1'),(3503,220,'MaxDur','f','4200'),(3504,220,'Dur','f','4200'),(3651,221,'UseLv','f','1'),(3652,222,'UseLv','f','1'),(3653,222,'SellPrice','f','16'),(3654,223,'UseLv','f','1'),(3655,223,'SellPrice','f','24'),(3656,224,'UseLv','f','1'),(3657,225,'UseLv','f','1'),(3658,225,'SellPrice','f','6'),(3659,226,'UseLv','f','1'),(3660,226,'ItemGrade','f','1'),(3661,226,'SellPrice','f','72'),(3662,226,'BaseSocket','f','1'),(3663,226,'MaxSocket_COUNT','f','1'),(3664,226,'PR','f','4'),(3665,226,'MaxPR','f','4'),(3666,226,'MaxSocket','f','1'),(3667,226,'MaxDur','f','4000'),(3668,226,'Dur','f','3200'),(3669,227,'UseLv','f','1'),(3670,227,'ItemGrade','f','1'),(3671,227,'SellPrice','f','36'),(3672,227,'BaseSocket','f','1'),(3673,227,'MaxSocket_COUNT','f','1'),(3674,227,'PR','f','4'),(3675,227,'MaxPR','f','4'),(3676,227,'MaxSocket','f','1'),(3677,227,'MaxDur','f','4000'),(3678,227,'Dur','f','3200'),(3679,228,'UseLv','f','1'),(3680,228,'ItemGrade','f','1'),(3681,228,'SellPrice','f','36'),(3682,228,'BaseSocket','f','1'),(3683,228,'MaxSocket_COUNT','f','1'),(3684,228,'PR','f','4'),(3685,228,'MaxPR','f','4'),(3686,228,'MaxSocket','f','1'),(3687,228,'MaxDur','f','4000'),(3688,228,'Dur','f','3200'),(3689,229,'UseLv','f','1'),(3690,229,'ItemGrade','f','1'),(3691,229,'SellPrice','f','80'),(3692,229,'MNA','f','2'),(3693,229,'PR','f','3'),(3694,229,'MaxPR','f','3'),(3695,229,'MaxDur','f','1800'),(3696,229,'Dur','f','1440'),(3697,230,'UseLv','f','1'),(3698,230,'ItemGrade','f','1'),(3699,230,'SellPrice','f','48'),(3700,230,'MGP','f','100'),(3701,230,'BlockRate','f','1'),(3702,230,'BLK','f','4'),(3703,230,'BaseSocket','f','1'),(3704,230,'MaxSocket_COUNT','f','1'),(3705,230,'PR','f','2'),(3706,230,'MaxPR','f','2'),(3707,230,'MaxSocket','f','1'),(3708,230,'MaxDur','f','3800'),(3709,230,'Dur','f','3040'),(3710,231,'UseLv','f','1'),(3711,231,'ItemGrade','f','1'),(3712,231,'SellPrice','f','72'),(3713,231,'BaseSocket','f','1'),(3714,231,'MaxSocket_COUNT','f','1'),(3715,231,'PR','f','4'),(3716,231,'MaxPR','f','4'),(3717,231,'MaxSocket','f','1'),(3718,231,'MaxDur','f','4000'),(3719,231,'Dur','f','3200'),(3901,232,'UseLv','f','1'),(3902,233,'UseLv','f','1'),(3903,233,'SellPrice','f','16'),(3904,234,'UseLv','f','1'),(3905,234,'SellPrice','f','24'),(3906,235,'UseLv','f','1'),(3907,236,'UseLv','f','1'),(3908,236,'SellPrice','f','6'),(3909,237,'UseLv','f','1'),(3910,237,'ItemGrade','f','1'),(3911,237,'SellPrice','f','72'),(3912,237,'BaseSocket','f','1'),(3913,237,'MaxSocket_COUNT','f','1'),(3914,237,'PR','f','3'),(3915,237,'MaxPR','f','3'),(3916,237,'MaxSocket','f','1'),(3917,237,'MaxDur','f','4200'),(3918,237,'Dur','f','4200'),(3919,238,'UseLv','f','1'),(3920,238,'ItemGrade','f','1'),(3921,238,'SellPrice','f','36'),(3922,238,'BaseSocket','f','1'),(3923,238,'MaxSocket_COUNT','f','1'),(3924,238,'PR','f','3'),(3925,238,'MaxPR','f','3'),(3926,238,'MaxSocket','f','1'),(3927,238,'MaxDur','f','4200'),(3928,238,'Dur','f','4200'),(3929,239,'UseLv','f','1'),(3930,239,'ItemGrade','f','1'),(3931,239,'SellPrice','f','36'),(3932,239,'BaseSocket','f','1'),(3933,239,'MaxSocket_COUNT','f','1'),(3934,239,'PR','f','3'),(3935,239,'MaxPR','f','3'),(3936,239,'MaxSocket','f','1'),(3937,239,'MaxDur','f','4200'),(3938,239,'Dur','f','4200'),(3939,240,'UseLv','f','1'),(3940,240,'ItemGrade','f','1'),(3941,240,'SellPrice','f','128'),(3942,240,'DEX','f','2'),(3943,240,'PR','f','3'),(3944,240,'MaxPR','f','3'),(3945,240,'MaxDur','f','1900'),(3946,240,'Dur','f','1900'),(3947,241,'UseLv','f','1'),(3948,241,'ItemGrade','f','1'),(3949,241,'SellPrice','f','72'),(3950,241,'BaseSocket','f','1'),(3951,241,'MaxSocket_COUNT','f','1'),(3952,241,'PR','f','3'),(3953,241,'MaxPR','f','3'),(3954,241,'MaxSocket','f','1'),(3955,241,'MaxDur','f','4200'),(3956,241,'Dur','f','4200'),(3957,242,'UseLv','f','1'),(3958,243,'UseLv','f','1'),(3959,243,'SellPrice','f','16'),(3960,244,'UseLv','f','1'),(3961,244,'SellPrice','f','24'),(3962,245,'UseLv','f','1'),(3963,246,'UseLv','f','1'),(3964,246,'SellPrice','f','6'),(3965,247,'UseLv','f','1'),(3966,247,'ItemGrade','f','1'),(3967,247,'SellPrice','f','72'),(3968,247,'BaseSocket','f','1'),(3969,247,'MaxSocket_COUNT','f','1'),(3970,247,'PR','f','4'),(3971,247,'MaxPR','f','4'),(3972,247,'MaxSocket','f','1'),(3973,247,'MaxDur','f','4000'),(3974,247,'Dur','f','4000'),(3975,248,'UseLv','f','1'),(3976,248,'ItemGrade','f','1'),(3977,248,'SellPrice','f','36'),(3978,248,'BaseSocket','f','1'),(3979,248,'MaxSocket_COUNT','f','1'),(3980,248,'PR','f','4'),(3981,248,'MaxPR','f','4'),(3982,248,'MaxSocket','f','1'),(3983,248,'MaxDur','f','4000'),(3984,248,'Dur','f','4000'),(3985,249,'UseLv','f','1'),(3986,249,'ItemGrade','f','1'),(3987,249,'SellPrice','f','36'),(3988,249,'BaseSocket','f','1'),(3989,249,'MaxSocket_COUNT','f','1'),(3990,249,'PR','f','4'),(3991,249,'MaxPR','f','4'),(3992,249,'MaxSocket','f','1'),(3993,249,'MaxDur','f','4000'),(3994,249,'Dur','f','4000'),(3995,250,'UseLv','f','1'),(3996,250,'ItemGrade','f','1'),(3997,250,'SellPrice','f','80'),(3998,250,'MNA','f','2'),(3999,250,'PR','f','3'),(4000,250,'MaxPR','f','3'),(4001,250,'MaxDur','f','1800'),(4002,250,'Dur','f','1800'),(4003,251,'UseLv','f','1'),(4004,251,'ItemGrade','f','1'),(4005,251,'SellPrice','f','48'),(4006,251,'MGP','f','100'),(4007,251,'BlockRate','f','1'),(4008,251,'BLK','f','4'),(4009,251,'BaseSocket','f','1'),(4010,251,'MaxSocket_COUNT','f','1'),(4011,251,'PR','f','2'),(4012,251,'MaxPR','f','2'),(4013,251,'MaxSocket','f','1'),(4014,251,'MaxDur','f','3800'),(4015,251,'Dur','f','3800'),(4016,252,'UseLv','f','1'),(4017,252,'ItemGrade','f','1'),(4018,252,'SellPrice','f','72'),(4019,252,'BaseSocket','f','1'),(4020,252,'MaxSocket_COUNT','f','1'),(4021,252,'PR','f','4'),(4022,252,'MaxPR','f','4'),(4023,252,'MaxSocket','f','1'),(4024,252,'MaxDur','f','4000'),(4025,252,'Dur','f','4000'),(4095,253,'UseLv','f','1'),(4096,253,'ItemGrade','f','1'),(4097,253,'SellPrice','f','72'),(4098,253,'BaseSocket','f','1'),(4099,253,'MaxSocket_COUNT','f','1'),(4100,253,'PR','f','3'),(4101,253,'MaxPR','f','3'),(4102,253,'MaxSocket','f','1'),(4103,253,'MaxDur','f','4200'),(4104,253,'Dur','f','4200'),(4105,254,'UseLv','f','1'),(4106,254,'ItemGrade','f','1'),(4107,254,'SellPrice','f','36'),(4108,254,'BaseSocket','f','1'),(4109,254,'MaxSocket_COUNT','f','1'),(4110,254,'PR','f','3'),(4111,254,'MaxPR','f','3'),(4112,254,'MaxSocket','f','1'),(4113,254,'MaxDur','f','4200'),(4114,254,'Dur','f','4200'),(4115,255,'UseLv','f','1'),(4116,255,'ItemGrade','f','1'),(4117,255,'SellPrice','f','36'),(4118,255,'BaseSocket','f','1'),(4119,255,'MaxSocket_COUNT','f','1'),(4120,255,'PR','f','3'),(4121,255,'MaxPR','f','3'),(4122,255,'MaxSocket','f','1'),(4123,255,'MaxDur','f','4200'),(4124,255,'Dur','f','4200'),(4125,256,'UseLv','f','1'),(4126,256,'ItemGrade','f','1'),(4127,256,'SellPrice','f','200'),(4128,256,'BaseSocket','f','1'),(4129,256,'MaxSocket_COUNT','f','1'),(4130,256,'PR','f','6'),(4131,256,'MaxPR','f','6'),(4132,256,'MaxSocket','f','1'),(4133,256,'MaxDur','f','3800'),(4134,256,'Dur','f','3800'),(4135,257,'UseLv','f','1'),(4136,257,'ItemGrade','f','1'),(4137,257,'SellPrice','f','80'),(4138,257,'Slash','f','3'),(4139,257,'PR','f','3'),(4140,257,'MaxPR','f','3'),(4141,257,'MaxDur','f','1800'),(4142,257,'Dur','f','1800'),(4143,258,'UseLv','f','1'),(4144,258,'ItemGrade','f','1'),(4145,258,'SellPrice','f','72'),(4146,258,'BaseSocket','f','1'),(4147,258,'MaxSocket_COUNT','f','1'),(4148,258,'PR','f','3'),(4149,258,'MaxPR','f','3'),(4150,258,'MaxSocket','f','1'),(4151,258,'MaxDur','f','4200'),(4152,258,'Dur','f','4200'),(4320,259,'UseLv','f','1'),(4321,259,'ItemGrade','f','5'),(4474,260,'UseLv','f','1'),(4475,260,'SellPrice','f','1'),(4476,261,'UseLv','f','1'),(4477,261,'ItemGrade','f','5'),(4555,262,'UseLv','f','1'),(4556,262,'SellPrice','f','20');
/*!40000 ALTER TABLE `item_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_properties_log`
--

DROP TABLE IF EXISTS `item_properties_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_properties_log` (
  `logId` bigint(20) NOT NULL AUTO_INCREMENT,
  `itemId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(1) NOT NULL,
  `value` mediumtext DEFAULT NULL,
  `backupTimestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `backupReason` varchar(50) DEFAULT 'pre_save',
  PRIMARY KEY (`logId`),
  KEY `idx_itemId_timestamp` (`itemId`,`backupTimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_properties_log`
--

LOCK TABLES `item_properties_log` WRITE;
/*!40000 ALTER TABLE `item_properties_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_properties_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `itemUniqueId` bigint(20) NOT NULL AUTO_INCREMENT,
  `itemId` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`itemUniqueId`)
) ENGINE=InnoDB AUTO_INCREMENT=265 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,645001,1,0),(2,301111,1,0),(3,640002,50,0),(4,640005,50,0),(5,640097,50,0),(6,645337,20,0),(13,640073,1,0),(28,645001,1,0),(29,640002,50,0),(30,640005,50,0),(31,640097,50,0),(32,640073,5,0),(33,645337,20,0),(34,531133,1,0),(35,501133,1,0),(36,511133,1,0),(37,141101,1,0),(38,221101,1,0),(39,521133,1,0),(40,645001,1,0),(41,640002,50,0),(42,640005,50,0),(43,640097,50,0),(44,645337,20,0),(45,531101,1,0),(46,501101,1,0),(47,511101,1,0),(48,161101,1,0),(49,521101,1,0),(50,645001,1,0),(51,640002,50,0),(52,640005,50,0),(53,640097,50,0),(54,645337,20,0),(55,531133,1,0),(56,501133,1,0),(57,511133,1,0),(58,201101,1,0),(59,221101,1,0),(60,521133,1,0),(67,645001,1,0),(68,101101,1,0),(69,511101,1,0),(70,501101,1,0),(71,521101,1,0),(72,221101,1,0),(73,531101,1,0),(74,640002,50,0),(75,640005,50,0),(76,640097,50,0),(77,645337,20,0),(89,645001,1,0),(90,301111,1,0),(91,640002,50,0),(92,640005,50,0),(93,640097,50,0),(94,645337,20,0),(95,531101,1,0),(96,501101,1,0),(97,511101,1,0),(98,111013,1,0),(99,101101,1,0),(100,521101,1,0),(101,645001,1,0),(102,640002,50,0),(103,640005,50,0),(104,640097,50,0),(105,645337,20,0),(106,531133,1,0),(107,501133,1,0),(108,511133,1,0),(109,141101,1,0),(110,221101,1,0),(111,521133,1,0),(112,645001,1,0),(113,640002,50,0),(114,640005,50,0),(115,640097,50,0),(116,645337,20,0),(117,531133,1,0),(118,501133,1,0),(119,511133,1,0),(120,141101,1,0),(121,221101,1,0),(122,521133,1,0),(123,645001,1,0),(124,640002,50,0),(125,640005,50,0),(126,640097,50,0),(127,645337,20,0),(128,531101,1,0),(129,501101,1,0),(130,511101,1,0),(131,161101,1,0),(132,521101,1,0),(133,645001,1,0),(134,640002,50,0),(135,640005,50,0),(136,640097,50,0),(137,645337,20,0),(138,531133,1,0),(139,501133,1,0),(140,511133,1,0),(141,141101,1,0),(142,221101,1,0),(143,521133,1,0),(144,645001,1,0),(145,640002,50,0),(146,640005,50,0),(147,640097,50,0),(148,645337,20,0),(149,531133,1,0),(150,501133,1,0),(151,511133,1,0),(152,201101,1,0),(153,221101,1,0),(154,521133,1,0),(155,645001,1,0),(156,640002,50,0),(157,640005,50,0),(158,640097,50,0),(159,645337,20,0),(160,531101,1,0),(161,501101,1,0),(162,511101,1,0),(163,101101,1,0),(164,221101,1,0),(165,521101,1,0),(166,645001,1,0),(167,640002,50,0),(168,640005,50,0),(169,640097,50,0),(170,645337,20,0),(171,531101,1,0),(172,501101,1,0),(173,511101,1,0),(174,161101,1,0),(175,521101,1,0),(176,645001,1,0),(177,640002,50,0),(178,640005,50,0),(179,640097,50,0),(180,645337,20,0),(181,531133,1,0),(182,501133,1,0),(183,511133,1,0),(184,201101,1,0),(185,221101,1,0),(186,521133,1,0),(187,645001,1,0),(188,640002,50,0),(189,640005,50,0),(190,640097,50,0),(191,645337,20,0),(192,531133,1,0),(193,501133,1,0),(194,511133,1,0),(195,201101,1,0),(196,221101,1,0),(197,521133,1,0),(198,645001,1,0),(199,640002,50,0),(200,640005,50,0),(201,640097,50,0),(202,645337,20,0),(203,531101,1,0),(204,501101,1,0),(205,511101,1,0),(206,101101,1,0),(207,221101,1,0),(208,521101,1,0),(209,645001,1,0),(210,301111,1,0),(211,640002,50,0),(212,640005,50,0),(213,640097,50,0),(214,645337,20,0),(215,531101,1,0),(216,501101,1,0),(217,511101,1,0),(218,111013,1,0),(219,101101,1,0),(220,521101,1,0),(221,645001,1,0),(222,640002,50,0),(223,640005,50,0),(224,640097,50,0),(225,645337,20,0),(226,531133,1,0),(227,501133,1,0),(228,511133,1,0),(229,141101,1,0),(230,221101,1,0),(231,521133,1,0),(232,645001,1,0),(233,640002,50,0),(234,640005,50,0),(235,640097,50,0),(236,645337,20,0),(237,531101,1,0),(238,501101,1,0),(239,511101,1,0),(240,161101,1,0),(241,521101,1,0),(242,645001,1,0),(243,640002,50,0),(244,640005,50,0),(245,640097,50,0),(246,645337,20,0),(247,531133,1,0),(248,501133,1,0),(249,511133,1,0),(250,141101,1,0),(251,221101,1,0),(252,521133,1,0),(253,531101,1,0),(254,501101,1,0),(255,511101,1,0),(256,111013,1,0),(257,101101,1,0),(258,521101,1,0),(259,11035678,1,0),(260,900011,1231345,0),(261,11205113,1,0),(262,721045,1,0),(263,11035125,1,0),(264,649720,10,0);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `characterId` bigint(20) NOT NULL,
  `jobId` int(11) NOT NULL,
  `circle` int(11) NOT NULL DEFAULT 1,
  `skillPoints` int(11) NOT NULL DEFAULT 0,
  `totalExp` bigint(20) NOT NULL DEFAULT 0,
  `selectionDate` datetime NOT NULL DEFAULT current_timestamp(),
  `advDate` date DEFAULT NULL,
  PRIMARY KEY (`characterId`,`jobId`),
  CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jobs_ibfk_2` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,5001,1,2,67,'2026-04-24 20:45:37','2026-04-24'),(3,2001,1,1,0,'2026-04-25 09:39:17','2026-04-25'),(4,3001,1,1,0,'2026-04-25 10:00:08','2026-04-25'),(5,4001,1,1,0,'2026-04-25 10:32:43','2026-04-25'),(6,1001,1,1,0,'2026-04-25 10:55:25','2026-04-25'),(8,5001,1,1,0,'2026-04-25 11:35:49','2026-04-25'),(9,2001,1,1,0,'2026-04-25 11:52:33','2026-04-25'),(10,2001,1,1,0,'2026-04-25 12:29:15','2026-04-25'),(11,3001,1,1,0,'2026-04-25 12:43:26','2026-04-25'),(12,2001,1,1,0,'2026-04-25 13:02:12','2026-04-25'),(13,4001,1,1,0,'2026-04-25 13:23:23','2026-04-25'),(14,1001,1,1,0,'2026-04-25 13:33:07','2026-04-25'),(15,3001,1,1,0,'2026-04-25 14:13:01','2026-04-25'),(16,4001,1,1,0,'2026-04-25 14:53:53','2026-04-25'),(17,4001,1,1,0,'2026-04-25 15:23:50','2026-04-25'),(18,1001,1,1,0,'2026-04-25 15:47:07','2026-04-25'),(19,5001,1,1,0,'2026-04-25 16:17:12','2026-04-25'),(20,2001,1,1,0,'2026-04-25 16:56:09','2026-04-25'),(21,3001,1,1,0,'2026-04-25 18:12:01','2026-04-25'),(22,2001,1,1,0,'2026-04-25 18:21:42','2026-04-25');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `likes` (
  `likeId` bigint(20) NOT NULL AUTO_INCREMENT,
  `receiverId` bigint(20) NOT NULL,
  `receiverName` varchar(128) NOT NULL,
  `senderId` bigint(20) NOT NULL,
  `senderName` varchar(128) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`likeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bot`
--

DROP TABLE IF EXISTS `log_bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_bot` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) unsigned NOT NULL,
  `characterName` varchar(50) NOT NULL,
  `activity` varchar(100) NOT NULL COMMENT 'e.g., Suspicious Movement, High-speed Looting',
  `details` text DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_characterId` (`characterId`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bot`
--

LOCK TABLES `log_bot` WRITE;
/*!40000 ALTER TABLE `log_bot` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_bot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_chat`
--

DROP TABLE IF EXISTS `log_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_chat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) unsigned NOT NULL,
  `characterName` varchar(50) NOT NULL,
  `chatType` int(11) NOT NULL COMMENT 'e.g., Normal, Whisper, Party, Guild',
  `message` text NOT NULL,
  `targetName` varchar(50) DEFAULT NULL COMMENT 'For whispers or private channels',
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_characterId` (`characterId`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_chat`
--

LOCK TABLES `log_chat` WRITE;
/*!40000 ALTER TABLE `log_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_item_transactions`
--

DROP TABLE IF EXISTS `log_item_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) unsigned NOT NULL,
  `characterName` varchar(50) NOT NULL,
  `itemObjectId` bigint(20) unsigned NOT NULL COMMENT 'In-memory unique ID of the item instance',
  `itemDbId` bigint(20) unsigned DEFAULT NULL COMMENT 'Database unique ID of the item instance',
  `itemId` int(10) unsigned NOT NULL COMMENT 'The class ID of the item',
  `itemName` varchar(100) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `transactionType` varchar(20) NOT NULL COMMENT 'e.g., Add, Remove',
  `reason` varchar(255) DEFAULT NULL COMMENT 'e.g., Pickup, Quest Reward, Used, Sold',
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_characterId` (`characterId`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_item_transactions`
--

LOCK TABLES `log_item_transactions` WRITE;
/*!40000 ALTER TABLE `log_item_transactions` DISABLE KEYS */;
INSERT INTO `log_item_transactions` VALUES (1,2,'Hiro',360287970189639829,0,663220,'Rose\'s Letter',1,'Add','PickUp','2026-04-25 05:49:33'),(2,2,'Hiro',360287970189639830,0,663221,'Anne\'s Letter',1,'Add','PickUp','2026-04-25 05:49:33'),(3,1,'Yuki',360287970189639731,0,602114,'Novice Bangle',1,'Add','New','2026-04-25 06:15:26'),(4,2,'Hiro',360287970189639827,0,101101,'Old Gladius',1,'Add','NotNew','2026-04-25 17:35:37'),(5,2,'Hiro',360287970189639828,0,221101,'Wooden Shield',1,'Add','NotNew','2026-04-25 17:35:37'),(6,2,'Hiro',360287970189639829,0,531101,'Light Armor',1,'Add','NotNew','2026-04-25 17:35:38'),(7,2,'Hiro',360287970189639830,0,521101,'Light Pants',1,'Add','NotNew','2026-04-25 17:35:38'),(8,2,'Hiro',360287970189639832,0,511101,'Light Boots',1,'Add','NotNew','2026-04-25 17:35:39'),(9,2,'Hiro',360287970189639831,0,501101,'Light Gloves',1,'Add','NotNew','2026-04-25 17:35:40'),(10,2,'Hiro',360287970189639827,0,101101,'Old Gladius',1,'Add','NotNew','2026-04-25 17:35:45'),(11,6,'Tux',360287970189639723,0,101101,'Old Gladius',1,'Add','NotNew','2026-04-25 17:58:17'),(12,6,'Tux',360287970189639724,0,221101,'Wooden Shield',1,'Add','NotNew','2026-04-25 17:58:18'),(13,6,'Tux',360287970189639725,0,531101,'Light Armor',1,'Add','NotNew','2026-04-25 17:58:18'),(14,6,'Tux',360287970189639726,0,521101,'Light Pants',1,'Add','NotNew','2026-04-25 17:58:19'),(15,6,'Tux',360287970189639727,0,501101,'Light Gloves',1,'Add','NotNew','2026-04-25 17:58:19'),(16,6,'Tux',360287970189639728,0,511101,'Light Boots',1,'Add','NotNew','2026-04-25 17:58:20'),(17,7,'Shunee',360287970189639771,0,141101,'Old Short Rod',1,'Add','NotNew','2026-04-25 18:15:11'),(18,7,'Shunee',360287970189639772,0,221101,'Wooden Shield',1,'Add','NotNew','2026-04-25 18:15:11'),(19,7,'Shunee',360287970189639773,0,531133,'Cotton Robe',1,'Add','NotNew','2026-04-25 18:15:12'),(20,7,'Shunee',360287970189639774,0,521133,'Cotton Pants',1,'Add','NotNew','2026-04-25 18:15:12'),(21,7,'Shunee',360287970189639775,0,501133,'Cotton Gloves',1,'Add','NotNew','2026-04-25 18:15:13'),(22,7,'Shunee',360287970189639776,0,511133,'Cotton Boots',1,'Add','NotNew','2026-04-25 18:15:14'),(23,20,'mula15',360287970189639815,230,221101,'Wooden Shield',1,'Add','NotNew','2026-04-25 23:58:20'),(24,20,'mula15',360287970189639816,229,141101,'Old Short Rod',1,'Add','NotNew','2026-04-25 23:58:21'),(25,20,'mula15',360287970189639819,226,531133,'Cotton Robe',1,'Add','NotNew','2026-04-25 23:58:21'),(26,20,'mula15',360287970189639820,231,521133,'Cotton Pants',1,'Add','NotNew','2026-04-25 23:58:21'),(27,20,'mula15',360287970189639818,227,501133,'Cotton Gloves',1,'Add','NotNew','2026-04-25 23:58:22'),(28,20,'mula15',360287970189639817,228,511133,'Cotton Boots',1,'Add','NotNew','2026-04-25 23:58:23'),(29,1,'Yuki',360287970189639732,0,11035125,'Panda Egg',1,'Add','PickUp','2026-04-26 02:20:41'),(30,1,'Yuki',360287970189639732,0,11035125,'Panda Egg',1,'Remove','Destroyed','2026-04-26 02:21:07'),(31,1,'Yuki',360287970189639734,0,11035125,'Panda Egg',1,'Add','PickUp','2026-04-26 02:25:42'),(32,1,'Yuki',360287970189639734,0,11035125,'Panda Egg',1,'Remove','Used','2026-04-26 02:25:48'),(33,1,'Yuki',360287970189639736,0,11035678,'Mount Voucher - TOS Davidson',1,'Add','PickUp','2026-04-26 02:26:30'),(34,1,'Yuki',360287970189639719,256,111013,'Training Kris Dagger',1,'Add','NotNew','2026-04-26 02:27:25'),(35,1,'Yuki',360287970189639790,0,11205113,'Mount Voucher - Falouros',1,'Add','PickUp','2026-04-26 02:29:49'),(36,1,'Yuki',360287970189639791,0,900011,'Silver',33,'Add','PickUp','2026-04-26 02:31:34'),(37,1,'Yuki',360287970189639786,13,640073,'Klaipeda Warp Scroll',1,'Remove','Used','2026-04-26 02:32:20'),(38,1,'Yuki',360287970189639846,0,11035193,'Rosy Floret Erhu Box',1,'Add','PickUp','2026-04-26 02:37:07'),(39,1,'Yuki',360287970189639847,0,721045,'Rosy Floret Erhu',1,'Add','New','2026-04-26 02:37:11'),(40,1,'Yuki',360287970189639846,0,11035193,'Rosy Floret Erhu Box',1,'Remove','Used','2026-04-26 02:37:11'),(41,1,'Yuki',360287970189639842,13,640073,'Klaipeda Warp Scroll',1,'Remove','Used','2026-04-26 02:37:23'),(42,1,'Yuki',360287970189639903,0,721045,'Rosy Floret Erhu',1,'Add','PickUp','2026-04-26 02:43:53'),(43,1,'Yuki',360287970189639736,0,11035125,'Panda Egg',1,'Add','PickUp','2026-04-26 02:52:47'),(44,1,'Yuki',360287970189639736,0,11035125,'Panda Egg',1,'Remove','Used','2026-04-26 02:52:55'),(45,1,'Yuki',360287970189639775,260,900011,'Silver',1231312,'Add','NotNew','2026-04-26 02:54:12'),(46,1,'Yuki',360287970189639843,13,640073,'Klaipeda Warp Scroll',1,'Remove','Used','2026-04-26 03:30:14'),(47,1,'Yuki',360287970189639897,13,640073,'Klaipeda Warp Scroll',1,'Remove','Used','2026-04-26 03:30:50');
/*!40000 ALTER TABLE `log_item_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `mailId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `sender` varchar(128) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `message` varchar(2048) DEFAULT NULL,
  `startDate` datetime DEFAULT '2016-04-01 00:00:00',
  `expirationDate` datetime DEFAULT '2038-01-01 00:00:00',
  `createdDate` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`mailId`),
  KEY `mail_ibfk_1` (`accountId`),
  CONSTRAINT `mail_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail`
--

LOCK TABLES `mail` WRITE;
/*!40000 ALTER TABLE `mail` DISABLE KEYS */;
INSERT INTO `mail` VALUES (1,1,0,'Gotei','teste','alouu','2026-04-25 19:55:30','2026-05-02 19:55:30','2026-04-25 19:55:30');
/*!40000 ALTER TABLE `mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_items`
--

DROP TABLE IF EXISTS `mail_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_items` (
  `mailItemId` bigint(20) NOT NULL AUTO_INCREMENT,
  `mailId` bigint(20) NOT NULL,
  `itemId` bigint(20) NOT NULL,
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`mailItemId`),
  KEY `mailId` (`mailId`),
  KEY `mail_items_ibfk_1` (`mailId`),
  CONSTRAINT `mail_items_ibfk_1` FOREIGN KEY (`mailId`) REFERENCES `mail` (`mailId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_items`
--

LOCK TABLES `mail_items` WRITE;
/*!40000 ALTER TABLE `mail_items` DISABLE KEYS */;
INSERT INTO `mail_items` VALUES (1,1,263,11035125,1,0),(2,1,264,649720,10,0);
/*!40000 ALTER TABLE `mail_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_items`
--

DROP TABLE IF EXISTS `market_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `market_items` (
  `marketitemUniqueId` bigint(20) NOT NULL AUTO_INCREMENT,
  `itemUniqueId` bigint(20) NOT NULL,
  `sellerId` bigint(20) NOT NULL,
  `buyerId` bigint(20) DEFAULT NULL,
  `price` bigint(20) NOT NULL,
  `dateRegistered` datetime DEFAULT current_timestamp(),
  `dateExpired` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`marketitemUniqueId`),
  KEY `market_items_ibfk_1` (`itemUniqueId`),
  KEY `market_items_ibfk_2` (`sellerId`),
  KEY `market_items_ibfk_3` (`buyerId`),
  CONSTRAINT `market_items_ibfk_1` FOREIGN KEY (`itemUniqueId`) REFERENCES `items` (`itemUniqueId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `market_items_ibfk_2` FOREIGN KEY (`sellerId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `market_items_ibfk_3` FOREIGN KEY (`buyerId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_items`
--

LOCK TABLES `market_items` WRITE;
/*!40000 ALTER TABLE `market_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `market_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_rollback_log`
--

DROP TABLE IF EXISTS `mass_rollback_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mass_rollback_log` (
  `massRollbackId` bigint(20) NOT NULL AUTO_INCREMENT,
  `bugDescription` text NOT NULL,
  `fromTime` datetime NOT NULL,
  `toTime` datetime NOT NULL,
  `totalAttempted` int(11) NOT NULL,
  `successfulCount` int(11) NOT NULL,
  `failedCount` int(11) NOT NULL,
  `executedAt` datetime NOT NULL,
  `resultDetails` longtext DEFAULT NULL,
  PRIMARY KEY (`massRollbackId`),
  KEY `idx_mass_rollback_executed` (`executedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_rollback_log`
--

LOCK TABLES `mass_rollback_log` WRITE;
/*!40000 ALTER TABLE `mass_rollback_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_rollback_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `partyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `leaderId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `note` varchar(64) NOT NULL,
  `dateCreated` datetime DEFAULT current_timestamp(),
  `questSharing` tinyint(1) DEFAULT 1,
  `expDistribution` tinyint(1) DEFAULT 1,
  `itemDistribution` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`partyId`),
  KEY `leaderId` (`leaderId`),
  KEY `party_ibfk_1` (`leaderId`),
  CONSTRAINT `party_ibfk_1` FOREIGN KEY (`leaderId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party`
--

LOCK TABLES `party` WRITE;
/*!40000 ALTER TABLE `party` DISABLE KEYS */;
/*!40000 ALTER TABLE `party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quests`
--

DROP TABLE IF EXISTS `quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quests` (
  `questId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `classId` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `startTime` datetime NOT NULL,
  `completeTime` datetime NOT NULL,
  `tracked` tinyint(1) NOT NULL,
  PRIMARY KEY (`questId`),
  UNIQUE KEY `uk_character_quest` (`characterId`,`classId`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `quests_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quests`
--

LOCK TABLES `quests` WRITE;
/*!40000 ALTER TABLE `quests` DISABLE KEYS */;
INSERT INTO `quests` VALUES (4,6,1001,100,'2026-04-25 11:12:28','0001-01-01 00:00:00',1),(8,8,1001,100,'2026-04-25 11:40:03','0001-01-01 00:00:00',1),(10,9,1001,300,'2026-04-25 11:52:41','0001-01-01 00:00:00',1),(12,10,1001,100,'2026-04-25 12:30:41','0001-01-01 00:00:00',1),(13,11,1001,300,'2026-04-25 12:43:32','0001-01-01 00:00:00',1),(14,12,1001,100,'2026-04-25 13:02:18','0001-01-01 00:00:00',1),(15,13,1001,300,'2026-04-25 13:23:30','0001-01-01 00:00:00',1),(16,13,1002,300,'2026-04-25 13:23:46','2026-04-25 13:23:46',1),(19,14,1001,300,'2026-04-25 13:33:14','0001-01-01 00:00:00',1),(20,14,1002,300,'2026-04-25 13:33:32','2026-04-25 13:33:32',1),(23,15,1001,300,'2026-04-25 14:13:06','0001-01-01 00:00:00',1),(24,15,1002,300,'2026-04-25 14:13:26','2026-04-25 14:13:26',1),(27,16,1001,300,'2026-04-25 14:53:59','0001-01-01 00:00:00',1),(28,16,1002,300,'2026-04-25 14:54:20','2026-04-25 14:54:20',1),(31,17,1001,300,'2026-04-25 15:24:00','0001-01-01 00:00:00',1),(32,17,1002,300,'2026-04-25 15:24:21','2026-04-25 15:24:21',1),(33,18,1001,300,'2026-04-25 15:47:14','0001-01-01 00:00:00',1),(34,18,1002,300,'2026-04-25 15:47:37','2026-04-25 15:47:37',1),(39,19,1001,100,'2026-04-25 16:55:50','0001-01-01 00:00:00',1),(42,20,1001,100,'2026-04-25 16:57:19','0001-01-01 00:00:00',1),(44,4,1001,100,'2026-04-25 17:01:31','0001-01-01 00:00:00',1),(45,21,1001,300,'2026-04-25 18:12:11','0001-01-01 00:00:00',1),(48,22,1001,300,'2026-04-25 18:21:52','0001-01-01 00:00:00',1),(49,22,1002,300,'2026-04-25 18:22:08','2026-04-25 18:22:08',1),(63,1,1001,100,'2026-04-25 20:30:52','0001-01-01 00:00:00',1);
/*!40000 ALTER TABLE `quests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quests_progress`
--

DROP TABLE IF EXISTS `quests_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quests_progress` (
  `questId` bigint(20) NOT NULL,
  `characterId` bigint(20) NOT NULL,
  `ident` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `count` int(11) NOT NULL,
  `done` tinyint(1) NOT NULL,
  `unlocked` tinyint(1) NOT NULL,
  PRIMARY KEY (`questId`,`ident`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `quests_progress_ibfk_1` FOREIGN KEY (`questId`) REFERENCES `quests` (`questId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quests_progress`
--

LOCK TABLES `quests_progress` WRITE;
/*!40000 ALTER TABLE `quests_progress` DISABLE KEYS */;
INSERT INTO `quests_progress` VALUES (4,6,'manual',0,0,1),(8,8,'manual',0,0,1),(10,9,'manual',0,0,1),(12,10,'manual',0,0,1),(13,11,'manual',0,0,1),(14,12,'manual',0,0,1),(15,13,'manual',0,0,1),(16,13,'manual',1,1,1),(19,14,'manual',0,0,1),(20,14,'manual',1,1,1),(23,15,'manual',0,0,1),(24,15,'manual',1,1,1),(27,16,'manual',0,0,1),(28,16,'manual',1,1,1),(31,17,'manual',0,0,1),(32,17,'manual',1,1,1),(33,18,'manual',0,0,1),(34,18,'manual',1,1,1),(39,19,'manual',0,0,1),(42,20,'manual',0,0,1),(44,4,'manual',0,0,1),(45,21,'manual',0,0,1),(48,22,'manual',0,0,1),(49,22,'manual',1,1,1),(63,1,'manual',0,0,1);
/*!40000 ALTER TABLE `quests_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revealedmaps`
--

DROP TABLE IF EXISTS `revealedmaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revealedmaps` (
  `revealedMapId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `map` int(11) NOT NULL,
  `explored` varbinary(128) NOT NULL,
  `percentage` float(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`revealedMapId`),
  UNIQUE KEY `UQ_revealedMaps_map` (`accountId`,`map`),
  CONSTRAINT `FK_revealedMaps_accountId` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE,
  CONSTRAINT `revealedmaps_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revealedmaps`
--

LOCK TABLES `revealedmaps` WRITE;
/*!40000 ALTER TABLE `revealedmaps` DISABLE KEYS */;
INSERT INTO `revealedmaps` VALUES (67,1,1021,'��~����\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',47.67);
/*!40000 ALTER TABLE `revealedmaps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rollback_log`
--

DROP TABLE IF EXISTS `rollback_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rollback_log` (
  `logId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `snapshotId` bigint(20) NOT NULL,
  `rollbackReason` varchar(500) NOT NULL,
  `rolledBackAt` datetime NOT NULL,
  `originalSnapshotReason` varchar(255) NOT NULL,
  `originalSnapshotDate` datetime NOT NULL,
  PRIMARY KEY (`logId`),
  KEY `idx_rollback_log_character` (`characterId`),
  KEY `idx_rollback_log_snapshot` (`snapshotId`),
  KEY `idx_rollback_log_date` (`rolledBackAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rollback_log`
--

LOCK TABLES `rollback_log` WRITE;
/*!40000 ALTER TABLE `rollback_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `rollback_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_objects_properties`
--

DROP TABLE IF EXISTS `session_objects_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_objects_properties` (
  `sessionObjectPropertyId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `sessionObjectId` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(1) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`sessionObjectPropertyId`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `session_object_properties_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `session_objects_properties_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_objects_properties`
--

LOCK TABLES `session_objects_properties` WRITE;
/*!40000 ALTER TABLE `session_objects_properties` DISABLE KEYS */;
INSERT INTO `session_objects_properties` VALUES (51,3,90000,'QSTARTZONETYPE','s','StartLine1'),(52,3,90000,'WARP_C_KLAIPE','f','300'),(59,5,90000,'QSTARTZONETYPE','s','StartLine1'),(64,6,90000,'QSTARTZONETYPE','s','StartLine1'),(65,6,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(72,8,90000,'QSTARTZONETYPE','s','StartLine1'),(73,8,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(76,9,90000,'QSTARTZONETYPE','s','StartLine1'),(77,9,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(80,10,90000,'QSTARTZONETYPE','s','StartLine1'),(81,10,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(82,11,90000,'QSTARTZONETYPE','s','StartLine1'),(83,11,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(84,12,90000,'QSTARTZONETYPE','s','StartLine1'),(85,12,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(86,13,90000,'QSTARTZONETYPE','s','StartLine1'),(87,13,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(88,13,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(92,14,90000,'QSTARTZONETYPE','s','StartLine1'),(93,14,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(94,14,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(98,15,90000,'QSTARTZONETYPE','s','StartLine1'),(99,15,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(100,15,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(105,16,90000,'QSTARTZONETYPE','s','StartLine1'),(106,16,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(107,16,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(108,16,90000,'WARP_F_SIAULIAI_WEST','f','300'),(113,17,90000,'QSTARTZONETYPE','s','StartLine1'),(114,17,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(115,17,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(116,17,90000,'WARP_F_SIAULIAI_WEST','f','300'),(117,18,90000,'QSTARTZONETYPE','s','StartLine1'),(118,18,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(119,18,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(120,18,90000,'WARP_F_SIAULIAI_WEST','f','300'),(127,19,90000,'QSTARTZONETYPE','s','StartLine1'),(128,19,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(129,19,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(133,20,90000,'QSTARTZONETYPE','s','StartLine1'),(134,20,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(135,20,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(139,4,90000,'QSTARTZONETYPE','s','StartLine1'),(140,4,90000,'WARP_F_SIAULIAI_WEST','f','300'),(141,4,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(142,21,90000,'QSTARTZONETYPE','s','StartLine1'),(143,21,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(148,22,90000,'QSTARTZONETYPE','s','StartLine1'),(149,22,90000,'SIAUL_WEST_MEET_TITAS','f','300'),(150,22,90000,'SIAUL_WEST_WEST_FOREST','f','300'),(151,22,90000,'WARP_F_SIAULIAI_WEST','f','300'),(207,1,90000,'QSTARTZONETYPE','s','StartLine1'),(208,1,90000,'WARP_C_KLAIPE','f','300'),(209,1,90000,'WARP_F_SIAULIAI_WEST','f','300'),(210,1,90000,'SIAUL_WEST_MEET_TITAS','f','100'),(211,1,90000,'SIAUL_WEST_WEST_FOREST','f','300');
/*!40000 ALTER TABLE `session_objects_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skills` (
  `skillId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`skillId`),
  UNIQUE KEY `uk_character_skill` (`characterId`,`id`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `skills_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `skills_ibfk_2` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3499 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skills`
--

LOCK TABLES `skills` WRITE;
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
INSERT INTO `skills` VALUES (1,1,100,1),(2,1,103,1),(3,1,108,1),(4,1,105,1),(5,1,101,1),(6,1,106,1),(7,1,110,1),(8,1,1,1),(9,1,5,1),(10,1,1535,1),(11,1,11,1),(12,1,10,1),(13,1,59,1),(14,1,53,1),(15,1,20,1),(16,1,2,1),(17,1,4,1),(18,1,6,1),(19,1,7,1),(20,1,13,1),(21,1,52,1),(22,1,55,1),(23,1,56,1),(24,1,57,1),(25,1,58,1),(26,1,63,1),(27,1,68,1),(28,1,70,1),(29,1,71,1),(30,1,72,1),(31,1,1506,1),(32,1,1507,1),(33,1,1508,1),(34,1,1509,1),(35,1,1510,1),(36,1,1511,1),(37,1,1512,1),(38,1,1514,1),(39,1,1515,1),(40,1,1516,1),(41,1,1517,1),(42,1,1518,1),(43,1,1519,1),(44,1,1520,1),(45,1,1525,1),(46,1,2118,1),(47,1,2119,1),(48,1,66,1),(49,1,73,1),(50,1,76,1),(945,3,100,1),(946,3,103,1),(947,3,108,1),(948,3,105,1),(949,3,101,1),(950,3,106,1),(951,3,110,1),(952,3,4,1),(953,3,6,1),(954,3,20,1),(955,3,54,1),(956,3,1,1),(957,3,2,1),(958,3,5,1),(959,3,7,1),(960,3,13,1),(961,3,52,1),(962,3,53,1),(963,3,55,1),(964,3,56,1),(965,3,57,1),(966,3,58,1),(967,3,63,1),(968,3,68,1),(969,3,70,1),(970,3,71,1),(971,3,72,1),(972,3,1506,1),(973,3,1507,1),(974,3,1508,1),(975,3,1509,1),(976,3,1510,1),(977,3,1511,1),(978,3,1512,1),(979,3,1514,1),(980,3,1515,1),(981,3,1516,1),(982,3,1517,1),(983,3,1518,1),(984,3,1519,1),(985,3,1520,1),(986,3,1525,1),(987,3,2118,1),(988,3,2119,1),(989,3,66,1),(990,3,73,1),(991,3,76,1),(1086,4,100,1),(1087,4,103,1),(1088,4,108,1),(1089,4,105,1),(1090,4,101,1),(1091,4,106,1),(1092,4,110,1),(1093,4,2,1),(1094,4,52,1),(1095,4,20,1),(1096,4,1535,1),(1097,4,53,1),(1098,4,55,1),(1099,4,56,1),(1100,4,70,1),(1101,4,1,1),(1102,4,4,1),(1103,4,5,1),(1104,4,6,1),(1105,4,7,1),(1106,4,13,1),(1107,4,57,1),(1108,4,58,1),(1109,4,63,1),(1110,4,68,1),(1111,4,71,1),(1112,4,72,1),(1113,4,1506,1),(1114,4,1507,1),(1115,4,1508,1),(1116,4,1509,1),(1117,4,1510,1),(1118,4,1511,1),(1119,4,1512,1),(1120,4,1514,1),(1121,4,1515,1),(1122,4,1516,1),(1123,4,1517,1),(1124,4,1518,1),(1125,4,1519,1),(1126,4,1520,1),(1127,4,1525,1),(1128,4,2118,1),(1129,4,2119,1),(1130,4,66,1),(1131,4,73,1),(1132,4,76,1),(1227,5,100,1),(1228,5,103,1),(1229,5,108,1),(1230,5,105,1),(1231,5,101,1),(1232,5,106,1),(1233,5,110,1),(1234,5,3,1),(1235,5,72,1),(1236,5,20,1),(1237,5,1535,1),(1238,5,1,1),(1239,5,2,1),(1240,5,4,1),(1241,5,5,1),(1242,5,6,1),(1243,5,7,1),(1244,5,13,1),(1245,5,52,1),(1246,5,53,1),(1247,5,55,1),(1248,5,56,1),(1249,5,57,1),(1250,5,58,1),(1251,5,63,1),(1252,5,68,1),(1253,5,70,1),(1254,5,71,1),(1255,5,1506,1),(1256,5,1507,1),(1257,5,1508,1),(1258,5,1509,1),(1259,5,1510,1),(1260,5,1511,1),(1261,5,1512,1),(1262,5,1514,1),(1263,5,1515,1),(1264,5,1516,1),(1265,5,1517,1),(1266,5,1518,1),(1267,5,1519,1),(1268,5,1520,1),(1269,5,1525,1),(1270,5,2118,1),(1271,5,2119,1),(1272,5,66,1),(1273,5,73,1),(1274,5,76,1),(1322,6,100,1),(1323,6,103,1),(1324,6,108,1),(1325,6,105,1),(1326,6,101,1),(1327,6,106,1),(1328,6,110,1),(1329,6,1,1),(1330,6,5,1),(1331,6,1535,1),(1332,6,53,1),(1333,6,20,1),(1334,6,2,1),(1335,6,4,1),(1336,6,6,1),(1337,6,7,1),(1338,6,13,1),(1339,6,52,1),(1340,6,55,1),(1341,6,56,1),(1342,6,57,1),(1343,6,58,1),(1344,6,63,1),(1345,6,68,1),(1346,6,70,1),(1347,6,71,1),(1348,6,72,1),(1349,6,1506,1),(1350,6,1507,1),(1351,6,1508,1),(1352,6,1509,1),(1353,6,1510,1),(1354,6,1511,1),(1355,6,1512,1),(1356,6,1514,1),(1357,6,1515,1),(1358,6,1516,1),(1359,6,1517,1),(1360,6,1518,1),(1361,6,1519,1),(1362,6,1520,1),(1363,6,1525,1),(1364,6,2118,1),(1365,6,2119,1),(1366,6,66,1),(1367,6,73,1),(1368,6,76,1),(1463,8,100,1),(1464,8,103,1),(1465,8,108,1),(1466,8,105,1),(1467,8,101,1),(1468,8,106,1),(1469,8,110,1),(1470,8,1,1),(1471,8,5,1),(1472,8,1535,1),(1473,8,11,1),(1474,8,10,1),(1475,8,59,1),(1476,8,53,1),(1477,8,20,1),(1478,8,2,1),(1479,8,4,1),(1480,8,6,1),(1481,8,7,1),(1482,8,13,1),(1483,8,52,1),(1484,8,55,1),(1485,8,56,1),(1486,8,57,1),(1487,8,58,1),(1488,8,63,1),(1489,8,68,1),(1490,8,70,1),(1491,8,71,1),(1492,8,72,1),(1493,8,1506,1),(1494,8,1507,1),(1495,8,1508,1),(1496,8,1509,1),(1497,8,1510,1),(1498,8,1511,1),(1499,8,1512,1),(1500,8,1514,1),(1501,8,1515,1),(1502,8,1516,1),(1503,8,1517,1),(1504,8,1518,1),(1505,8,1519,1),(1506,8,1520,1),(1507,8,1525,1),(1508,8,2118,1),(1509,8,2119,1),(1510,8,66,1),(1511,8,73,1),(1512,8,76,1),(1613,9,100,1),(1614,9,103,1),(1615,9,108,1),(1616,9,105,1),(1617,9,101,1),(1618,9,106,1),(1619,9,110,1),(1620,9,4,1),(1621,9,6,1),(1622,9,20,1),(1623,9,54,1),(1624,9,1,1),(1625,9,2,1),(1626,9,5,1),(1627,9,7,1),(1628,9,13,1),(1629,9,52,1),(1630,9,53,1),(1631,9,55,1),(1632,9,56,1),(1633,9,57,1),(1634,9,58,1),(1635,9,63,1),(1636,9,68,1),(1637,9,70,1),(1638,9,71,1),(1639,9,72,1),(1640,9,1506,1),(1641,9,1507,1),(1642,9,1508,1),(1643,9,1509,1),(1644,9,1510,1),(1645,9,1511,1),(1646,9,1512,1),(1647,9,1514,1),(1648,9,1515,1),(1649,9,1516,1),(1650,9,1517,1),(1651,9,1518,1),(1652,9,1519,1),(1653,9,1520,1),(1654,9,1525,1),(1655,9,2118,1),(1656,9,2119,1),(1657,9,66,1),(1658,9,73,1),(1659,9,76,1),(1707,10,100,1),(1708,10,103,1),(1709,10,108,1),(1710,10,105,1),(1711,10,101,1),(1712,10,106,1),(1713,10,110,1),(1714,10,4,1),(1715,10,6,1),(1716,10,20,1),(1717,10,54,1),(1718,10,1,1),(1719,10,2,1),(1720,10,5,1),(1721,10,7,1),(1722,10,13,1),(1723,10,52,1),(1724,10,53,1),(1725,10,55,1),(1726,10,56,1),(1727,10,57,1),(1728,10,58,1),(1729,10,63,1),(1730,10,68,1),(1731,10,70,1),(1732,10,71,1),(1733,10,72,1),(1734,10,1506,1),(1735,10,1507,1),(1736,10,1508,1),(1737,10,1509,1),(1738,10,1510,1),(1739,10,1511,1),(1740,10,1512,1),(1741,10,1514,1),(1742,10,1515,1),(1743,10,1516,1),(1744,10,1517,1),(1745,10,1518,1),(1746,10,1519,1),(1747,10,1520,1),(1748,10,1525,1),(1749,10,2118,1),(1750,10,2119,1),(1751,10,66,1),(1752,10,73,1),(1753,10,76,1),(1801,11,100,1),(1802,11,103,1),(1803,11,108,1),(1804,11,105,1),(1805,11,101,1),(1806,11,106,1),(1807,11,110,1),(1808,11,2,1),(1809,11,52,1),(1810,11,20,1),(1811,11,1535,1),(1812,11,53,1),(1813,11,55,1),(1814,11,56,1),(1815,11,70,1),(1816,11,1,1),(1817,11,4,1),(1818,11,5,1),(1819,11,6,1),(1820,11,7,1),(1821,11,13,1),(1822,11,57,1),(1823,11,58,1),(1824,11,63,1),(1825,11,68,1),(1826,11,71,1),(1827,11,72,1),(1828,11,1506,1),(1829,11,1507,1),(1830,11,1508,1),(1831,11,1509,1),(1832,11,1510,1),(1833,11,1511,1),(1834,11,1512,1),(1835,11,1514,1),(1836,11,1515,1),(1837,11,1516,1),(1838,11,1517,1),(1839,11,1518,1),(1840,11,1519,1),(1841,11,1520,1),(1842,11,1525,1),(1843,11,2118,1),(1844,11,2119,1),(1845,11,66,1),(1846,11,73,1),(1847,11,76,1),(1848,12,100,1),(1849,12,103,1),(1850,12,108,1),(1851,12,105,1),(1852,12,101,1),(1853,12,106,1),(1854,12,110,1),(1855,12,4,1),(1856,12,6,1),(1857,12,20,1),(1858,12,54,1),(1859,12,1,1),(1860,12,2,1),(1861,12,5,1),(1862,12,7,1),(1863,12,13,1),(1864,12,52,1),(1865,12,53,1),(1866,12,55,1),(1867,12,56,1),(1868,12,57,1),(1869,12,58,1),(1870,12,63,1),(1871,12,68,1),(1872,12,70,1),(1873,12,71,1),(1874,12,72,1),(1875,12,1506,1),(1876,12,1507,1),(1877,12,1508,1),(1878,12,1509,1),(1879,12,1510,1),(1880,12,1511,1),(1881,12,1512,1),(1882,12,1514,1),(1883,12,1515,1),(1884,12,1516,1),(1885,12,1517,1),(1886,12,1518,1),(1887,12,1519,1),(1888,12,1520,1),(1889,12,1525,1),(1890,12,2118,1),(1891,12,2119,1),(1892,12,66,1),(1893,12,73,1),(1894,12,76,1),(1895,13,100,1),(1896,13,103,1),(1897,13,108,1),(1898,13,105,1),(1899,13,101,1),(1900,13,106,1),(1901,13,110,1),(1902,13,3,1),(1903,13,72,1),(1904,13,20,1),(1905,13,1535,1),(1906,13,1,1),(1907,13,2,1),(1908,13,4,1),(1909,13,5,1),(1910,13,6,1),(1911,13,7,1),(1912,13,13,1),(1913,13,52,1),(1914,13,53,1),(1915,13,55,1),(1916,13,56,1),(1917,13,57,1),(1918,13,58,1),(1919,13,63,1),(1920,13,68,1),(1921,13,70,1),(1922,13,71,1),(1923,13,1506,1),(1924,13,1507,1),(1925,13,1508,1),(1926,13,1509,1),(1927,13,1510,1),(1928,13,1511,1),(1929,13,1512,1),(1930,13,1514,1),(1931,13,1515,1),(1932,13,1516,1),(1933,13,1517,1),(1934,13,1518,1),(1935,13,1519,1),(1936,13,1520,1),(1937,13,1525,1),(1938,13,2118,1),(1939,13,2119,1),(1940,13,66,1),(1941,13,73,1),(1942,13,76,1),(1943,14,100,1),(1944,14,103,1),(1945,14,108,1),(1946,14,105,1),(1947,14,101,1),(1948,14,106,1),(1949,14,110,1),(1950,14,1,1),(1951,14,5,1),(1952,14,1535,1),(1953,14,53,1),(1954,14,20,1),(1955,14,2,1),(1956,14,4,1),(1957,14,6,1),(1958,14,7,1),(1959,14,13,1),(1960,14,52,1),(1961,14,55,1),(1962,14,56,1),(1963,14,57,1),(1964,14,58,1),(1965,14,63,1),(1966,14,68,1),(1967,14,70,1),(1968,14,71,1),(1969,14,72,1),(1970,14,1506,1),(1971,14,1507,1),(1972,14,1508,1),(1973,14,1509,1),(1974,14,1510,1),(1975,14,1511,1),(1976,14,1512,1),(1977,14,1514,1),(1978,14,1515,1),(1979,14,1516,1),(1980,14,1517,1),(1981,14,1518,1),(1982,14,1519,1),(1983,14,1520,1),(1984,14,1525,1),(1985,14,2118,1),(1986,14,2119,1),(1987,14,66,1),(1988,14,73,1),(1989,14,76,1),(2037,15,100,1),(2038,15,103,1),(2039,15,108,1),(2040,15,105,1),(2041,15,101,1),(2042,15,106,1),(2043,15,110,1),(2044,15,2,1),(2045,15,52,1),(2046,15,20,1),(2047,15,1535,1),(2048,15,53,1),(2049,15,55,1),(2050,15,56,1),(2051,15,70,1),(2052,15,1,1),(2053,15,4,1),(2054,15,5,1),(2055,15,6,1),(2056,15,7,1),(2057,15,13,1),(2058,15,57,1),(2059,15,58,1),(2060,15,63,1),(2061,15,68,1),(2062,15,71,1),(2063,15,72,1),(2064,15,1506,1),(2065,15,1507,1),(2066,15,1508,1),(2067,15,1509,1),(2068,15,1510,1),(2069,15,1511,1),(2070,15,1512,1),(2071,15,1514,1),(2072,15,1515,1),(2073,15,1516,1),(2074,15,1517,1),(2075,15,1518,1),(2076,15,1519,1),(2077,15,1520,1),(2078,15,1525,1),(2079,15,2118,1),(2080,15,2119,1),(2081,15,66,1),(2082,15,73,1),(2083,15,76,1),(2131,16,100,1),(2132,16,103,1),(2133,16,108,1),(2134,16,105,1),(2135,16,101,1),(2136,16,106,1),(2137,16,110,1),(2138,16,3,1),(2139,16,72,1),(2140,16,20,1),(2141,16,1535,1),(2142,16,1,1),(2143,16,2,1),(2144,16,4,1),(2145,16,5,1),(2146,16,6,1),(2147,16,7,1),(2148,16,13,1),(2149,16,52,1),(2150,16,53,1),(2151,16,55,1),(2152,16,56,1),(2153,16,57,1),(2154,16,58,1),(2155,16,63,1),(2156,16,68,1),(2157,16,70,1),(2158,16,71,1),(2159,16,1506,1),(2160,16,1507,1),(2161,16,1508,1),(2162,16,1509,1),(2163,16,1510,1),(2164,16,1511,1),(2165,16,1512,1),(2166,16,1514,1),(2167,16,1515,1),(2168,16,1516,1),(2169,16,1517,1),(2170,16,1518,1),(2171,16,1519,1),(2172,16,1520,1),(2173,16,1525,1),(2174,16,2118,1),(2175,16,2119,1),(2176,16,66,1),(2177,16,73,1),(2178,16,76,1),(2227,17,100,1),(2228,17,103,1),(2229,17,108,1),(2230,17,105,1),(2231,17,101,1),(2232,17,106,1),(2233,17,110,1),(2234,17,3,1),(2235,17,72,1),(2236,17,20,1),(2237,17,1535,1),(2238,17,1,1),(2239,17,2,1),(2240,17,4,1),(2241,17,5,1),(2242,17,6,1),(2243,17,7,1),(2244,17,13,1),(2245,17,52,1),(2246,17,53,1),(2247,17,55,1),(2248,17,56,1),(2249,17,57,1),(2250,17,58,1),(2251,17,63,1),(2252,17,68,1),(2253,17,70,1),(2254,17,71,1),(2255,17,1506,1),(2256,17,1507,1),(2257,17,1508,1),(2258,17,1509,1),(2259,17,1510,1),(2260,17,1511,1),(2261,17,1512,1),(2262,17,1514,1),(2263,17,1515,1),(2264,17,1516,1),(2265,17,1517,1),(2266,17,1518,1),(2267,17,1519,1),(2268,17,1520,1),(2269,17,1525,1),(2270,17,2118,1),(2271,17,2119,1),(2272,17,66,1),(2273,17,73,1),(2274,17,76,1),(2323,18,100,1),(2324,18,103,1),(2325,18,108,1),(2326,18,105,1),(2327,18,101,1),(2328,18,106,1),(2329,18,110,1),(2330,18,1,1),(2331,18,5,1),(2332,18,1535,1),(2333,18,53,1),(2334,18,20,1),(2335,18,2,1),(2336,18,4,1),(2337,18,6,1),(2338,18,7,1),(2339,18,13,1),(2340,18,52,1),(2341,18,55,1),(2342,18,56,1),(2343,18,57,1),(2344,18,58,1),(2345,18,63,1),(2346,18,68,1),(2347,18,70,1),(2348,18,71,1),(2349,18,72,1),(2350,18,1506,1),(2351,18,1507,1),(2352,18,1508,1),(2353,18,1509,1),(2354,18,1510,1),(2355,18,1511,1),(2356,18,1512,1),(2357,18,1514,1),(2358,18,1515,1),(2359,18,1516,1),(2360,18,1517,1),(2361,18,1518,1),(2362,18,1519,1),(2363,18,1520,1),(2364,18,1525,1),(2365,18,2118,1),(2366,18,2119,1),(2367,18,66,1),(2368,18,73,1),(2369,18,76,1),(2370,19,100,1),(2371,19,103,1),(2372,19,108,1),(2373,19,105,1),(2374,19,101,1),(2375,19,106,1),(2376,19,110,1),(2377,19,1,1),(2378,19,5,1),(2379,19,1535,1),(2380,19,11,1),(2381,19,10,1),(2382,19,59,1),(2383,19,53,1),(2384,19,20,1),(2385,19,2,1),(2386,19,4,1),(2387,19,6,1),(2388,19,7,1),(2389,19,13,1),(2390,19,52,1),(2391,19,55,1),(2392,19,56,1),(2393,19,57,1),(2394,19,58,1),(2395,19,63,1),(2396,19,68,1),(2397,19,70,1),(2398,19,71,1),(2399,19,72,1),(2400,19,1506,1),(2401,19,1507,1),(2402,19,1508,1),(2403,19,1509,1),(2404,19,1510,1),(2405,19,1511,1),(2406,19,1512,1),(2407,19,1514,1),(2408,19,1515,1),(2409,19,1516,1),(2410,19,1517,1),(2411,19,1518,1),(2412,19,1519,1),(2413,19,1520,1),(2414,19,1525,1),(2415,19,2118,1),(2416,19,2119,1),(2417,19,66,1),(2418,19,73,1),(2419,19,76,1),(2520,20,100,1),(2521,20,103,1),(2522,20,108,1),(2523,20,105,1),(2524,20,101,1),(2525,20,106,1),(2526,20,110,1),(2527,20,4,1),(2528,20,6,1),(2529,20,20,1),(2530,20,54,1),(2531,20,1,1),(2532,20,2,1),(2533,20,5,1),(2534,20,7,1),(2535,20,13,1),(2536,20,52,1),(2537,20,53,1),(2538,20,55,1),(2539,20,56,1),(2540,20,57,1),(2541,20,58,1),(2542,20,63,1),(2543,20,68,1),(2544,20,70,1),(2545,20,71,1),(2546,20,72,1),(2547,20,1506,1),(2548,20,1507,1),(2549,20,1508,1),(2550,20,1509,1),(2551,20,1510,1),(2552,20,1511,1),(2553,20,1512,1),(2554,20,1514,1),(2555,20,1515,1),(2556,20,1516,1),(2557,20,1517,1),(2558,20,1518,1),(2559,20,1519,1),(2560,20,1520,1),(2561,20,1525,1),(2562,20,2118,1),(2563,20,2119,1),(2564,20,66,1),(2565,20,73,1),(2566,20,76,1),(2708,21,100,1),(2709,21,103,1),(2710,21,108,1),(2711,21,105,1),(2712,21,101,1),(2713,21,106,1),(2714,21,110,1),(2715,21,2,1),(2716,21,52,1),(2717,21,20,1),(2718,21,1535,1),(2719,21,53,1),(2720,21,55,1),(2721,21,56,1),(2722,21,70,1),(2723,21,1,1),(2724,21,4,1),(2725,21,5,1),(2726,21,6,1),(2727,21,7,1),(2728,21,13,1),(2729,21,57,1),(2730,21,58,1),(2731,21,63,1),(2732,21,68,1),(2733,21,71,1),(2734,21,72,1),(2735,21,1506,1),(2736,21,1507,1),(2737,21,1508,1),(2738,21,1509,1),(2739,21,1510,1),(2740,21,1511,1),(2741,21,1512,1),(2742,21,1514,1),(2743,21,1515,1),(2744,21,1516,1),(2745,21,1517,1),(2746,21,1518,1),(2747,21,1519,1),(2748,21,1520,1),(2749,21,1525,1),(2750,21,2118,1),(2751,21,2119,1),(2752,21,66,1),(2753,21,73,1),(2754,21,76,1),(2755,22,100,1),(2756,22,103,1),(2757,22,108,1),(2758,22,105,1),(2759,22,101,1),(2760,22,106,1),(2761,22,110,1),(2762,22,4,1),(2763,22,6,1),(2764,22,20,1),(2765,22,54,1),(2766,22,1,1),(2767,22,2,1),(2768,22,5,1),(2769,22,7,1),(2770,22,13,1),(2771,22,52,1),(2772,22,53,1),(2773,22,55,1),(2774,22,56,1),(2775,22,57,1),(2776,22,58,1),(2777,22,63,1),(2778,22,68,1),(2779,22,70,1),(2780,22,71,1),(2781,22,72,1),(2782,22,1506,1),(2783,22,1507,1),(2784,22,1508,1),(2785,22,1509,1),(2786,22,1510,1),(2787,22,1511,1),(2788,22,1512,1),(2789,22,1514,1),(2790,22,1515,1),(2791,22,1516,1),(2792,22,1517,1),(2793,22,1518,1),(2794,22,1519,1),(2795,22,1520,1),(2796,22,1525,1),(2797,22,2118,1),(2798,22,2119,1),(2799,22,66,1),(2800,22,73,1),(2801,22,76,1);
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_abilities`
--

DROP TABLE IF EXISTS `snapshot_abilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_abilities` (
  `snapshotId` bigint(20) NOT NULL,
  `abilityId` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`snapshotId`,`abilityId`),
  CONSTRAINT `snapshot_abilities_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_abilities`
--

LOCK TABLES `snapshot_abilities` WRITE;
/*!40000 ALTER TABLE `snapshot_abilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_abilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_character_data`
--

DROP TABLE IF EXISTS `snapshot_character_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_character_data` (
  `snapshotId` bigint(20) NOT NULL,
  `characterId` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `teamName` varchar(64) NOT NULL,
  `jobId` smallint(6) NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `hair` int(11) NOT NULL,
  `skinColor` int(10) unsigned NOT NULL,
  `mapId` int(11) NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `z` float NOT NULL,
  `dir` float NOT NULL,
  `exp` bigint(20) NOT NULL,
  `maxExp` bigint(20) NOT NULL,
  `totalExp` bigint(20) NOT NULL,
  `equipVisibility` int(11) NOT NULL,
  `equippedTitleId` int(11) NOT NULL DEFAULT -1,
  `stamina` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`snapshotId`),
  CONSTRAINT `snapshot_character_data_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_character_data`
--

LOCK TABLES `snapshot_character_data` WRITE;
/*!40000 ALTER TABLE `snapshot_character_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_character_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_character_etc_properties`
--

DROP TABLE IF EXISTS `snapshot_character_etc_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_character_etc_properties` (
  `snapshotId` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`snapshotId`,`name`),
  CONSTRAINT `snapshot_character_etc_properties_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_character_etc_properties`
--

LOCK TABLES `snapshot_character_etc_properties` WRITE;
/*!40000 ALTER TABLE `snapshot_character_etc_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_character_etc_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_character_properties`
--

DROP TABLE IF EXISTS `snapshot_character_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_character_properties` (
  `snapshotId` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`snapshotId`,`name`),
  CONSTRAINT `snapshot_character_properties_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_character_properties`
--

LOCK TABLES `snapshot_character_properties` WRITE;
/*!40000 ALTER TABLE `snapshot_character_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_character_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_item_properties`
--

DROP TABLE IF EXISTS `snapshot_item_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_item_properties` (
  `snapshotItemId` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`snapshotItemId`,`name`),
  CONSTRAINT `snapshot_item_properties_ibfk_1` FOREIGN KEY (`snapshotItemId`) REFERENCES `snapshot_items` (`snapshotItemId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_item_properties`
--

LOCK TABLES `snapshot_item_properties` WRITE;
/*!40000 ALTER TABLE `snapshot_item_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_item_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_items`
--

DROP TABLE IF EXISTS `snapshot_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_items` (
  `snapshotItemId` bigint(20) NOT NULL AUTO_INCREMENT,
  `snapshotId` bigint(20) NOT NULL,
  `originalItemId` bigint(20) DEFAULT NULL,
  `itemId` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `isEquipped` tinyint(1) NOT NULL DEFAULT 0,
  `equipSlot` tinyint(3) unsigned DEFAULT NULL,
  `inventoryIndex` int(11) DEFAULT NULL,
  PRIMARY KEY (`snapshotItemId`),
  KEY `idx_snapshot_items_snapshot` (`snapshotId`),
  CONSTRAINT `snapshot_items_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_items`
--

LOCK TABLES `snapshot_items` WRITE;
/*!40000 ALTER TABLE `snapshot_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_jobs`
--

DROP TABLE IF EXISTS `snapshot_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_jobs` (
  `snapshotId` bigint(20) NOT NULL,
  `jobId` int(11) NOT NULL,
  `circle` int(11) NOT NULL,
  `skillPoints` int(11) NOT NULL,
  `totalExp` bigint(20) NOT NULL,
  `selectionDate` datetime NOT NULL,
  `advDate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`snapshotId`,`jobId`),
  CONSTRAINT `snapshot_jobs_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_jobs`
--

LOCK TABLES `snapshot_jobs` WRITE;
/*!40000 ALTER TABLE `snapshot_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_quest_progress`
--

DROP TABLE IF EXISTS `snapshot_quest_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_quest_progress` (
  `snapshotQuestId` bigint(20) NOT NULL,
  `ident` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `done` tinyint(1) NOT NULL,
  `unlocked` tinyint(1) NOT NULL,
  PRIMARY KEY (`snapshotQuestId`,`ident`),
  CONSTRAINT `snapshot_quest_progress_ibfk_1` FOREIGN KEY (`snapshotQuestId`) REFERENCES `snapshot_quests` (`snapshotQuestId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_quest_progress`
--

LOCK TABLES `snapshot_quest_progress` WRITE;
/*!40000 ALTER TABLE `snapshot_quest_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_quest_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_quests`
--

DROP TABLE IF EXISTS `snapshot_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_quests` (
  `snapshotQuestId` bigint(20) NOT NULL AUTO_INCREMENT,
  `snapshotId` bigint(20) NOT NULL,
  `questClassId` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `startTime` datetime NOT NULL,
  `completeTime` datetime NOT NULL,
  `tracked` tinyint(1) NOT NULL,
  PRIMARY KEY (`snapshotQuestId`),
  KEY `idx_snapshot_quests_snapshot` (`snapshotId`),
  CONSTRAINT `snapshot_quests_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_quests`
--

LOCK TABLES `snapshot_quests` WRITE;
/*!40000 ALTER TABLE `snapshot_quests` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_quests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_skills`
--

DROP TABLE IF EXISTS `snapshot_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_skills` (
  `snapshotId` bigint(20) NOT NULL,
  `skillId` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`snapshotId`,`skillId`),
  CONSTRAINT `snapshot_skills_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_skills`
--

LOCK TABLES `snapshot_skills` WRITE;
/*!40000 ALTER TABLE `snapshot_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_social_data`
--

DROP TABLE IF EXISTS `snapshot_social_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_social_data` (
  `snapshotId` bigint(20) NOT NULL,
  `partyId` bigint(20) NOT NULL DEFAULT 0,
  `guildId` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`snapshotId`),
  CONSTRAINT `snapshot_social_data_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_social_data`
--

LOCK TABLES `snapshot_social_data` WRITE;
/*!40000 ALTER TABLE `snapshot_social_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_social_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_storage_personal`
--

DROP TABLE IF EXISTS `snapshot_storage_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_storage_personal` (
  `snapshotId` bigint(20) NOT NULL,
  `position` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `originalItemDbId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`snapshotId`,`position`),
  CONSTRAINT `snapshot_storage_personal_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_storage_personal`
--

LOCK TABLES `snapshot_storage_personal` WRITE;
/*!40000 ALTER TABLE `snapshot_storage_personal` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_storage_personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_storage_team`
--

DROP TABLE IF EXISTS `snapshot_storage_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_storage_team` (
  `snapshotId` bigint(20) NOT NULL,
  `position` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `originalItemDbId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`snapshotId`,`position`),
  CONSTRAINT `snapshot_storage_team_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_storage_team`
--

LOCK TABLES `snapshot_storage_team` WRITE;
/*!40000 ALTER TABLE `snapshot_storage_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_storage_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snapshot_variables`
--

DROP TABLE IF EXISTS `snapshot_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snapshot_variables` (
  `snapshotId` bigint(20) NOT NULL,
  `variableName` varchar(255) NOT NULL,
  `variableType` varchar(10) NOT NULL,
  `variableValue` mediumtext NOT NULL,
  PRIMARY KEY (`snapshotId`,`variableName`),
  CONSTRAINT `snapshot_variables_ibfk_1` FOREIGN KEY (`snapshotId`) REFERENCES `character_snapshots` (`snapshotId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snapshot_variables`
--

LOCK TABLES `snapshot_variables` WRITE;
/*!40000 ALTER TABLE `snapshot_variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `snapshot_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_users`
--

DROP TABLE IF EXISTS `social_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_users` (
  `userId` bigint(20) NOT NULL,
  `accountId` bigint(20) NOT NULL,
  `accountName` varchar(32) NOT NULL,
  `teamName` varchar(64) NOT NULL,
  `lastLogin` datetime DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `accountId` (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_users`
--

LOCK TABLES `social_users` WRITE;
/*!40000 ALTER TABLE `social_users` DISABLE KEYS */;
INSERT INTO `social_users` VALUES (1,1,'gotei','Gotei','2026-04-25 20:28:32');
/*!40000 ALTER TABLE `social_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_personal`
--

DROP TABLE IF EXISTS `storage_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storage_personal` (
  `characterId` bigint(20) NOT NULL,
  `itemId` bigint(20) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`characterId`,`itemId`),
  KEY `itemId` (`itemId`),
  CONSTRAINT `storage_personal_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `storage_personal_ibfk_2` FOREIGN KEY (`itemId`) REFERENCES `items` (`itemUniqueId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_personal`
--

LOCK TABLES `storage_personal` WRITE;
/*!40000 ALTER TABLE `storage_personal` DISABLE KEYS */;
/*!40000 ALTER TABLE `storage_personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_team`
--

DROP TABLE IF EXISTS `storage_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storage_team` (
  `accountId` bigint(20) NOT NULL,
  `itemId` bigint(20) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`accountId`,`itemId`),
  KEY `itemId` (`itemId`),
  CONSTRAINT `storage_team_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `storage_team_ibfk_2` FOREIGN KEY (`itemId`) REFERENCES `items` (`itemUniqueId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_team`
--

LOCK TABLES `storage_team` WRITE;
/*!40000 ALTER TABLE `storage_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `storage_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates`
--

DROP TABLE IF EXISTS `updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates` (
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates`
--

LOCK TABLES `updates` WRITE;
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
INSERT INTO `updates` VALUES ('main.sql'),('update_2015-08-17_1.sql'),('update_2015-08-17_2.sql'),('update_2015-08-17_3.sql'),('update_2015-08-20_1.sql'),('update_2015-08-20_2.sql'),('update_2015-08-27_1.sql'),('update_2015-09-03_1.sql'),('update_2015-09-16_1.sql'),('update_2015-12-12_1.sql'),('update_2016-04-01_1.sql'),('update_2016-04-02_1.sql'),('update_2016-04-03_1.sql'),('update_2016-04-11_1.sql'),('update_2016-04-23_1.sql'),('update_2017-09-01_1.sql'),('update_2017-09-02_1.sql'),('update_2017-09-03_1.sql'),('update_2017-09-04_1.sql'),('update_2017-09-12_1.sql'),('update_2017-09-14_1.sql'),('update_2017-09-19_1.sql'),('update_2017-09-19_2.sql'),('update_2017-09-19_3.sql'),('update_2017-09-25_1.sql'),('update_2017-09-26_1.sql'),('update_2017-09-28_1.sql'),('update_2017-09-29_1.sql'),('update_2017-10-31_1.sql'),('update_2021-09-08_1.sql'),('update_2021-09-14_1.sql'),('update_2021-09-28_1.sql'),('update_2021-10-07_1.sql'),('update_2021-10-07_2.sql'),('update_2021-10-13_1.sql'),('update_2023-05-10_1.sql'),('update_2023-05-11_1.sql'),('update_2023-05-18_2.sql'),('update_2023-05-19_1.sql'),('update_2023-05-21_1.sql'),('update_2023-05-22_1.sql'),('update_2023-05-22_2.sql'),('update_2023-05-23_1.sql'),('update_2023-05-24_1.sql'),('update_2023-05-25_1.sql'),('update_2023-05-25_2.sql'),('update_2023-05-27_1.sql'),('update_2023-05-29_1.sql'),('update_2023-05-31_1.sql'),('update_2023-05-31_2.sql'),('update_2023-05-31_3.sql'),('update_2023-06-01_1.sql'),('update_2023-06-02_1.sql'),('update_2023-06-03_1.sql'),('update_2023-06-03_2.sql'),('update_2023-06-26_1.sql'),('update_2023-06-27_1.sql'),('update_2023-06-30_1.sql'),('update_2023-07-03_1.sql'),('update_2023-07-03_2.sql'),('update_2023-07-12_1.sql'),('update_2023-07-15_1.sql'),('update_2023-07-16_1.sql'),('update_2023-07-20_1.sql'),('update_2023-07-27_1.sql'),('update_2023-07-27_2.sql'),('update_2023-07-27_3.sql'),('update_2023-07-28_1.sql'),('update_2023-09-29_1.sql'),('update_2024-01-26_1.sql'),('update_2024-03-11_1.sql'),('update_2024-05-16_1.sql'),('update_2024-06-03_1.sql'),('update_2024-06-05_1.sql'),('update_2024-07-13_1.sql'),('update_2024-07-16_1.sql'),('update_2024-07-26_1.sql'),('update_2024-07-27_1.sql'),('update_2024-08-11_1.sql'),('update_2024-08-11_2.sql'),('update_2024-08-13_1.sql'),('update_2024-08-16_1.sql'),('update_2024-08-16_2.sql'),('update_2024-08-16_3.sql'),('update_2024-08-19_1.sql'),('update_2024-08-22_1.sql'),('update_2024-08-23_1.sql'),('update_2024-09-02_1.sql'),('update_2024-09-09_1.sql'),('update_2024-09-20_1.sql'),('update_2024-09-23_1.sql'),('update_2024-10-12_1.sql'),('update_2024-10-17_1.sql'),('update_2024-11-14_1.sql'),('update_2024_08-26_1.sql'),('update_2025-02-05_1.sql'),('update_2025-06-16_1.sql'),('update_2025-06-18_1.sql'),('update_2025-06-20_1.sql'),('update_2025-07-02_1.sql'),('update_2025-08-07_1.sql'),('update_2025-08-07_2.sql'),('update_2025-11-10_1.sql'),('update_2025-11-12_1.sql'),('update_2025-11-17_1.sql'),('update_2025-11-17_2.sql'),('update_2025-11-20_1.sql'),('update_2025-11-20_2.sql'),('update_2025-11-27_1.sql'),('update_2025-12-22_1.sql'),('update_2025-12-26_2.sql'),('update_2026-01-16_1.sql'),('update_2026-01-21_title.sql'),('update_2026-01-21_title_snapshot.sql'),('update_2026-01-25_1.sql'),('update_2026-02-05_1.sql'),('update_2026-03-11_1.sql'),('update_2026-04-04_1.sql'),('update_2026-04-08_1.sql'),('update_2026-04-08_2.sql');
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_recent_snapshots`
--

DROP TABLE IF EXISTS `v_recent_snapshots`;
/*!50001 DROP VIEW IF EXISTS `v_recent_snapshots`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_recent_snapshots` AS SELECT
 1 AS `snapshotId`,
  1 AS `characterId`,
  1 AS `accountId`,
  1 AS `snapshotReason`,
  1 AS `operationDetails`,
  1 AS `createdAt`,
  1 AS `gameVersion`,
  1 AS `characterLevel`,
  1 AS `mapId`,
  1 AS `characterName`,
  1 AS `teamName`,
  1 AS `ageCategory` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_rollback_summary`
--

DROP TABLE IF EXISTS `v_rollback_summary`;
/*!50001 DROP VIEW IF EXISTS `v_rollback_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_rollback_summary` AS SELECT
 1 AS `characterId`,
  1 AS `characterName`,
  1 AS `teamName`,
  1 AS `totalRollbacks`,
  1 AS `lastRollback`,
  1 AS `reasons` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_snapshot_statistics`
--

DROP TABLE IF EXISTS `v_snapshot_statistics`;
/*!50001 DROP VIEW IF EXISTS `v_snapshot_statistics`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_snapshot_statistics` AS SELECT
 1 AS `snapshotDate`,
  1 AS `snapshotReason`,
  1 AS `snapshotCount`,
  1 AS `uniqueCharacters`,
  1 AS `uniqueAccounts` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vars_accounts`
--

DROP TABLE IF EXISTS `vars_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vars_accounts` (
  `varId` bigint(20) NOT NULL AUTO_INCREMENT,
  `accountId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(2) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`varId`),
  KEY `accountId` (`accountId`),
  CONSTRAINT `vars_accounts_ibfk_1` FOREIGN KEY (`accountId`) REFERENCES `accounts` (`accountId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vars_accounts`
--

LOCK TABLES `vars_accounts` WRITE;
/*!40000 ALTER TABLE `vars_accounts` DISABLE KEYS */;
INSERT INTO `vars_accounts` VALUES (1,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(2,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(3,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(4,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(5,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(6,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(7,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(8,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(9,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(10,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(11,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(12,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(13,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(14,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(15,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(16,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(17,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(18,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(19,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(20,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(21,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(22,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(23,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(24,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(25,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(26,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(27,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(28,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(29,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(30,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(31,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(32,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(33,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(34,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(35,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(36,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(37,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(38,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(39,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(40,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(41,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(42,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(43,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(44,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(45,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(46,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(47,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(48,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(49,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(50,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(51,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(52,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(53,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(54,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(55,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(56,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(57,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(58,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(59,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(60,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(61,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(62,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(63,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(64,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(65,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(66,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(67,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(68,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(69,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(70,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(71,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True'),(72,1,'Melia.ClientScripts.BetterOptions.DoneFirstTime','b','True');
/*!40000 ALTER TABLE `vars_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vars_buffs`
--

DROP TABLE IF EXISTS `vars_buffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vars_buffs` (
  `varId` bigint(20) NOT NULL AUTO_INCREMENT,
  `buffId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(2) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`varId`),
  KEY `characterId` (`buffId`),
  CONSTRAINT `vars_buffs_ibfk_1` FOREIGN KEY (`buffId`) REFERENCES `buffs` (`buffId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vars_buffs`
--

LOCK TABLES `vars_buffs` WRITE;
/*!40000 ALTER TABLE `vars_buffs` DISABLE KEYS */;
/*!40000 ALTER TABLE `vars_buffs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vars_characters`
--

DROP TABLE IF EXISTS `vars_characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vars_characters` (
  `varId` bigint(20) NOT NULL AUTO_INCREMENT,
  `characterId` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `type` char(2) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`varId`),
  UNIQUE KEY `uk_character_var` (`characterId`,`name`),
  KEY `characterId` (`characterId`),
  CONSTRAINT `vars_characters_ibfk_1` FOREIGN KEY (`characterId`) REFERENCES `characters` (`characterId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=875 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vars_characters`
--

LOCK TABLES `vars_characters` WRITE;
/*!40000 ALTER TABLE `vars_characters` DISABLE KEYS */;
INSERT INTO `vars_characters` VALUES (1,1,'Melia.PropertiesInitialized','b','True'),(2,1,'Melia.EverLoggedIn','b','True'),(3,1,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(4,1,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(5,1,'Laima.Tutorial.Movement','b','True'),(6,1,'Melia.QuickSlotRows','1u','40'),(7,1,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640073,360287970189639951#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(8,1,'Melia.Main.Welcome','s','C34CDB038AD19D341468C1F913A7BB9BF778843A'),(9,1,'Melia.HudSkin','4','0'),(19,1,'Laima.Faction','s','Klaipeda'),(20,1,'Melia.CityReturnLocation.Map','s','c_Klaipe'),(21,1,'Melia.CityReturnLocation.X','f','-161'),(22,1,'Melia.CityReturnLocation.Y','f','149'),(23,1,'Melia.CityReturnLocation.Z','f','54'),(260,3,'Melia.PropertiesInitialized','b','True'),(261,3,'Melia.EverLoggedIn','b','True'),(262,3,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(263,3,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(264,3,'Laima.Tutorial.Movement','b','True'),(265,3,'Melia.QuickSlotRows','1u','20'),(266,3,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640073,360287970189639826#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(267,3,'Melia.Main.Welcome','s','1D444CEE04827C3BD2D069F22EBCF4BCF7C3FB27'),(268,3,'Laima.Faction','s','Klaipeda'),(269,3,'Melia.CityReturnLocation.Map','s','c_Klaipe'),(270,3,'Melia.CityReturnLocation.X','f','-161'),(271,3,'Melia.CityReturnLocation.Y','f','149'),(272,3,'Melia.CityReturnLocation.Z','f','54'),(299,4,'Melia.PropertiesInitialized','b','True'),(300,4,'Clover.ClassicStartInitialized','b','True'),(301,4,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(302,4,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(303,4,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(304,4,'Laima.Tutorial.Movement','b','True'),(305,4,'Melia.QuickSlotRows','1u','20'),(306,4,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,360287970189639921#Item,640005,360287970189639922#Item,640097,360287970189639923#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(307,4,'Melia.Main.Welcome','s','A7F9946DB9ED4387D90EB4914E823A65F4D3D41F'),(326,5,'Melia.PropertiesInitialized','b','True'),(327,5,'Clover.ClassicStartInitialized','b','True'),(328,5,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(329,5,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(330,5,'Laima.Tutorial.Movement','b','True'),(331,5,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(332,5,'Melia.QuickSlotRows','1u','20'),(333,5,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(334,5,'Melia.Main.Welcome','s','C951A29B70B169DF44A289E98593C92EC8FDEDBA'),(350,6,'Melia.PropertiesInitialized','b','True'),(351,6,'Clover.ClassicStartInitialized','b','True'),(352,6,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(353,6,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(354,6,'Laima.Tutorial.Movement','b','True'),(355,6,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(356,6,'Melia.QuickSlotRows','1u','20'),(357,6,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(358,6,'Melia.Main.Welcome','s','6581E012253BB101624C8788C81A1FA4B1BB9E4D'),(378,8,'Melia.PropertiesInitialized','b','True'),(379,8,'Clover.ClassicStartInitialized','b','True'),(380,8,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(381,8,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(382,8,'Laima.Tutorial.Movement','b','True'),(383,8,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(384,8,'Melia.QuickSlotRows','1u','20'),(385,8,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,360287970189639774#Item,640005,360287970189639775#Item,640097,360287970189639776#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(386,8,'Melia.Main.Welcome','s','BF01EEC205EF53D40ED1AE74E340936362CAE2B1'),(387,8,'Melia.ResurrectOptions','4','4096'),(408,9,'Melia.PropertiesInitialized','b','True'),(409,9,'Clover.ClassicStartInitialized','b','True'),(410,9,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(411,9,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(412,9,'Laima.Tutorial.Movement','b','True'),(413,9,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(414,9,'Melia.QuickSlotRows','1u','20'),(415,9,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(416,9,'Melia.Main.Welcome','s','1699CC5DD81532CF0B65714C7589BAC6B951EEC9'),(426,10,'Melia.PropertiesInitialized','b','True'),(427,10,'Clover.ClassicStartInitialized','b','True'),(428,10,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(429,10,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(430,10,'Laima.Tutorial.Movement','b','True'),(431,10,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(432,10,'Melia.QuickSlotRows','1u','20'),(433,10,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(434,10,'Melia.Main.Welcome','s','24935DCD236E93B3D460D24BA6995B80CEFF861A'),(435,10,'Melia.ResurrectOptions','4','4096'),(446,11,'Melia.PropertiesInitialized','b','True'),(447,11,'Clover.ClassicStartInitialized','b','True'),(448,11,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(449,11,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(450,11,'Laima.Tutorial.Movement','b','True'),(451,11,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(452,11,'Melia.QuickSlotRows','1u','20'),(453,11,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(454,11,'Melia.Main.Welcome','s','B324C104878111E5443E900522FE200557CF0FD7'),(455,12,'Melia.PropertiesInitialized','b','True'),(456,12,'Clover.ClassicStartInitialized','b','True'),(457,12,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(458,12,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(459,12,'Laima.Tutorial.Movement','b','True'),(460,12,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(461,13,'Melia.PropertiesInitialized','b','True'),(462,13,'Clover.ClassicStartInitialized','b','True'),(463,13,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(464,13,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(465,13,'Laima.Tutorial.Movement','b','True'),(466,13,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(467,13,'Melia.QuickSlotRows','1u','20'),(468,13,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(469,13,'Melia.Main.Welcome','s','71ECCA02EC63DD0FF7368374F466C6622B71D7EE'),(470,14,'Melia.PropertiesInitialized','b','True'),(471,14,'Clover.ClassicStartInitialized','b','True'),(472,14,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(473,14,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(474,14,'Laima.Tutorial.Movement','b','True'),(475,14,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(476,14,'Melia.QuickSlotRows','1u','20'),(477,14,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(478,14,'Melia.Main.Welcome','s','E2B6C6680B61CC002CDC2DEDA41B92E727A839F3'),(488,15,'Melia.PropertiesInitialized','b','True'),(489,15,'Clover.ClassicStartInitialized','b','True'),(490,15,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(491,15,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(492,15,'Laima.Tutorial.Movement','b','True'),(493,15,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(494,15,'Melia.QuickSlotRows','1u','20'),(495,15,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(496,15,'Melia.Main.Welcome','s','21F8AAE52A14BBBB6DE789E8087429D54DB8F80E'),(506,16,'Melia.PropertiesInitialized','b','True'),(507,16,'Clover.ClassicStartInitialized','b','True'),(508,16,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(509,16,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(510,16,'Laima.Tutorial.Movement','b','True'),(511,16,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(512,16,'Melia.QuickSlotRows','1u','20'),(513,16,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(514,16,'Melia.Main.Welcome','s','88A82E6C3AB747EC5B4A5748D707023D92575C92'),(515,16,'1021:11','2','0'),(526,17,'Melia.PropertiesInitialized','b','True'),(527,17,'Clover.ClassicStartInitialized','b','True'),(528,17,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(529,17,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(530,17,'Laima.Tutorial.Movement','b','True'),(531,17,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(532,17,'Melia.QuickSlotRows','1u','20'),(533,17,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(534,17,'Melia.Main.Welcome','s','156947A961D39777F609FF89BEB18F8E1085E7F6'),(535,17,'1021:11','2','0'),(546,18,'Melia.PropertiesInitialized','b','True'),(547,18,'Clover.ClassicStartInitialized','b','True'),(548,18,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(549,18,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(550,18,'Laima.Tutorial.Movement','b','True'),(551,18,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(552,18,'Melia.QuickSlotRows','1u','20'),(553,18,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(554,18,'Melia.Main.Welcome','s','331BA5271C8B915889A5C69AB3BDF4F54CE78781'),(555,18,'1021:11','2','0'),(556,19,'Melia.PropertiesInitialized','b','True'),(557,19,'Clover.ClassicStartInitialized','b','True'),(558,19,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(559,19,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(560,19,'Laima.Tutorial.Movement','b','True'),(561,19,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(562,19,'Melia.QuickSlotRows','1u','20'),(563,19,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,360287970189639725#Item,640005,360287970189639726#Item,640097,360287970189639727#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(564,19,'Melia.Main.Welcome','s','49FFD5C9A4520023837E1B85F1CFFCF7068BC938'),(565,19,'1021:11','2','0'),(586,20,'Melia.PropertiesInitialized','b','True'),(587,20,'Clover.ClassicStartInitialized','b','True'),(588,20,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(589,20,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(590,20,'Laima.Tutorial.Movement','b','True'),(591,20,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(592,20,'Melia.QuickSlotRows','1u','20'),(593,20,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,360287970189639821#Item,640005,360287970189639822#Item,640097,360287970189639823#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(594,20,'Melia.Main.Welcome','s','A52EE2769E35D555498B1914CF836DD394A86563'),(595,20,'1021:11','2','0'),(596,20,'Melia.ResurrectOptions','4','4096'),(617,4,'Melia.ResurrectOptions','4','4096'),(628,21,'Melia.PropertiesInitialized','b','True'),(629,21,'Clover.ClassicStartInitialized','b','True'),(630,21,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(631,21,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(632,21,'Laima.Tutorial.Movement','b','True'),(633,21,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(634,21,'Melia.QuickSlotRows','1u','20'),(635,21,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#Item,640002,0#Item,640005,0#Item,640097,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(636,21,'Melia.Main.Welcome','s','85649CCA59A2538D50659882FD5499EAD4298692'),(637,22,'Melia.PropertiesInitialized','b','True'),(638,22,'Clover.ClassicStartInitialized','b','True'),(639,22,'Laima.Custom.JobExpMigration_2026_02_12','b','True'),(640,22,'Laima.Custom.JobExpMigration_2026_03_17','b','True'),(641,22,'Laima.Tutorial.Movement','b','True'),(642,22,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(643,22,'Melia.QuickSlotRows','1u','20'),(644,22,'Melia.QuickSlotList','s','#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,0,0#None,1,0#None,2,0#None,3,0#'),(645,22,'Melia.Main.Welcome','s','99496E38CD74D62955D20D9000FBD4581408302E'),(646,22,'1021:11','2','0'),(671,1,'Clover.ClassicStartInitialized','b','True'),(672,1,'Clover.Tutorial.Movement.WestSiauliai','b','True'),(753,1,'1021:11','2','0');
/*!40000 ALTER TABLE `vars_characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vars_global`
--

DROP TABLE IF EXISTS `vars_global`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vars_global` (
  `varId` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `type` char(2) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`varId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vars_global`
--

LOCK TABLES `vars_global` WRITE;
/*!40000 ALTER TABLE `vars_global` DISABLE KEYS */;
/*!40000 ALTER TABLE `vars_global` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `guiltinesin_local`
--

USE `guiltinesin_local`;

--
-- Final view structure for view `v_recent_snapshots`
--

/*!50001 DROP VIEW IF EXISTS `v_recent_snapshots`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`melia`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_recent_snapshots` AS select `cs`.`snapshotId` AS `snapshotId`,`cs`.`characterId` AS `characterId`,`cs`.`accountId` AS `accountId`,`cs`.`snapshotReason` AS `snapshotReason`,`cs`.`operationDetails` AS `operationDetails`,`cs`.`createdAt` AS `createdAt`,`cs`.`gameVersion` AS `gameVersion`,`cs`.`characterLevel` AS `characterLevel`,`cs`.`mapId` AS `mapId`,`scd`.`name` AS `characterName`,`scd`.`teamName` AS `teamName`,case when `cs`.`createdAt` >= current_timestamp() - interval 24 hour then 'Last 24 Hours' when `cs`.`createdAt` >= current_timestamp() - interval 7 day then 'Last Week' when `cs`.`createdAt` >= current_timestamp() - interval 30 day then 'Last Month' else 'Older' end AS `ageCategory` from (`character_snapshots` `cs` left join `snapshot_character_data` `scd` on(`cs`.`snapshotId` = `scd`.`snapshotId`)) where `cs`.`createdAt` >= current_timestamp() - interval 90 day order by `cs`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_rollback_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_rollback_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`melia`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_rollback_summary` AS select `rl`.`characterId` AS `characterId`,`scd`.`name` AS `characterName`,`scd`.`teamName` AS `teamName`,count(0) AS `totalRollbacks`,max(`rl`.`rolledBackAt`) AS `lastRollback`,group_concat(distinct `rl`.`rollbackReason` order by `rl`.`rolledBackAt` DESC separator '; ') AS `reasons` from ((`rollback_log` `rl` left join `character_snapshots` `cs` on(`rl`.`snapshotId` = `cs`.`snapshotId`)) left join `snapshot_character_data` `scd` on(`cs`.`snapshotId` = `scd`.`snapshotId`)) group by `rl`.`characterId`,`scd`.`name`,`scd`.`teamName` order by count(0) desc,max(`rl`.`rolledBackAt`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_snapshot_statistics`
--

/*!50001 DROP VIEW IF EXISTS `v_snapshot_statistics`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`melia`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_snapshot_statistics` AS select cast(`guiltinesin_local`.`character_snapshots`.`createdAt` as date) AS `snapshotDate`,`guiltinesin_local`.`character_snapshots`.`snapshotReason` AS `snapshotReason`,count(0) AS `snapshotCount`,count(distinct `guiltinesin_local`.`character_snapshots`.`characterId`) AS `uniqueCharacters`,count(distinct `guiltinesin_local`.`character_snapshots`.`accountId`) AS `uniqueAccounts` from `character_snapshots` where `guiltinesin_local`.`character_snapshots`.`createdAt` >= current_timestamp() - interval 30 day group by cast(`guiltinesin_local`.`character_snapshots`.`createdAt` as date),`guiltinesin_local`.`character_snapshots`.`snapshotReason` order by cast(`guiltinesin_local`.`character_snapshots`.`createdAt` as date) desc,count(0) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-07 16:22:33
